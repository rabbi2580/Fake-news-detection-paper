# Group 7 — Fake News Detection: Codebase & All Scores

This package contains the R/Python codebase that produced the results in the
paper ("Auditing Explainability and Dataset Artifacts in Traditional Fake
News Detection"), the raw execution logs showing the scores as they were
actually computed, and every numeric result found across the project. Numbers
here are taken verbatim from logs/CSVs, not retyped from the paper. See
`README.md` for environment setup, dataset acquisition, and run order.

**Canonical run (paper v12).** Every R number below is from one complete run of
`group7_pipeline_runnable.ipynb` under R 4.6.1 (Posit build, UTF-8 locale), captured cell by cell in
`group7_pipeline_with_output.ipynb` and split per script into `logs/`. Compared with the earlier
R 4.3.3 run (`logs/earlier_run_R4.3.3/`), all results are identical except: the linear SVM
(LIBLINEAR's own RNG is not seeded by R; TF-IDF accuracy 0.9707 -> 0.9706), tabular-path LIME
stability (5,000 perm. 0.751 -> 0.742, cross-doc 0.707 -> 0.712), reverse-transfer XGBoost
(0.7275 -> 0.7279), and the exact-match overlap count (encoding fix, see section 10).

**Revision note (earlier version):** a prior version of this file and the paper
contained an unreconciled inconsistency -- the LR-BoW headline accuracy
appeared as 0.9738 in one place and 0.9745 in another (table/abstract), with
a vague footnote blaming "CV-fold jitter." That was investigated properly:
`04_train_models.R` was independently re-run twice in a fresh session and
reproduced **0.9738 bit-for-bit both times** -- it is the canonical,
verified number. The 0.9745 figure could not be reproduced from any script
or log in the project and has been removed everywhere (table, abstract,
confusion matrix, top-words coefficients, ablation baseline, vocab-sweep
baseline). Three further issues raised in an external review were also
addressed: the WELFake experiment is now described as a within-WELFake,
overlap-filtered evaluation rather than "cross-dataset generalization"; the
overlap audit now also checks normalized-text and near-duplicate-prefix
matches, not just exact-text match; and every number in Table VI
(vocabulary-size sweep, time-aware split, full-WELFake baseline) that had no
surviving script has been re-derived with a new, included script. See
"Reproducibility notes" at the end of this file for the full account.

**Revision 2 (journal version, v9):** a second review asked for a real
cross-corpus test, confidence intervals, an overlap label check, stronger
baselines, explicit research questions and fixed references. All are done; the
new results are in Sections 14-21 below. Three corrections came out of this
round and are reflected in both papers: (1) the agreement / tabular-LIME
numbers in earlier drafts (0.859, 0.020, 0.083, 0.011) had no script in the
current pipeline and were re-derived (Section 19: 0.836, 0.046, 0.146, 0.010);
(2) the claim "text-mode LIME is more faithful than SHAP" is not supported:
the difference is not significant on the original 97 documents and reverses
(still non-significantly) on a 300-document replication, where exact
attributions are significantly the most faithful (Section 18); (3) an
independent audit found Table III listed `minist`/`featur` instead of the true
top-5 coefficients `monday`/`gop` (Section 21 is now its source).

---

## 1. Dataset construction (`01_build_corpus.R`, `02_clean_corpus.R`, `03_split_features_models.R`)

```
Raw counts: True=21,417  Fake=23,481  Total=44,898
Exact-duplicate rows: 6,252 (13.92%)   [of which 6,027 Fake, 225 Real]
After dedup: 38,646 docs (Fake=17,454, Real=21,192)
After cleaning, 55 further docs emptied (54 Fake, 1 Real)
Final corpus: 38,591 docs (Fake=17,400, Real=21,191)

Train: 30,873 docs (Fake=13,920, Real=16,953)
Test:  7,718 docs (Fake=3,480, Real=4,238)
Zero train/test exact-text overlap: VERIFIED
Vocabulary: 2,482 terms survive 0.99 sparsity pruning; top-500 used
```

## 2. Main model results — final, deduplicated corpus, CANONICAL (`04_train_models.R`)

Independently re-run twice in this environment; reproduced bit-for-bit both times.

| Model | Repr. | Accuracy | F1 | Selected λ |
|---|---|---|---|---|
| Naive Bayes | BoW | 0.8792 | 0.8955 | — |
| Naive Bayes | TF-IDF | 0.9013 | 0.9129 | — |
| Logistic Regression | BoW | **0.9738** | **0.9763** | 0.0004641589 |
| Logistic Regression | TF-IDF | 0.9740 | 0.9764 | 0.001 |

LR-BoW vs. LR-TF-IDF: not significantly different (McNemar exact p=1, 2 discordant pairs).
LR vs. NB, both representations: Holm-corrected McNemar p<10⁻⁹³ (smallest:
p=1.06×10⁻¹⁴⁰). Confusion matrices (rows=predicted, cols=actual):

```
NB-BoW:  Pred.Fake [2791, 243]   Pred.Real [689, 3995]
LR-BoW:  Pred.Fake [3356, 78]    Pred.Real [124, 4160]
```

## 3. Pre-dedup. comparison, same protocol (`12_before_pipeline.R`, `13a-c_before_*.R`)

```
NB  BoW:    0.839407
NB  TF-IDF: 0.881394
LR  BoW:    0.970009   (λ=0.0004641589)
LR  TF-IDF: 0.970914   (λ=0.0004641589)
Before-test class balance: 48.5% Real (8,836 test docs)
After-test class balance:  54.9% Real (7,718 test docs)
```
(These, not the unrelated `earlier_pipeline_csvs/bootstrap_ci_v4.csv` figures
from a defunct, older pipeline generation, are the correct "Pre-dedup." column
in Table I — an earlier version of this table mixed the two.)

Composition-shift decomposition (`14_composition_shift_test.R`) — before-trained
models scored on the after (deduplicated) test set:
```
LR-BoW:    0.9761596
LR-TFIDF:  0.9759005
NB-BoW:    0.8643431
NB-TFIDF:  0.8984193
```
This is the result that shows Logistic Regression's entire reported accuracy
"rise" from deduplication is attributable to the test set's shifted class
composition, not to cleaner training data (Section IV-A of the paper).

## 4. Leakage ablation, deduplicated corpus (`21_leakage_ablation_dedup.R`, `22_leakage_ablation_curve_fix.R`)

Eight source-artifact tokens (`reuter` + all 7 weekday names present in the
500-term vocabulary) removed, model fully retrained via the same caret/glmnet
CV protocol as the canonical model:

```
BoW:    0.9738 -> 0.9594  (-1.44 points, McNemar p=4.6e-15)
TF-IDF: 0.9740 -> 0.9653  (-0.87 points)
```

Coefficient-ranked incremental removal curve (fixed lambda, direct refit at
each step, ranking only the 8 artifact tokens by |coefficient|):
```
k=0 (none removed):  0.9740
k=1 (+reuter):        0.9703
k=2 (+thursday):       0.9649
k=3 (+wednesday):      0.9604
k=4 (+monday):          0.9593
k=5..8:                 0.9593-0.9596 (converges)
Final point (k=8, direct refit): 0.9596 -- matches the full caret retrain's 0.9594
Reuter alone accounts for 25.2% of the total drop.
```
Vacated-weight migration (full-vocab vs.\ 8-token-ablated model coefficients):
`minist` +0.19, `spokesman` +0.18, `presidenti` +0.22; `getti` -2.13, `via`
-0.41, `pic` -1.64 (all became more strongly Fake-predictive).

## 5. Vocabulary-size sweep, deduplicated corpus (`23_vocab_size_sweep_dedup.R`, `23b_vocab_sweep_full2482.R`)

```
500 terms  (caret CV):              LR-BoW accuracy=0.9738  F1=0.9763
1,000 terms (caret CV):             LR-BoW accuracy=0.9788  F1=0.9808
2,482 terms (fixed λ, direct refit): LR-BoW accuracy=0.9819  F1=0.9836
```
Monotonically increasing. The 2,482-term point uses the 500-term model's own
CV-selected lambda rather than a fresh CV search (a fresh 5-fold search over
2,482 sparse features did not finish in 10 minutes on this machine) — disclosed
in the script.

## 6. Time-aware (chronological) split, deduplicated corpus (`24_time_aware_split_dedup.R`)

```
36 of 38,591 docs (0.09%) had unparseable dates, excluded.
Date range: 2015-03-31 to 2017-12-31
Time-train: 30,844 docs (2015-03-31 to 2017-10-18), 46.5% Real
Time-test:   7,711 docs (2017-10-18 to 2017-12-31), 88.8% Real  <- heavily imbalanced

LR-BoW:   accuracy=0.9722  λ=0.001
LR-TFIDF: accuracy=0.9760  λ=0.000464159
```
The test fold's 88.8%-Real imbalance (vs. 54.9% under the random split) means
its raw accuracy is not directly comparable to Section 2's numbers — a
same-protocol majority-class baseline there would already score 88.8%. Top
tokens recur (`via`, `getti`, `pic`, `read`, `reuter`, weekdays), confirming
the artifact pattern is not an artifact of the random split specifically.

## 7. LIME text-mode vs. tabular-path stability (`07`–`09_lime_text_*.R`)

```
Tabular path (300 perm., original misconfiguration): mean Jaccard 0.146 (sd 0.025) -- re-derived on the current model, see Section 19 (the 0.083 in earlier drafts came from an older pipeline)

Text-mode (word-masking), same 20 docs x 5 repeats:
  300 perm.:    0.4862  (sd 0.3144)
  1,000 perm.:  0.7692  (sd 0.1728)
  5,000 perm.:  0.8899  (sd 0.1010)
  10,000 perm.: 0.9255  (sd 0.0869)

Random present-word-pool baseline: 0.1025 (n=4,000 simulated pairs)
```
Per-document top-10 word sets at 10,000 perms are in `logs/09_lime_text_stability.log`.
These experiments run against the `00c_light_refit.R` model object (see
"Reproducibility notes" below for exactly how that differs from the Table I
canonical model — the difference is 1 prediction out of 7,718, not something
that could plausibly change these conclusions).

## 8. Deletion-based faithfulness / normalized AOPC (`10_deletion_faithfulness_v2.R`, `11_deletion_curve_full.R`)

Mean |ΔP(Real)| by top-k words removed, text-mode LIME @ 5,000 perms, n=97 valid docs:

| k | Exact | SHAP | LIME (text) | Random |
|---|---|---|---|---|
| 1 | 0.0782 | 0.0581 | 0.0566 | 0.0034 |
| 3 | 0.1539 | 0.1422 | 0.1372 | 0.0153 |
| 5 | 0.1883 | 0.1679 | 0.1930 | 0.0197 |
| 10 | 0.2431 | 0.2252 | 0.2195 | 0.0347 |

AOPC averaged k=1..10: Exact 0.1759, SHAP 0.1576, LIME(text) 0.1736, Random 0.0194
Normalized AOPC (AOPC − random-order AOPC): **Exact 0.1565, SHAP 0.1383, LIME(text) 0.1542, Random 0.0000**

No confidence interval is computed for these n=97-document figures; treat as
exploratory, not confirmatory (same caveat applies to Sections 5-7 above,
which also reuse the same 7,718-document test set / its subsets).

## 9. WELFake, within-corpus (not cross-dataset) (`05_welfake_pipeline.R`, `16_welfake_clean.R`, `29_welfake_full_train.R`)

```
WELFake raw: 72,134 articles -> cleaned/deduplicated: 62,614 docs (Fake=27,995, Real=34,619)
  [13.01% duplicate rows removed]

Full-WELFake 80/20 split (own corpus, own random split -- NOT ISOT-trained):
  LR-BoW:   accuracy=0.9213
  LR-TFIDF: accuracy=0.9050
  NB-BoW:   accuracy=0.7703
  NB-TFIDF: accuracy=0.7274
```
Top LR-BoW coefficients: `reuter` 3.24, `via` −2.49, `octob` −1.08, `imag`
−0.79, `com` −0.72, `novemb` −0.68 — same artifact pattern as ISOT. This is a
**within-WELFake** result: it never involves an ISOT-trained model, so it is
not evidence of cross-dataset generalization by itself.

## 10. ISOT↔WELFake overlap audit, strengthened (`15_overlap_check.R`, `25_overlap_check_v2.R`)

```
[1] Exact raw-text match:              20,155 ISOT docs (52.23%), 20,155 WELFake docs (32.14%)
[2] Normalized-text exact match:       20,156 ISOT docs (52.23%), 20,157 WELFake docs (32.14%)
      (+1 ISOT doc beyond [1])
[3] 200-char normalized-prefix match:  20,159 ISOT docs (52.24%), 20,166 WELFake docs (32.15%)
      (+3 docs beyond [1]+[2] -- true near-duplicates with different trailing text are rare)
[4] 100-char normalized-prefix match:  20,159 ISOT docs (52.24%), 20,167 WELFake docs (32.16%)

UNION [1]+[2]+[3]: 20,159 ISOT docs (52.24%), 20,166 WELFake docs (32.15%)

By class (ISOT side):
  exact-match only: Fake 100.00%  Real 13.00%
  union (v2) flag:   Fake 100.00%  Real 13.02%
```
**Encoding note.** In the earlier R 4.3.3 run (logs in `logs/earlier_run_R4.3.3/`) the
WELFake CSV was read without an explicit encoding, so 1,978 articles identical to ISOT
articles carried different string-encoding marks and exact matching found only 18,178
(47.10%); normalized matching still caught them, and the union was the same 20,159.
All `read.csv` calls now pass `encoding = "UTF-8"`, and exact matching finds 20,155.
The union flag is used for every overlap-filtered experiment.

## 11. WELFake overlap-filtered, within-corpus, TWO versions

**v1 — exact-match-filtered only** (`17_welfake_minus_overlap_split.R`, `18_wfm_features.R`, `19b_wfm_train_fast.R`, `19c_wfm_fix_mcc_coefs.R`, `19d_wfm_nb.R`), 42,459 docs retained (67.8%):
```
LR-BoW:    acc=0.9368  f1=0.9578  macroF1=0.9157  balAcc=0.9166  MCC=0.83150
LR-TFIDF:  acc=0.9238  f1=0.9499  macroF1=0.8953  balAcc=0.8842  MCC=0.79199
NB-BoW:    acc=0.7811  f1=0.8625  macroF1=0.6628  balAcc=0.6467  MCC=0.34788
NB-TFIDF:  acc=0.7952  f1=0.8712  macroF1=0.6861  balAcc=0.6673  MCC=0.39412
```

**v2 — exact + normalized-text + near-duplicate-prefix-filtered** (`26_welfake_minus_overlap_v2.R`, `27_wfm_features_v2.R`, `28_wfm_train_v2.R`), 42,448 docs retained (67.8%):
```
LR-BoW:    acc=0.9380  f1=0.9589  macroF1=0.9169  balAcc=0.9149  MCC=0.83374
LR-TFIDF:  acc=0.9257  f1=0.9511  macroF1=0.8982  balAcc=0.8883  MCC=0.79744
NB-BoW:    acc=0.7887  f1=0.8671  macroF1=0.6755  balAcc=0.6580  MCC=0.37281
NB-TFIDF:  acc=0.7914  f1=0.8699  macroF1=0.6715  balAcc=0.6525  MCC=0.37322
```
**The two filters give almost the same subset and result (93.68% vs 93.80%)**,
because with consistent UTF-8 reading exact matching already catches nearly all shared articles. Both versions are **within-WELFake
evaluations** — neither is a cross-dataset generalization test. Top v2 LR-BoW
coefficients: `reuter` 2.97, `octob` −1.44, `novemb` −0.91, `twitter` 0.80,
`sunday` 0.68, `monday` 0.56 — same pattern as v1.

## 12. DistilBERT

**Final / corrected, full 30,873-doc. training set, 1 epoch, CPU** (`train_distilbert_full.py`, `rds/distilbert_full_metrics.json`):
```
eval_accuracy:  0.995336
eval_f1:        0.995756
eval_precision: 0.995052
eval_recall:    0.996461
eval_loss:      0.021199
```
Single run, one dataset, no hyperparameter search, no independent test
corpus — reported as "this dataset's artifacts are transformer-learnable
too," not as a general transformer-superiority claim.

**Earlier / uncorrected, 4,000-doc. class-balanced subsample, 2 epochs** (`earlier_pipeline_csvs/distilbert_results_OLD_uncorrected_4k_subsample.json`), run on the *non-deduplicated* 8,836-doc test set, before an encoding-corruption bug was fixed:
```
accuracy:      0.967746
precision_real: 0.998504
recall_real:    0.934859
f1_real:        0.965634
```

## 13. Earlier-pipeline robustness checks (pre-deduplication corpus, an OLDER pipeline generation; scripts no longer on disk, CSVs in `earlier_pipeline_csvs/`)

These are kept for transparency but are **not** the numbers used anywhere in
the current paper (Table VI's vocab-size/time-split rows were re-derived on
the current, deduplicated corpus in Sections 5-6 above, specifically because
these older numbers are a different, no-longer-reproducible pipeline
generation).

**Leakage ablation** (`leakage_ablation_v4.csv`):
```
BoW:    0.971367 -> 0.956994  (Δ -0.0144, -1.44 pts)
TF-IDF: 0.969783 -> 0.961408  (Δ -0.0084, -0.84 pts)
```

**Feature-vocabulary-size sweep** (`feature_size_sensitivity_v4.csv`), selected rows:
```
1,000 terms: NB-BoW 0.8465/0.8552 F1, NB-TFIDF 0.8786/0.8827, LR-BoW 0.9802/0.9797, LR-TFIDF 0.9791/0.9785
5,000 terms: NB-BoW 0.8526/0.8597, LR-BoW 0.9837/0.9832, NB-TFIDF 0.8656/0.8707, LR-TFIDF 0.9839/0.9835
```

**Time-aware chronological split** (`time_split_raw_v4.csv`):
```
NB-BoW:    acc=0.9373  f1=0.9628
NB-TFIDF:  acc=0.9226  f1=0.9542
LR-BoW:    acc=0.9644  f1=0.9787
LR-TFIDF:  acc=0.9697  f1=0.9819
```

**Bootstrap 95% CI on accuracy** (`bootstrap_ci_v4.csv`):
```
NB-BoW:    0.8451  [0.8374, 0.8521]
NB-TFIDF:  0.8772  [0.8702, 0.8840]
LR-BoW:    0.9714  [0.9681, 0.9747]
LR-TFIDF:  0.9698  [0.9660, 0.9734]
```

**Holm-corrected pairwise McNemar tests** (`mcnemar_crossmodel_v4.csv`): every
Naive-Bayes-vs-Logistic-Regression pair significant at p < 1e-148; LR-BoW vs.
LR-TFIDF not significant (p_holm = 0.231).

**Cross-method agreement, same-document LIME stability (tabular path), SHAP
global importances, worked LIME examples, top words by representation and by
time-split**: full raw data in `agreement_analysis_v4.csv`, `lime_stability_v4.csv`,
`shap_global_bow_v4.csv`, `shap_global_tfidf_v4.csv`, `lime_examples.csv`,
`top_real_bow_v4.csv`, `top_fake_bow_v4.csv`, `top_real_tfidf_v4.csv`,
`top_fake_tfidf_v4.csv`, `top_real_bow_timesplit_v4.csv`, `top_fake_bow_timesplit_v4.csv`.

## 14. Stronger baselines (`34_svm_baseline.R`, `35_xgboost_baseline.R`), ISOT test set, 95% bootstrap CI (`33_bootstrap_ci.R` §6)

```
Linear SVM BoW:    0.9708 [0.9668, 0.9745]  F1 0.9736   C=1     minus LR -0.30 [-0.51, -0.09] pts  McNemar p=0.0056
Linear SVM TF-IDF: 0.9706 [0.9670, 0.9745]  F1 0.9734   C=10    minus LR -0.34 [-0.56, -0.13] pts  McNemar p=0.0028
XGBoost BoW:       0.9821 [0.9790, 0.9848]  F1 0.9838   296 rounds   minus LR +0.83 [0.53, 1.13] pts  McNemar p=1.0e-7
XGBoost TF-IDF:    0.9811 [0.9778, 0.9839]  F1 0.9828   285 rounds   minus LR +0.71 [0.40, 1.01] pts  McNemar p=8.4e-6
XGBoost top gain (BoW): via, said, imag, reuter, read, featur, just, pic, minist, watch
DistilBERT: 0.9953, Clopper-Pearson 95% CI [0.9935, 0.9967] (per-document predictions not retained)
```

## 15. Bootstrap CIs for the main results (`33_bootstrap_ci.R`)

```
NB BoW 0.8792 [0.8725, 0.8864]   NB TF-IDF 0.9013 [0.8951, 0.9076]
LR BoW 0.9738 [0.9703, 0.9773]   LR TF-IDF 0.9740 [0.9705, 0.9775]
LR - NB (BoW) 9.46 [8.73, 10.18] pts; LR - NB (TF-IDF) 7.27 [6.65, 7.93]; NB TF-IDF - BoW 2.20 [1.50, 2.93]; LR TF-IDF - BoW 0.01 [-0.22, 0.23]
8-token ablation drop (BoW): 1.44 [1.09, 1.80] pts
LIME text-mode stability, n=20: 300 0.486 [0.352, 0.620]; 1,000 0.769 [0.696, 0.839]; 5,000 0.890 [0.845, 0.931]; 10,000 0.926 [0.886, 0.963]
```

## 16. Cross-corpus transfer: ISOT-trained models on WELFake v2 (no ISOT match), n=42,448, 75.06% Real (`31`, `31b`, `36`, `36b`)

```
Model (trained on ISOT)          Accuracy [95% CI]         Bal. acc.  MCC    Macro-F1  minus LR (pts)
NB (BoW)                         0.6817 [0.6773, 0.6861]   0.6449     0.262  0.622     -11.18 [-11.56, -10.79]
LR (BoW), canonical              0.7935 [0.7896, 0.7973]   0.8122     0.556  0.761      --
Linear SVM (BoW)                 0.7903 [0.7864, 0.7941]   0.8080     0.549  0.757     -0.32 [-0.47, -0.17]
XGBoost (BoW)                    0.7982 [0.7943, 0.8019]   0.8260     0.578  0.769     +0.47 [+0.21, +0.73]
LR (BoW), 8 artifact tokens out  0.7765 [0.7725, 0.7803]   0.7725     0.493  0.735     -1.70 [-1.93, -1.46]
LR-TF-IDF canonical: 0.7852 (bal. 0.8070, MCC 0.545)

Paired, same 8,489 WELFake v2 test docs: WELFake-trained LR 0.9380 vs ISOT-trained LR 0.8078; gap 13.03 [12.20, 13.89] pts

Mechanism (ISOT-trained LR-BoW):
  WELFake Real docs containing 'reuter' (58.7%):        accuracy 0.9934
  WELFake Real docs containing reuter OR a weekday (87.4%): 0.8497
  WELFake Real docs containing neither (12.6%):          0.2584
  WELFake Fake docs containing 'reuter' (2.5%):          0.3408
  WELFake Fake docs containing neither (72.4%):          0.9048
```
Removing the artifact tokens *lowers* transfer accuracy because WELFake's real
class is itself Reuters-heavy: the transfer test cannot separate veracity from source.

## 17. Overlap label agreement (`32_overlap_label_agreement.R`)

```
Matched ISOT docs (union of exact / normalized / 200-char prefix): 20,159
  matched to >1 WELFake doc: 332; matched WELFake docs with both labels: 1
            WELFake Fake  Fake/Real  Real
ISOT Fake       17,399        1         0
ISOT Real            1        0     2,758
Agreement: 20,157 / 20,158 = 99.995%  (ISOT-Fake 100.00%, ISOT-Real 99.96%)
```

## 18. Explanation replication, 300 new documents (`37_xai_expanded.R` x5 chunks, `37b_xai_expanded_summary.R`)

```
Normalized AOPC              Exact                  SHAP (present)         LIME (text, 5,000)
Original (n=97)              0.1565 [0.127, 0.189]  0.1383 [0.111, 0.166]  0.1542 [0.126, 0.184]
Replication, all (n=300)     0.1719 [0.151, 0.193]  0.1606 [0.139, 0.182]  0.1518 [0.133, 0.172]
  correct (n=240)            0.1542                 0.1474                 0.1458
  misclassified (n=60)       0.2428                 0.2136                 0.1757
Paired differences, original n=97: exact-SHAP +0.018 [0.005, 0.032] (p=0.004); exact-LIME +0.002 [-0.021, 0.025]; LIME-SHAP +0.016 [-0.008, 0.041] (n.s.)
Paired differences, n=300:         exact-SHAP +0.011 [0.003, 0.021]; exact-LIME +0.020 [0.003, 0.037]; LIME-SHAP -0.009 [-0.027, 0.008] (n.s.)
Misclassified only: exact-LIME +0.067 [0.015, 0.120]
LIME text stability @5,000, n=100: 0.881 [0.860, 0.900]; Real-correct 0.905, Fake-correct 0.821, misclassified 0.952; 0/100 below 0.5
```

## 19. Re-derived agreement and tabular LIME (`38_agreement_tabular_rerun.R` A/B, `38b`), current model

```
Agreement, n=97:  exact vs SHAP(present) 0.836 [0.813, 0.858]; exact vs SHAP(full) 0.534 [0.493, 0.574]
                  exact vs LIME tabular(300) 0.046 [0.037, 0.056]; exact vs LIME text(5,000) 0.627 [0.590, 0.665]
Tabular LIME, n=20:  300 perm. same-doc 0.146, cross-doc 0.136;  5,000 perm. same-doc 0.742, cross-doc 0.712 (14/20 distinct sets)
Text LIME, n=20:     cross-doc 0.083 (5,000) / 0.084 (10,000), 20/20 distinct sets
Random top-10 baseline (full 500-term vocab): 0.010
```
These replace 0.859 / 0.020 / 0.083 / 0.011 from earlier drafts (older pipeline, no current script).
Figure: `paper/figures/lime_tabular_vs_text.png` (`39_lime_collapse_figure.R`).

## 20. References verified for v9

Every reference was checked online. Changes: added Junejo et al. 2026 (closest
prior work: WELFake, SHAP-vs-LIME consistency, doi:10.71146/kjmr937), LIBLINEAR,
XGBoost, Efron & Tibshirani; corrected Warman (Dylan Warman, M. A. Kabir),
Thibault (Camille), Edin (full author list, pages, DOI), WELFake (DOI). The
earlier claim "ISOT's top-40 keywords predict the label at 91.8% macro-F1
[Thibault]" could not be verified in the paper's text and was replaced with what
the paper states (ISOT flagged for spurious keyword and temporal correlations).
`dietterich1998` and `lyu2024faithful` were in the bibliography but uncited; both are now cited.

## 21. Remaining paper statistics (`40_paper_extra_stats.R`)

```
Error asymmetry: NB-BoW 689 vs 243, binomial p=4.6e-50; LR-BoW 124 vs 78, p=0.0015
Holm-corrected McNemar (NB/LR family): smallest NB-vs-LR p=1.6e-97; LR-BoW vs LR-TF-IDF p=1.0
Table III (canonical LR-BoW): Real: reuter 2.214, thursday 0.960, wednesday 0.917, monday 0.887, tuesday 0.824
                              Fake: getti -4.105, via -3.687, pic -3.039, read -2.196, gop -2.151
Table I model vs explanation model (00c refit): differ on 1 of 7,718 test predictions
```

## 22. Five random splits (`41_multiseed.R` x5, `41b_multiseed_summary.R`)

```
seed   NB-BoW NB-TFIDF LR-BoW LR-TFIDF LR-ablated SVM-BoW XGB-BoW transfer-LR transfer-XGB LR on WELFake real w/o artifact
123    0.8792 0.9013   0.9738 0.9740   0.9594     0.9708  0.9821  0.7935      0.7982       0.2584
2024   0.8809 0.9022   0.9731 0.9732   0.9636     0.9692  0.9832  0.7945      0.8010       0.2552
7      0.8908 0.8975   0.9731 0.9741   0.9632     0.9712  0.9841  0.7972      0.8024       0.2589
42     0.8728 0.9068   0.9712 0.9715   0.9559     0.9677  0.9822  0.7937      0.8016       0.2639
999    0.8853 0.9020   0.9737 0.9716   0.9610     0.9702  0.9835  0.7963      0.8040       0.2604
mean   0.8818 0.9020   0.9730 0.9729   0.9606     0.9698  0.9830  0.7950      0.8014       0.2594
SD     0.0067 0.0033   0.0010 0.0012   0.0031     0.0014  0.0008  0.0016      0.0021       0.0032
Ablation drop (LR-BoW): mean 1.23 pts, SD 0.26, range 0.95-1.53
XGB - LR: mean +1.01 (0.83-1.10), 5/5 seeds; SVM - LR: mean -0.31 (-0.39 to -0.18), 5/5 seeds
```
Seed 123 reproduces Table I exactly except SVM (0.9710 vs 0.9708; narrower cost grid in the seed script).

## 23. XGBoost explanation audit, 100 docs (`42_xgb_xai.R` x2 chunks, `42b_xgb_xai_summary.R`)

```
Normalized AOPC        TreeSHAP              LIME text (5,000)     Occlusion (leave-one-out)
all (n=100)            0.218 [0.163, 0.275]  0.248 [0.190, 0.304]  0.294 [0.236, 0.354]
correct (n=80)         0.214                 0.231                 0.266
misclassified (n=20)   0.233                 0.316                 0.408
TreeSHAP - LIME: -0.030 [-0.067, +0.006] (n.s., bootstrap p=0.09); occlusion - TreeSHAP +0.076 [0.042, 0.112]; occlusion - LIME +0.046 [0.018, 0.074]
Agreement: TreeSHAP vs LIME 0.660 [0.629, 0.689]; TreeSHAP vs occlusion 0.681; LIME vs occlusion 0.559
TreeSHAP full-vocab top-10 words absent from the document: 25.0%
LIME stability on XGBoost (5 reruns, n=40): 0.766 [0.728, 0.802]  (vs 0.881 on LR)
```

## 24. CC-News multi-publisher real-news probe (`data3/ccnews_extract.py`, `43_ccnews_publisher_probe.R`)

```
% of real articles labeled Real    n     ISOT-LR  ISOT-XGB  WELFake-LR
Reuters (control)                  600   86.8     81.8      79.5
ABC News                           600   56.3     55.5      75.8
National Post                      600   51.0     52.8      75.5
Irish Times                        442   49.8     50.7      70.6
NZ Herald                          600   48.2     49.7      69.0
BBC                                340   43.8     44.1      62.1
NBC News                           600   42.3     40.0      86.2
LA Times                           600   41.7     39.7      87.8
New York Times                     276   15.6     18.8      87.3
NPR                                355   13.8     12.7      75.2
All non-Reuters                    4413  43.0 [41.5, 44.4]  43.0  77.0 [75.7, 78.2]
  politics only                    1585  53.4     53.9      88.6
  non-Reuters containing 'reuter'  185   71.4     83.8      98.9
```
Source-level labels (mainstream outlet => real), 2017 articles; CC-News is not redistributed (rebuild with the script).

## 25. Reverse transfer WELFake -> ISOT (`44_reverse_transfer.R`)

```
ISOT test n=7,718 (54.9% Real; majority 0.5491)
WELFake-trained LR-BoW:  0.7319 [0.7217, 0.7419]  balanced 0.7124  Real recall 0.911  Fake recall 0.514
WELFake-trained XGBoost: 0.7279 [0.7183, 0.7376]  balanced 0.7047  Real recall 0.941  Fake recall 0.469
```

## 26. Remaining CIs (`46_extra_cis.R`)

```
Tabular LIME 300 perm.: same-doc 0.146 [0.132, 0.158]; cross-doc 0.136 [0.126, 0.146]
Tabular LIME 5,000:     same-doc 0.742 [0.724, 0.760]; cross-doc 0.712 [0.689, 0.733]
TF-IDF ablation drop: 0.87 pts [0.58, 1.17], McNemar p=6.2e-9
```

## 27. WELFake label polarity

WELFake's documentation (Zenodo record 4561253) says "0 = fake and 1 = real". The file's content
is the reverse: every ISOT fake article found in WELFake carries label 1. The pipeline uses the
content-based mapping (`05_welfake_pipeline.R`: 0 -> Real, 1 -> Fake), confirmed by the 99.995%
label agreement on 20,158 overlapping articles (Section 17).

## 28. DistilBERT cross-corpus (pending, GPU)

`distilbert_retrain_transfer_colab.ipynb` + `distilbert_colab_data.zip` (exported by `06` and `45`).
Not yet run; results to be added when the Colab output is returned.

---

## Reproducibility notes

**Why did 0.9738 and 0.9745 both appear in earlier drafts?** Three different
fitting procedures were used across the project for an LR-BoW model at the
same lambda (4.641589e-4):

1. `04_train_models.R` — `caret::train(method="glmnet", trControl=trainControl(method="cv", number=5), tuneGrid=<10 lambdas>)`. Caret's internal final-model refit fits the *entire* lambda grid as one path and reads off the selected lambda's coefficients. **This is canonical: 0.9738, reproduced bit-for-bit on two independent re-runs.**
2. `00c_light_refit.R` — a direct, single-lambda `glmnet(x, y, lambda=4.641589e-4)` call, used only to rebuild a lightweight model object for the explanation-validation scripts (which don't need the full `features.rds` in memory). Gives 0.973957 — 1 of 7,718 test predictions differs from (1) (see `40_paper_extra_stats.log`) due to the different fitting path (not CV-fold randomness; this fit has no CV in it at all). Coefficients differ by ~0.005 (e.g. `reuter`: 2.214 vs. 2.220).
3. An unrecovered third run (whatever produced the 0.9745/0.8777/0.9044 figures in an earlier paper draft) — could not be reproduced from any script or log in the project and has been retired. The most likely explanation is a run with a different package version or an uncommitted code change at some earlier point in the project's history; it is not used anywhere in the current paper or this file.

All current paper numbers trace to (1), except where explicitly marked
"00c model" in Section 7 above (where the difference is immaterial to the
conclusion being drawn).

**Table VI entries with no surviving script**: the original vocabulary-size
sweep, time-aware split, and full-WELFake baseline numbers in an earlier
paper draft had no corresponding script anywhere in the project (similar to
`earlier_pipeline_csvs/`, but for the *current*, deduplicated-corpus pipeline
generation specifically — i.e., not an old-pipeline/new-pipeline mismatch,
just a lost script). These have been re-derived from scratch with new,
included scripts (`23`, `23b`, `24`, `29`) and the new numbers are what the
paper now reports.

---

## File map

```
scripts/        all R + Python scripts for the pipeline (relative paths; see README.md for run order)
logs/            console output from actually running those scripts (the scores above, verbatim)
figures/         the PNG figures used in the paper (regenerated with corrected numbers)
earlier_pipeline_csvs/   surviving CSV/JSON outputs from the earlier (pre-dedup) pipeline phase
distilbert_full_metrics.json   final, corrected DistilBERT result (full training set)
README.md        environment setup, dataset acquisition, full run order, script-to-result map
group7_pipeline_with_output.ipynb   the same pipeline as one notebook with captured output
```
