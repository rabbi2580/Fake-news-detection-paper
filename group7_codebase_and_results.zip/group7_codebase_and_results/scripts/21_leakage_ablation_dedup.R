suppressMessages({ library(dplyr); library(caret); library(glmnet) })

# Reproducible re-run of the source-artifact-token leakage ablation on the
# FINAL deduplicated corpus (38,591 docs). Supersedes an earlier, undocumented
# ablation run whose script no longer exists on disk and whose reported
# baseline (97.45%) does not match the canonical, reproducible 04_train_models.R
# output (97.38%). This script defines the experiment explicitly (which 8
# tokens, which fitting procedure) so the numbers it prints are the only ones
# used in the paper going forward.

feat <- readRDS("rds/features.rds")
train_docs <- feat$train_docs; test_docs <- feat$test_docs
train_bow <- feat$train_bow; test_bow <- feat$test_bow
train_tfidf <- feat$train_tfidf; test_tfidf <- feat$test_tfidf
vocab500 <- feat$vocab500

# All 8 source-artifact tokens identified in Table "Top words by BoW coefficient"
# (reuter = wire-service byproduct; the 7 weekday names = dateline-stamp byproduct).
# All 8 are confirmed present in the 500-term vocabulary.
artifact_tokens <- c("reuter","monday","tuesday","wednesday","thursday","friday","saturday","sunday")
stopifnot(all(artifact_tokens %in% vocab500))
cat("Removing", length(artifact_tokens), "source-artifact tokens:", paste(artifact_tokens, collapse=", "), "\n")
keep <- setdiff(vocab500, artifact_tokens)

cv_ctrl <- trainControl(method="cv", number=5)
lambda_grid <- 10^seq(log10(1e-4), log10(1e-1), length.out=10)

fit_lr_caret <- function(X, y, seed=123) {
  set.seed(seed)
  df <- data.frame(X, label=y, check.names=FALSE)
  train(label ~ ., data=df, method="glmnet", family="binomial",
        trControl=cv_ctrl, tuneGrid=expand.grid(alpha=1, lambda=lambda_grid))
}
eval_caret <- function(fit, X, y) {
  df <- data.frame(X, check.names=FALSE)
  pred <- predict(fit, df)
  mean(pred == y)
}

y_train <- train_docs$label; y_test <- test_docs$label

cat("\n== BoW: same caret/glmnet CV protocol as 04_train_models.R ==\n")
fit_full_bow <- fit_lr_caret(train_bow, y_train)
acc_full_bow <- eval_caret(fit_full_bow, test_bow, y_test)
cat(sprintf("Full-vocab BoW accuracy (sanity check vs 04_train_models.R's 0.9738): %.4f  lambda=%g\n",
            acc_full_bow, fit_full_bow$bestTune$lambda))

train_bow_abl <- train_bow[, keep]; test_bow_abl <- test_bow[, keep]
fit_abl_bow <- fit_lr_caret(train_bow_abl, y_train)
acc_abl_bow <- eval_caret(fit_abl_bow, test_bow_abl, y_test)
cat(sprintf("Ablated (8-token-removed) BoW accuracy: %.4f  lambda=%g\n", acc_abl_bow, fit_abl_bow$bestTune$lambda))
cat(sprintf("Drop: %.4f (%.2f points)\n", acc_full_bow - acc_abl_bow, 100*(acc_full_bow - acc_abl_bow)))

cat("\n== TF-IDF: same protocol ==\n")
fit_full_tfidf <- fit_lr_caret(train_tfidf, y_train)
acc_full_tfidf <- eval_caret(fit_full_tfidf, test_tfidf, y_test)
cat(sprintf("Full-vocab TF-IDF accuracy (sanity check vs 04_train_models.R's 0.9740): %.4f\n", acc_full_tfidf))

train_tfidf_abl <- train_tfidf[, keep]; test_tfidf_abl <- test_tfidf[, keep]
fit_abl_tfidf <- fit_lr_caret(train_tfidf_abl, y_train)
acc_abl_tfidf <- eval_caret(fit_abl_tfidf, test_tfidf_abl, y_test)
cat(sprintf("Ablated TF-IDF accuracy: %.4f\n", acc_abl_tfidf))
cat(sprintf("Drop: %.4f (%.2f points)\n", acc_full_tfidf - acc_abl_tfidf, 100*(acc_full_tfidf - acc_abl_tfidf)))

# McNemar test: full-vocab BoW predictions vs ablated BoW predictions, both on test set
pred_full_bow <- predict(fit_full_bow, data.frame(test_bow, check.names=FALSE))
pred_abl_bow  <- predict(fit_abl_bow,  data.frame(test_bow_abl, check.names=FALSE))
mc <- mcnemar.test(table(pred_full_bow == y_test, pred_abl_bow == y_test))
cat("\nMcNemar (full-vocab-correct vs ablated-correct, BoW), p =", format.pval(mc$p.value), "\n")

saveRDS(list(acc_full_bow=acc_full_bow, acc_abl_bow=acc_abl_bow,
             acc_full_tfidf=acc_full_tfidf, acc_abl_tfidf=acc_abl_tfidf,
             mcnemar_p=mc$p.value, fit_full_bow=fit_full_bow, fit_abl_bow=fit_abl_bow),
        "rds/leakage_ablation_dedup.rds")

# ---- Coefficient-ranked incremental removal curve ----
# Fast path: fixed lambda (= the full-vocab BoW model's own CV-selected lambda),
# direct glmnet refit at each step rather than a full caret CV re-search --
# this keeps a 13-point curve tractable. Explicitly disclosed as a design choice.
cat("\n== Incremental coefficient-ranked removal curve (BoW, fixed lambda, direct glmnet refit) ==\n")
lambda_fixed <- fit_full_bow$bestTune$lambda
cat("Fixed lambda for curve:", lambda_fixed, "\n")
y_train_bin <- ifelse(y_train=="Real",1,0)

full_glm <- glmnet(train_bow, y_train_bin, family="binomial", alpha=1, lambda=lambda_fixed)
beta <- as.matrix(full_glm$beta)
ranked_tokens <- rownames(beta)[order(-abs(beta[,1]))]
cat("Top 10 |coef|-ranked tokens:", paste(ranked_tokens[1:10], collapse=", "), "\n")

eval_glmnet_acc <- function(Xtr, Xte, ytr_bin, yte) {
  f <- glmnet(Xtr, ytr_bin, family="binomial", alpha=1, lambda=lambda_fixed)
  p <- as.numeric(predict(f, newx=Xte, type="response"))
  mean(ifelse(p>0.5,"Real","Fake") == yte)
}

ks <- c(0,1,2,3,4,5,6,7,8,10,12,15,20)
curve <- data.frame(k=ks, accuracy=NA_real_, removed=NA_character_)
for (i in seq_along(ks)) {
  k <- ks[i]
  rm_tok <- if (k==0) character(0) else ranked_tokens[1:k]
  keep_k <- setdiff(vocab500, rm_tok)
  acc_k <- eval_glmnet_acc(train_bow[,keep_k], test_bow[,keep_k], y_train_bin, y_test)
  curve$accuracy[i] <- acc_k
  curve$removed[i] <- paste(rm_tok, collapse=",")
  cat(sprintf("k=%2d  acc=%.4f  removed=[%s]\n", k, acc_k, paste(rm_tok, collapse=",")))
}
total_drop <- curve$accuracy[curve$k==0] - curve$accuracy[curve$k==max(curve$k)]
reuter_drop <- curve$accuracy[curve$k==0] - curve$accuracy[curve$k==1]
cat(sprintf("\nTotal drop k=0->%d: %.4f. Share due to removing 'reuter' alone (k=0->1): %.1f%%\n",
            max(curve$k), total_drop, 100*reuter_drop/total_drop))

saveRDS(curve, "rds/leakage_ablation_curve.rds")
cat("\nDone.\n")
