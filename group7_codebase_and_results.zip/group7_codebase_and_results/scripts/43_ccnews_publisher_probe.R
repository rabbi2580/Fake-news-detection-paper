suppressMessages({ library(stringr); library(tm); library(SnowballC); library(caret); library(glmnet); library(xgboost) })

# Multi-publisher REAL-news probe. ISOT's real class is 100% Reuters, so an
# ISOT model may have learned "Reuters style = real". We take real news from
# ten mainstream publishers in CC-News (Hamborg et al.; Hugging Face
# vblagoje/cc_news), all from 2017 (ISOT's period), up to 600 articles each,
# at least 500 characters (sample built by data3/ccnews_extract.py), apply the
# identical ISOT cleaning, and ask: what fraction does each model call "Real"?
# On an all-real sample this is the accuracy (= specificity for "real").
# Labels here are a SOURCE-LEVEL assumption (mainstream outlet => real), not
# per-article fact checks. Reuters is included as the in-distribution control.

cc <- read.csv("data3/ccnews_2017_mainstream_sample.csv", stringsAsFactors = FALSE, encoding = "UTF-8")
cat("CC-News sample:", nrow(cc), "articles,", length(unique(cc$domain)), "publishers\n")

clean_text <- function(txt) { txt <- tolower(txt); txt <- str_replace_all(txt, "http\\S+|www\\.\\S+", " ")
  txt <- str_replace_all(txt, "[^a-z\\s]", " "); str_trim(str_replace_all(txt, "\\s+", " ")) }
stem_stop <- function(txt) { w <- unlist(str_split(txt, "\\s+")); w <- w[w != "" & !w %in% stopwords("en")]
  paste(wordStem(w, language = "english"), collapse = " ") }
cc$text_ds <- str_replace(cc$text, "^[A-Za-z\\.,' ]+\\(Reuters\\)\\s*-\\s*", "")   # same dateline strip as ISOT
cc$text_final <- vapply(clean_text(cc$text_ds), stem_stop, character(1))
cc <- cc[str_trim(cc$text_final) != "", ]
tok <- strsplit(cc$text_final, "\\s+")
cc$has_reuter <- vapply(tok, function(w) "reuter" %in% w, logical(1))
pol_terms <- c("trump","presid","govern","minist","elect","senat","congress","parliament","polit","republican","democrat")
cc$politics <- vapply(tok, function(w) sum(w %in% pol_terms) >= 2, logical(1))

bow <- function(txt, vocab) { d <- DocumentTermMatrix(VCorpus(VectorSource(txt)), control = list(dictionary = vocab))[, vocab]
  stopifnot(identical(colnames(d), vocab)); as.matrix(d) }
v_isot <- readRDS("rds/vocab500.rds"); X <- bow(cc$text_final, v_isot)
lr <- readRDS("rds/lr_bow_fit.rds")
cc$p_lr <- as.character(predict(lr, data.frame(X, check.names = FALSE)))
xg <- xgb.load("rds/xgb_model_bow.ubj")
cc$p_xgb <- ifelse(predict(xg, xgb.DMatrix(X)) > 0.5, "Real", "Fake")
v_wf <- readRDS("rds/vocab500_wfm_v2.rds"); Xw <- bow(cc$text_final, v_wf)
wl <- readRDS("rds/wfm_results_v2.rds")$lr_bow_fit
cc$p_wf <- ifelse(as.numeric(predict(wl, newx = Xw, type = "response")) > 0.5, "Real", "Fake")

set.seed(2030); B <- 2000
cif <- function(v) { b <- replicate(B, mean(v[sample.int(length(v), length(v), TRUE)])); quantile(b, c(.025, .975)) }
summ <- function(sel, lab) {
  r <- c(n = sum(sel), reuter_tok = mean(cc$has_reuter[sel]),
         isot_lr = mean(cc$p_lr[sel] == "Real"), isot_xgb = mean(cc$p_xgb[sel] == "Real"), welfake_lr = mean(cc$p_wf[sel] == "Real"))
  cat(sprintf("  %-22s n=%4d  'reuter' in text %5.1f%%  | %% called Real: ISOT-LR %5.1f  ISOT-XGB %5.1f  WELFake-LR %5.1f\n",
              lab, r["n"], 100 * r["reuter_tok"], 100 * r["isot_lr"], 100 * r["isot_xgb"], 100 * r["welfake_lr"]))
  r }
cat("\n=== Fraction of mainstream REAL articles each model labels 'Real' (= accuracy on this all-real sample) ===\n")
out <- list()
for (d in c("uk.reuters.com", setdiff(sort(unique(cc$domain)), "uk.reuters.com"))) out[[d]] <- summ(cc$domain == d, d)
nonr <- cc$domain != "uk.reuters.com"
cat("\n"); out$non_reuters_all <- summ(nonr, "ALL non-Reuters")
out$non_reuters_politics <- summ(nonr & cc$politics, "non-Reuters, politics")
out$non_reuters_with_reuter_tok <- summ(nonr & cc$has_reuter, "non-Reuters, has 'reuter'")
out$non_reuters_without <- summ(nonr & !cc$has_reuter, "non-Reuters, no 'reuter'")
for (m in c("p_lr","p_xgb","p_wf")) { q <- cif(cc[[m]][nonr] == "Real")
  cat(sprintf("  95%% CI, %-6s on all non-Reuters: [%.3f, %.3f]\n", m, q[1], q[2])) }
saveRDS(list(table = do.call(rbind, out), data = cc[, c("domain","has_reuter","politics","p_lr","p_xgb","p_wf")]),
        "rds/ccnews_probe.rds")
cat("\nDone.\n")
