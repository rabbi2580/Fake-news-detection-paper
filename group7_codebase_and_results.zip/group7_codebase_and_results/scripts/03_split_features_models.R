suppressMessages({
  library(dplyr); library(tm); library(caret); library(glmnet); library(naivebayes); library(slam)
})

final <- readRDS("rds/final_corpus.rds")
final$label <- factor(final$label, levels = c("Fake","Real"))

set.seed(123)
idx <- createDataPartition(final$label, p = 0.8, list = FALSE)
train_docs <- final[idx, ]
test_docs  <- final[-idx, ]
cat("Train:", nrow(train_docs), "| Fake:", sum(train_docs$label=="Fake"), "Real:", sum(train_docs$label=="Real"), "\n")
cat("Test:", nrow(test_docs), "| Fake:", sum(test_docs$label=="Fake"), "Real:", sum(test_docs$label=="Real"), "\n")

stopifnot(length(intersect(train_docs$text, test_docs$text)) == 0)
cat("Zero train/test exact-text overlap: VERIFIED\n")

# Build DTM over TRAINING corpus only
train_corpus <- VCorpus(VectorSource(train_docs$text_final))
train_dtm <- DocumentTermMatrix(train_corpus)
train_dtm_pruned <- removeSparseTerms(train_dtm, 0.99)
cat("Terms surviving sparsity pruning (0.99):", ncol(train_dtm_pruned), "\n")

train_mat <- as.matrix(train_dtm_pruned)
term_freq <- colSums(train_mat)
vocab500 <- names(sort(term_freq, decreasing = TRUE))[1:500]
cat("Vocab size (top-500):", length(vocab500), "\n")

# Function to build BoW matrix for a set of texts against a fixed vocab
build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control = list(dictionary = vocab))
  mat <- as.matrix(dtm)
  # ensure all vocab columns present in correct order
  missing_cols <- setdiff(vocab, colnames(mat))
  if (length(missing_cols) > 0) {
    addmat <- matrix(0, nrow = nrow(mat), ncol = length(missing_cols), dimnames = list(NULL, missing_cols))
    mat <- cbind(mat, addmat)
  }
  mat <- mat[, vocab, drop = FALSE]
  mat
}

train_bow <- build_bow(train_docs$text_final, vocab500)
test_bow  <- build_bow(test_docs$text_final, vocab500)
cat("train_bow dim:", dim(train_bow), " test_bow dim:", dim(test_bow), "\n")

# TF-IDF: train-only idf
N_train <- nrow(train_bow)
df_train <- colSums(train_bow > 0)
idf <- log2(N_train / df_train)
idf[is.infinite(idf)] <- 0

tfidf_from_bow <- function(bow_mat, idf_vec) {
  row_sums <- rowSums(bow_mat)
  row_sums[row_sums == 0] <- 1
  tf <- bow_mat / row_sums
  sweep(tf, 2, idf_vec, `*`)
}
train_tfidf <- tfidf_from_bow(train_bow, idf)
test_tfidf  <- tfidf_from_bow(test_bow, idf)

saveRDS(list(train_docs=train_docs, test_docs=test_docs, vocab500=vocab500,
             train_bow=train_bow, test_bow=test_bow,
             train_tfidf=train_tfidf, test_tfidf=test_tfidf, idf=idf),
        "rds/features.rds")
cat("Saved features.rds\n")
