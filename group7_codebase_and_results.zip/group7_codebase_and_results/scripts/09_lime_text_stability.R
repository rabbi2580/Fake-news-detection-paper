suppressMessages({ library(lime); library(tm); library(glmnet) })

core <- readRDS("rds/lime_text_core.rds")
glmnet_wrap <- core$glmnet_wrap
preprocess_bow <- core$preprocess_bow
vocab500 <- readRDS("rds/vocab500.rds")
test_docs <- readRDS("rds/test_docs_light.rds")
correct_idx <- readRDS("rds/correct_idx.rds")$correct_idx

predict_model.glmnet_wrap <- function(x, newdata, type, ...) {
  p1 <- as.numeric(predict(x$fit, newx = as.matrix(newdata), type = "response"))
  data.frame(Fake = 1 - p1, Real = p1)
}
model_type.glmnet_wrap <- function(x, ...) "classification"
assign("predict_model.glmnet_wrap", predict_model.glmnet_wrap, envir = .GlobalEnv)
assign("model_type.glmnet_wrap", model_type.glmnet_wrap, envir = .GlobalEnv)

jaccard <- function(a, b) length(intersect(a,b)) / length(union(a,b))

# Stratified sample: 10 Real-labeled, 10 Fake-labeled correctly classified docs (fixed seed)
set.seed(777)
real_pool <- correct_idx[test_docs$label[correct_idx] == "Real"]
fake_pool <- correct_idx[test_docs$label[correct_idx] == "Fake"]
sel_idx <- c(sample(real_pool, 10), sample(fake_pool, 10))
cat("Selected", length(sel_idx), "documents (10 Real, 10 Fake)\n")

explainer <- lime(test_docs$text_final[sel_idx], model = glmnet_wrap, preprocess = preprocess_bow)

run_stability <- function(doc_indices, n_perm, n_repeats = 5, seed_base = 1000) {
  doc_results <- list()
  for (i in seq_along(doc_indices)) {
    idx <- doc_indices[i]
    txt <- test_docs$text_final[idx]
    repeats <- list()
    for (r in 1:n_repeats) {
      set.seed(seed_base + i*100 + r)
      e <- tryCatch(explain(txt, explainer, n_labels = 1, n_features = 10, n_permutations = n_perm),
                    error = function(e) NULL)
      if (is.null(e)) { repeats[[r]] <- character(0) } else {
        repeats[[r]] <- e$feature[order(-abs(e$feature_weight))][1:min(10,nrow(e))]
      }
    }
    pairs <- combn(n_repeats, 2)
    jacs <- apply(pairs, 2, function(p) jaccard(repeats[[p[1]]], repeats[[p[2]]]))
    doc_results[[i]] <- list(idx = idx, repeats = repeats, mean_jaccard = mean(jacs), jacs = jacs)
  }
  doc_results
}

cat("\n=== Running stability at 300 permutations (matching original budget) ===\n")
t0 <- Sys.time()
res_300 <- run_stability(sel_idx, 300)
cat("Time:", as.numeric(Sys.time()-t0, units="secs"), "sec\n")
means_300 <- sapply(res_300, function(x) x$mean_jaccard)
cat("Per-doc mean Jaccard (300 perm):", round(means_300,4), "\n")
cat("Overall mean:", mean(means_300), " SD:", sd(means_300), "\n")

saveRDS(list(sel_idx=sel_idx, res_300=res_300), "rds/lime_text_stability_300.rds")

cat("\n=== Running stability at 1000 permutations ===\n")
t0 <- Sys.time()
res_1000 <- run_stability(sel_idx, 1000)
cat("Time:", as.numeric(Sys.time()-t0, units="secs"), "sec\n")
means_1000 <- sapply(res_1000, function(x) x$mean_jaccard)
cat("Overall mean:", mean(means_1000), " SD:", sd(means_1000), "\n")

cat("\n=== Running stability at 5000 permutations ===\n")
t0 <- Sys.time()
res_5000 <- run_stability(sel_idx, 5000)
cat("Time:", as.numeric(Sys.time()-t0, units="secs"), "sec\n")
means_5000 <- sapply(res_5000, function(x) x$mean_jaccard)
cat("Overall mean:", mean(means_5000), " SD:", sd(means_5000), "\n")

cat("\n=== Running stability at 10000 permutations ===\n")
t0 <- Sys.time()
res_10000 <- run_stability(sel_idx, 10000)
cat("Time:", as.numeric(Sys.time()-t0, units="secs"), "sec\n")
means_10000 <- sapply(res_10000, function(x) x$mean_jaccard)
cat("Overall mean:", mean(means_10000), " SD:", sd(means_10000), "\n")

saveRDS(list(sel_idx=sel_idx, res_300=res_300, res_1000=res_1000, res_5000=res_5000, res_10000=res_10000),
        "rds/lime_text_sensitivity_sweep.rds")

# Random baseline: random 10-of-present-words picks (document-specific pool), per selected doc
set.seed(99)
random_jaccards <- c()
for (idx in sel_idx) {
  words <- unique(strsplit(test_docs$text_final[idx], " ")[[1]])
  words <- words[words != ""]
  if (length(words) < 10) next
  for (b in 1:200) {
    s1 <- sample(words, min(10,length(words)))
    s2 <- sample(words, min(10,length(words)))
    random_jaccards <- c(random_jaccards, jaccard(s1,s2))
  }
}
cat("\nRandom present-word baseline Jaccard: mean=", mean(random_jaccards), " n=", length(random_jaccards), "\n")
saveRDS(random_jaccards, "rds/lime_text_random_baseline.rds")

# Locality check at largest budget: inspect top-10 word SETS for a handful of different docs
cat("\n=== Locality check at 10000 perms: top-10 word sets for first doc of each repeat-1 ===\n")
for (i in seq_along(sel_idx)) {
  cat("Doc", sel_idx[i], "(", as.character(test_docs$label[sel_idx[i]]), "):", res_10000[[i]]$repeats[[1]], "\n")
}
