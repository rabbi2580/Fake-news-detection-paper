suppressMessages({ library(glmnet); library(tm) })
feat <- readRDS("rds/features.rds")
vocab500 <- feat$vocab500
train_docs <- feat$train_docs
test_docs <- feat$test_docs
train_bow <- feat$train_bow
test_bow <- feat$test_bow

y_train <- ifelse(train_docs$label == "Real", 1, 0)
# Same lambda as the canonical caret model (04_train_models.R), read from it rather than hardcoded,
# so the explanation model is the Table I model's regularization in every R/package environment.
lambda_canon <- readRDS("rds/model_results.rds")$lr_bow$fit$bestTune$lambda
cat("Canonical caret lambda (LR-BoW):", lambda_canon, "\n")
lr_bow_glmnet <- glmnet(x = train_bow, y = y_train, family = "binomial", alpha = 1, lambda = lambda_canon)

pred_prob <- predict(lr_bow_glmnet, newx = test_bow, type = "response")[,1]
pred_class <- ifelse(pred_prob > 0.5, "Real", "Fake")
acc <- mean(pred_class == test_docs$label)
cat("Lightweight glmnet refit LR-BoW accuracy:", acc, "\n")

saveRDS(lr_bow_glmnet, "rds/lr_bow_glmnet.rds")
saveRDS(vocab500, "rds/vocab500.rds")
saveRDS(train_docs[, c("text","text_final","label")], "rds/train_docs_light.rds")
saveRDS(test_docs[, c("text","text_final","label")], "rds/test_docs_light.rds")
cat("Saved light objects.\n")
