# Summarize 41_multiseed.R over the 5 split seeds: mean, SD, min, max.
seeds <- c(123, 2024, 7, 42, 999)
R <- do.call(rbind, lapply(seeds, function(s) unlist(readRDS(sprintf("rds/multiseed_%d.rds", s)))))
R <- as.data.frame(R)
cat("Per-seed results:\n"); print(round(R, 4), row.names = FALSE)
cols <- setdiff(names(R), c("seed", "n_artifact_in_vocab"))
S <- data.frame(metric = cols, mean = sapply(R[cols], mean), sd = sapply(R[cols], sd),
                min = sapply(R[cols], min), max = sapply(R[cols], max))
S$ablation_drop_pts <- NA
cat("\nAcross 5 seeds:\n"); print(transform(S[, 1:5], mean = round(mean, 4), sd = round(sd, 4), min = round(min, 4), max = round(max, 4)), row.names = FALSE)
d <- 100 * (R$lr_bow - R$lr_bow_ablated)
cat(sprintf("\nArtifact-ablation drop (LR-BoW), pts: mean %.2f, SD %.2f, range %.2f-%.2f\n", mean(d), sd(d), min(d), max(d)))
g <- 100 * (R$xgb_bow - R$lr_bow)
cat(sprintf("XGBoost minus LR (BoW), pts: mean %.2f, SD %.2f, range %.2f-%.2f; XGB > LR in %d/5 seeds\n", mean(g), sd(g), min(g), max(g), sum(g > 0)))
s <- 100 * (R$svm_bow - R$lr_bow)
cat(sprintf("SVM minus LR (BoW), pts: mean %.2f, SD %.2f, range %.2f-%.2f; SVM < LR in %d/5 seeds\n", mean(s), sd(s), min(s), max(s), sum(s < 0)))
saveRDS(list(per_seed = R, summary = S), "rds/multiseed_summary.rds")
