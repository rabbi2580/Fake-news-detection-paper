suppressMessages(library(glmnet))
res <- readRDS("rds/wfm_lr_results.rds")
split <- readRDS("rds/welfake_minus_overlap_split.rds")
wfm_test <- split$wfm_test
wfm_test_bow <- readRDS("rds/wfm_test_bow.rds")
wfm_test_tfidf <- readRDS("rds/wfm_test_tfidf.rds")

mcc_fix <- function(fit, X, actual, positive="Real") {
  pred <- ifelse(as.numeric(predict(fit, newx=X, type="response"))>0.5, positive, setdiff(c("Real","Fake"),positive))
  tp <- as.numeric(sum(pred==positive & actual==positive)); tn <- as.numeric(sum(pred!=positive & actual!=positive))
  fp <- as.numeric(sum(pred==positive & actual!=positive)); fn <- as.numeric(sum(pred!=positive & actual==positive))
  mcc_num <- tp*tn - fp*fn; mcc_den <- sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
  mcc_num/mcc_den
}
cat("MCC LR-BoW:", mcc_fix(res$lr_bow_fit, wfm_test_bow, as.character(wfm_test$label)), "\n")
cat("MCC LR-TFIDF:", mcc_fix(res$lr_tfidf_fit, wfm_test_tfidf, as.character(wfm_test$label)), "\n")

# Top coefficients, BoW model
co <- as.matrix(coef(res$lr_bow_fit))
co <- co[co[,1]!=0, , drop=FALSE]
co <- co[rownames(co)!="(Intercept)",,drop=FALSE]
ord <- order(-co[,1])
cat("\nTop 10 toward Real:\n"); print(head(co[ord,,drop=FALSE],10))
cat("\nTop 10 toward Fake:\n"); print(head(co[rev(ord),,drop=FALSE],10))
