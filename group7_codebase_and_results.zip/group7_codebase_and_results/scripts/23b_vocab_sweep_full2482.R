suppressMessages({ library(tm); library(slam); library(glmnet); library(Matrix); library(caret) })

# Standalone, memory-light rerun of just the full-vocabulary (2,482-term)
# point of the vocab-size sweep (23_vocab_size_sweep_dedup.R OOM'd on this
# step when building dense 2,482-column matrices inside the same R process
# that already held the 500- and 1000-term results). This script keeps
# everything sparse and runs in its own fresh process.

feat <- readRDS("rds/features.rds")
train_docs <- feat$train_docs; test_docs <- feat$test_docs
y_train <- train_docs$label; y_test <- test_docs$label
rm(feat); gc()

train_corpus <- VCorpus(VectorSource(train_docs$text_final))
train_dtm <- DocumentTermMatrix(train_corpus)
train_dtm_pruned <- removeSparseTerms(train_dtm, 0.99)
cat("Terms surviving 0.99 sparsity pruning:", ncol(train_dtm_pruned), "\n")
term_freq <- slam::col_sums(train_dtm_pruned)
vocab_full <- names(sort(term_freq, decreasing=TRUE))
cat("Full vocab size:", length(vocab_full), "\n")
rm(train_dtm, term_freq); gc()

# Build train BoW as a SPARSE matrix directly from the pruned DTM (same
# vocabulary/columns, just reordered to vocab_full and kept sparse).
train_dtm_pruned <- train_dtm_pruned[, vocab_full]
stopifnot(identical(colnames(train_dtm_pruned), vocab_full))
train_simple <- as.simple_triplet_matrix(train_dtm_pruned)
train_bow_sp <- sparseMatrix(i = train_simple$i, j = train_simple$j, x = train_simple$v,
                              dims = dim(train_simple), dimnames = list(NULL, vocab_full))
rm(train_dtm_pruned, train_simple, train_corpus); gc()
cat("train_bow_sp dim:", dim(train_bow_sp), "class:", class(train_bow_sp)[1], "\n")

test_corpus <- VCorpus(VectorSource(test_docs$text_final))
test_dtm <- DocumentTermMatrix(test_corpus, control=list(dictionary=vocab_full))
test_dtm <- test_dtm[, vocab_full]   # tm's dictionary= does not guarantee column order matches vocab_full
stopifnot(identical(colnames(test_dtm), vocab_full))
test_simple <- as.simple_triplet_matrix(test_dtm)
test_bow_sp <- sparseMatrix(i = test_simple$i, j = test_simple$j, x = test_simple$v,
                             dims = dim(test_simple), dimnames = list(NULL, vocab_full))
rm(test_dtm, test_simple, test_corpus); gc()
cat("test_bow_sp dim:", dim(test_bow_sp), "\n")

y_train_bin <- ifelse(y_train=="Real", 1, 0)

# A full 5-fold CV lambda search over 2,482 sparse features did not finish
# within a 10-minute budget in this environment. Rather than let it hang,
# this step reuses the canonical lambda already selected for the 500-term
# model (read from 04_train_models.R's caret fit) -- i.e. it isolates the pure
# effect of vocabulary size at a FIXED regularization strength, rather than
# re-tuning regularization at every vocabulary size. Disclosed explicitly;
# not re-tuned per vocabulary size.
best_lambda <- readRDS("rds/model_results.rds")$lr_bow$fit$bestTune$lambda   # canonical caret lambda, read (not hardcoded)
cat("Using fixed lambda (reused from the canonical 500-term model, not re-tuned):", best_lambda, "\n")

final_fit <- glmnet(train_bow_sp, y_train_bin, family="binomial", alpha=1, lambda=best_lambda)
p <- as.numeric(predict(final_fit, newx=test_bow_sp, type="response"))
pred <- ifelse(p>0.5, "Real", "Fake")
acc <- mean(pred == y_test)
cm <- caret::confusionMatrix(factor(pred, levels=c("Fake","Real")), factor(y_test, levels=c("Fake","Real")), positive="Real")
f1 <- cm$byClass["F1"]
cat(sprintf("\nvocab=%d  LR-BoW accuracy=%.4f  F1=%.4f  lambda=%g\n", length(vocab_full), acc, f1, best_lambda))

saveRDS(list(vocab_size=length(vocab_full), accuracy=acc, f1=f1, lambda=best_lambda),
        "rds/vocab_sweep_full2482.rds")
cat("Done.\n")
