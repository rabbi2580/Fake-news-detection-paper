suppressMessages({ library(dplyr); library(stringr); library(tm); library(SnowballC); library(caret); library(glmnet) })

true_df <- read.csv("data/True.csv", stringsAsFactors = FALSE, encoding = "UTF-8")
fake_df <- read.csv("data/Fake.csv", stringsAsFactors = FALSE, encoding = "UTF-8")
true_df$label <- "Real"; fake_df$label <- "Fake"
combined <- rbind(true_df, fake_df)  # NOT deduplicated - the "before" corpus
cat("Before-pipeline raw combined:", nrow(combined), "\n")

combined$text <- str_replace(combined$text, "^[A-Za-z\\.,' ]+\\(Reuters\\)\\s*-\\s*", "")
set.seed(123)
combined <- combined[sample(nrow(combined)), ]

clean_text <- function(txt) {
  txt <- tolower(txt)
  txt <- str_replace_all(txt, "http\\S+|www\\.\\S+", " ")
  txt <- str_replace_all(txt, "[^a-z\\s]", " ")
  txt <- str_replace_all(txt, "\\s+", " ")
  str_trim(txt)
}
remove_stopwords_stem <- function(txt) {
  words <- unlist(str_split(txt, "\\s+")); words <- words[words != ""]
  words <- words[!words %in% stopwords("en")]
  words <- wordStem(words, language = "english")
  paste(words, collapse = " ")
}

cat("Cleaning", nrow(combined), "documents (before pipeline, non-deduplicated)...\n")
combined$text_clean <- clean_text(combined$text)
combined$text_final <- sapply(combined$text_clean, remove_stopwords_stem)
empty_idx <- str_trim(combined$text_final) == ""
cat("Empty after cleaning:", sum(empty_idx), "\n"); print(table(combined$label[empty_idx]))
before_final <- combined[!empty_idx, ]
cat("Before-pipeline final corpus:", nrow(before_final), "| Fake:", sum(before_final$label=="Fake"), "Real:", sum(before_final$label=="Real"), "\n")
before_final$label <- factor(before_final$label, levels=c("Fake","Real"))

set.seed(123)
idx <- createDataPartition(before_final$label, p=0.8, list=FALSE)
before_train <- before_final[idx,]; before_test <- before_final[-idx,]
cat("Before-train:", nrow(before_train), "Before-test:", nrow(before_test), "\n")
cat("Before-test class balance: Fake=", sum(before_test$label=="Fake"), " Real=", sum(before_test$label=="Real"),
    sprintf(" (%.1f%% Real)\n", 100*mean(before_test$label=="Real")))

saveRDS(list(before_train=before_train, before_test=before_test), "rds/before_pipeline_docs.rds")
cat("Saved before_pipeline_docs.rds\n")
