# Summarize 38_agreement_tabular_rerun.R Part A with 95% bootstrap CIs over documents.
set.seed(2026); B <- 2000
A <- do.call(rbind, lapply(sort(list.files("rds", "^agreement_rerun_[0-9]{3}_[0-9]{3}\\.rds$", full.names = TRUE)), readRDS))
stopifnot(!anyDuplicated(A[, "idx"]))
cat("Agreement documents (>=10 present vocab words):", nrow(A), "\n\n")
lab <- c(exact_shapP = "Exact vs. SHAP (present-word)", exact_shapF = "Exact vs. SHAP (full vocabulary)",
         exact_limeTab = "Exact vs. LIME tabular (300 perm.)", exact_limeText = "Exact vs. LIME text-mode (5,000 perm.)",
         shapF_limeTab = "SHAP (full) vs. LIME tabular", shapP_limeText = "SHAP (present) vs. LIME text-mode")
res <- list()
for (k in names(lab)) {
  v <- A[, k]; b <- replicate(B, mean(v[sample.int(length(v), length(v), TRUE)])); q <- quantile(b, c(.025, .975))
  cat(sprintf("  %-42s %.3f [%.3f, %.3f]\n", lab[k], mean(v), q[1], q[2])); res[[k]] <- c(mean(v), q)
}
saveRDS(list(per_doc = A, summary = res), "rds/agreement_rerun_summary.rds")
