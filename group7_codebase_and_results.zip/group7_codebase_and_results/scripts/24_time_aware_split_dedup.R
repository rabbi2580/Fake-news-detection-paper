suppressMessages({ library(tm); library(caret); library(glmnet); library(stringr) })

# Reproducible time-aware (chronological) split on the FINAL deduplicated
# corpus. Supersedes an earlier, undocumented run whose script no longer
# exists and whose reported numbers (97.25%/97.56%) do not match this
# pipeline's canonical random-split baseline or any surviving log file.

final <- readRDS("rds/final_corpus.rds")
final$label <- factor(final$label, levels=c("Fake","Real"))

date_parsed <- as.Date(str_trim(final$date), format="%B %d, %Y")
n_unparsed <- sum(is.na(date_parsed))
cat(sprintf("Docs with unparseable date: %d of %d (%.2f%%)\n", n_unparsed, nrow(final), 100*n_unparsed/nrow(final)))
final$date_parsed <- date_parsed

usable <- final[!is.na(final$date_parsed), ]
cat(sprintf("Usable (parseable-date) docs: %d | Fake: %d  Real: %d\n",
            nrow(usable), sum(usable$label=="Fake"), sum(usable$label=="Real")))
cat("Date range:", as.character(min(usable$date_parsed)), "to", as.character(max(usable$date_parsed)), "\n")

ord <- order(usable$date_parsed)
usable <- usable[ord, ]
n <- nrow(usable)
cut <- floor(0.8 * n)
time_train <- usable[1:cut, ]
time_test  <- usable[(cut+1):n, ]
cat(sprintf("Time-train: %d docs (%s to %s) | Fake: %d Real: %d (%.1f%% Real)\n",
            nrow(time_train), min(time_train$date_parsed), max(time_train$date_parsed),
            sum(time_train$label=="Fake"), sum(time_train$label=="Real"), 100*mean(time_train$label=="Real")))
cat(sprintf("Time-test:  %d docs (%s to %s) | Fake: %d Real: %d (%.1f%% Real)\n",
            nrow(time_test), min(time_test$date_parsed), max(time_test$date_parsed),
            sum(time_test$label=="Fake"), sum(time_test$label=="Real"), 100*mean(time_test$label=="Real")))
stopifnot(length(intersect(time_train$text, time_test$text)) == 0)
cat("Zero train/test exact-text overlap: VERIFIED\n")

build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control = list(dictionary = vocab))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab, colnames(mat))
  if (length(missing_cols) > 0) {
    addmat <- matrix(0, nrow = nrow(mat), ncol = length(missing_cols), dimnames = list(NULL, missing_cols))
    mat <- cbind(mat, addmat)
  }
  mat[, vocab, drop = FALSE]
}

train_corpus <- VCorpus(VectorSource(time_train$text_final))
train_dtm <- DocumentTermMatrix(train_corpus)
train_dtm_pruned <- removeSparseTerms(train_dtm, 0.99)
train_mat <- as.matrix(train_dtm_pruned)
term_freq <- colSums(train_mat)
vocab500_time <- names(sort(term_freq, decreasing=TRUE))[1:500]
cat("Time-train vocab (top-500) built,", ncol(train_dtm_pruned), "terms survived pruning.\n")
rm(train_dtm, train_dtm_pruned, train_corpus, train_mat); gc()

time_train_bow <- build_bow(time_train$text_final, vocab500_time)
time_test_bow  <- build_bow(time_test$text_final, vocab500_time)

N_train <- nrow(time_train_bow); df_train <- colSums(time_train_bow>0)
idf <- log2(N_train/df_train); idf[is.infinite(idf)] <- 0
tfidf_from_bow <- function(bow, idfv) { rs <- rowSums(bow); rs[rs==0]<-1; sweep(bow/rs, 2, idfv, `*`) }
time_train_tfidf <- tfidf_from_bow(time_train_bow, idf)
time_test_tfidf  <- tfidf_from_bow(time_test_bow, idf)

cv_ctrl <- trainControl(method="cv", number=5)
lambda_grid <- 10^seq(log10(1e-4), log10(1e-1), length.out=10)
fit_lr_caret <- function(X, y, seed=123) {
  set.seed(seed)
  df <- data.frame(X, label=y, check.names=FALSE)
  train(label ~ ., data=df, method="glmnet", family="binomial",
        trControl=cv_ctrl, tuneGrid=expand.grid(alpha=1, lambda=lambda_grid))
}

cat("\n== LR, BoW, time-aware split ==\n")
fit_bow <- fit_lr_caret(time_train_bow, time_train$label)
pred_bow <- predict(fit_bow, data.frame(time_test_bow, check.names=FALSE))
acc_bow <- mean(pred_bow == time_test$label)
cat(sprintf("LR-BoW time-split accuracy: %.4f  lambda=%g\n", acc_bow, fit_bow$bestTune$lambda))

cat("\n== LR, TF-IDF, time-aware split ==\n")
fit_tfidf <- fit_lr_caret(time_train_tfidf, time_train$label)
pred_tfidf <- predict(fit_tfidf, data.frame(time_test_tfidf, check.names=FALSE))
acc_tfidf <- mean(pred_tfidf == time_test$label)
cat(sprintf("LR-TFIDF time-split accuracy: %.4f  lambda=%g\n", acc_tfidf, fit_tfidf$bestTune$lambda))

beta <- as.matrix(coef(fit_bow$finalModel, s=fit_bow$bestTune$lambda))
ord2 <- order(-abs(beta[,1]))
cat("\nTop 10 |coef| tokens, time-split LR-BoW model:\n")
print(data.frame(token=rownames(beta)[ord2][1:10], coef=beta[ord2,1][1:10]))

saveRDS(list(acc_bow=acc_bow, acc_tfidf=acc_tfidf, n_unparsed=n_unparsed,
             train_range=range(time_train$date_parsed), test_range=range(time_test$date_parsed),
             fit_bow=fit_bow, fit_tfidf=fit_tfidf),
        "rds/time_aware_split_dedup.rds")
cat("\nDone.\n")
