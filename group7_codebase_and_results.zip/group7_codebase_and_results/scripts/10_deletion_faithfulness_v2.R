suppressMessages({ library(lime); library(tm); library(glmnet) })

core <- readRDS("rds/lime_text_core.rds")
glmnet_wrap <- core$glmnet_wrap
preprocess_bow <- core$preprocess_bow
vocab500 <- readRDS("rds/vocab500.rds")
test_docs <- readRDS("rds/test_docs_light.rds")
correct_idx <- readRDS("rds/correct_idx.rds")$correct_idx
lr_bow_glmnet <- readRDS("rds/lr_bow_glmnet.rds")

predict_model.glmnet_wrap <- function(x, newdata, type, ...) {
  p1 <- as.numeric(predict(x$fit, newx = as.matrix(newdata), type = "response"))
  data.frame(Fake = 1 - p1, Real = p1)
}
model_type.glmnet_wrap <- function(x, ...) "classification"
assign("predict_model.glmnet_wrap", predict_model.glmnet_wrap, envir = .GlobalEnv)
assign("model_type.glmnet_wrap", model_type.glmnet_wrap, envir = .GlobalEnv)

beta <- as.numeric(coef(lr_bow_glmnet))[-1]  # drop intercept
names(beta) <- rownames(coef(lr_bow_glmnet))[-1]
train_means <- readRDS("rds/train_bow_colmeans.rds")

p_real <- function(bow_row) {
  as.numeric(predict(lr_bow_glmnet, newx = matrix(bow_row, nrow=1, dimnames=list(NULL, vocab500)), type="response"))
}

# Stratified sample: 100 correctly classified docs (50 Real, 50 Fake), matching original protocol
set.seed(2024)
real_pool <- correct_idx[test_docs$label[correct_idx] == "Real"]
fake_pool <- correct_idx[test_docs$label[correct_idx] == "Fake"]
samp_idx <- c(sample(real_pool, 50), sample(fake_pool, 50))

results <- data.frame(idx=samp_idx, n_present=NA, orig_p=NA,
                       exact_d1=NA, exact_d3=NA, exact_d5=NA, exact_d10=NA,
                       shap_d1=NA, shap_d3=NA, shap_d5=NA, shap_d10=NA,
                       lime_d1=NA, lime_d3=NA, lime_d5=NA, lime_d10=NA,
                       rand_d1=NA, rand_d3=NA, rand_d5=NA, rand_d10=NA)

explainer_full <- lime(test_docs$text_final[samp_idx], model = glmnet_wrap, preprocess = preprocess_bow)

delete_topk_change <- function(bow_row, word_order, k, orig_p) {
  cols <- intersect(word_order[1:min(k,length(word_order))], vocab500)
  modified <- bow_row
  modified[cols] <- 0
  abs(orig_p - p_real(modified))
}

t_start <- Sys.time()
for (i in seq_along(samp_idx)) {
  idx <- samp_idx[i]
  txt <- test_docs$text_final[idx]
  bow_row <- preprocess_bow(txt)[1,]
  present_words <- names(bow_row)[bow_row > 0]
  results$n_present[i] <- length(present_words)
  if (length(present_words) < 10) next  # require at least 10 present words for a full top-10 curve
  orig_p <- p_real(bow_row)
  results$orig_p[i] <- orig_p

  # Exact contribution ranking (present words only)
  contrib <- bow_row[present_words] * beta[present_words]
  exact_order <- present_words[order(-abs(contrib))]

  # SHAP (present-word) ranking: phi_i = beta_i*(x_i - mean_i), restricted to present words
  shap_vals <- beta[present_words] * (bow_row[present_words] - train_means[present_words])
  shap_order <- present_words[order(-abs(shap_vals))]

  # LIME (present-word), HIGH BUDGET (5000 perms, text-mode)
  set.seed(3000+i)
  e <- tryCatch(explain(txt, explainer_full, n_labels=1, n_features=min(10,length(present_words)), n_permutations=5000),
                error=function(e) NULL)
  if (!is.null(e)) {
    lime_order <- e$feature[order(-abs(e$feature_weight))]
    lime_order <- intersect(lime_order, present_words)
  } else lime_order <- character(0)

  # Random present-word order
  set.seed(4000+i)
  rand_order <- sample(present_words)

  for (k in c(1,3,5,10)) {
    results[i, paste0("exact_d",k)] <- delete_topk_change(bow_row, exact_order, k, orig_p)
    results[i, paste0("shap_d",k)]  <- delete_topk_change(bow_row, shap_order, k, orig_p)
    if (length(lime_order) >= 1) results[i, paste0("lime_d",k)] <- delete_topk_change(bow_row, lime_order, k, orig_p)
    results[i, paste0("rand_d",k)]  <- delete_topk_change(bow_row, rand_order, k, orig_p)
  }
  if (i %% 20 == 0) cat("Processed", i, "/", length(samp_idx), " elapsed:", as.numeric(Sys.time()-t_start,units="secs"), "s\n")
}
cat("Total time:", as.numeric(Sys.time()-t_start, units="secs"), "sec\n")

saveRDS(results, "rds/deletion_curve_results.rds")

cat("\n=== Mean |delta P(Real)| by top-k removed (n=", sum(results$n_present>=10), ") ===\n")
for (k in c(1,3,5,10)) {
  cat(sprintf("k=%2d: exact=%.4f shap=%.4f lime=%.4f random=%.4f\n", k,
      mean(results[[paste0("exact_d",k)]], na.rm=TRUE),
      mean(results[[paste0("shap_d",k)]], na.rm=TRUE),
      mean(results[[paste0("lime_d",k)]], na.rm=TRUE),
      mean(results[[paste0("rand_d",k)]], na.rm=TRUE)))
}
