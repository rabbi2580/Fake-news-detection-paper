feat <- readRDS("rds/features.rds")
train_means <- colMeans(feat$train_bow)
saveRDS(train_means, "rds/train_bow_colmeans.rds")
cat("Saved train_bow_colmeans.rds, length:", length(train_means), "\n")
