suppressMessages({ library(caret); library(tm); library(slam); library(glmnet); library(naivebayes) })

# Reproducible train/test run on the FULL deduplicated WELFake corpus (62,614
# docs, no ISOT-overlap removal) -- supersedes an earlier, undocumented run
# whose script no longer exists and whose reported numbers (92.40% LR-BoW /
# 75.07% NB-BoW) are not reproducible from anything in the current package.

wf_final <- readRDS("rds/welfake_final.rds")
wf_final$label <- factor(wf_final$label_name, levels=c("Fake","Real"))
cat("Full WELFake (deduplicated):", nrow(wf_final), "| Fake:", sum(wf_final$label=="Fake"), "Real:", sum(wf_final$label=="Real"), "\n")

set.seed(123)
idx <- createDataPartition(wf_final$label, p=0.8, list=FALSE)
wf_train <- wf_final[idx,]; wf_test <- wf_final[-idx,]
cat("Train:", nrow(wf_train), " Test:", nrow(wf_test), "\n")
stopifnot(length(intersect(wf_train$text, wf_test$text))==0)
cat("Zero train/test overlap verified.\n")

train_corpus <- VCorpus(VectorSource(wf_train$text_final))
train_dtm <- DocumentTermMatrix(train_corpus)
train_dtm_pruned <- removeSparseTerms(train_dtm, 0.99)
cat("Terms surviving pruning:", ncol(train_dtm_pruned), "\n")
term_freq <- slam::col_sums(train_dtm_pruned)
vocab500 <- names(sort(term_freq, decreasing=TRUE))[1:500]
rm(train_dtm, train_dtm_pruned, train_corpus, term_freq); gc()

build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control=list(dictionary=vocab))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab, colnames(mat))
  if (length(missing_cols)>0) { addmat <- matrix(0,nrow=nrow(mat),ncol=length(missing_cols),dimnames=list(NULL,missing_cols)); mat <- cbind(mat,addmat) }
  mat[, vocab, drop=FALSE]
}
train_bow <- build_bow(wf_train$text_final, vocab500)
test_bow <- build_bow(wf_test$text_final, vocab500)

N_train <- nrow(train_bow); df_train <- colSums(train_bow>0)
idf <- log2(N_train/df_train); idf[is.infinite(idf)] <- 0
tfidf_from_bow <- function(bow, idfv) { rs<-rowSums(bow); rs[rs==0]<-1; sweep(bow/rs,2,idfv,`*`) }
train_tfidf <- tfidf_from_bow(train_bow, idf)
test_tfidf <- tfidf_from_bow(test_bow, idf)

FIXED_LAMBDA <- 4.641589e-4
y_train_bin <- ifelse(wf_train$label=="Real",1,0)

cat("\n== LR ==\n")
lr_bow <- glmnet(train_bow, y_train_bin, family="binomial", alpha=1, lambda=FIXED_LAMBDA)
pred_lr_bow <- ifelse(as.numeric(predict(lr_bow, newx=test_bow, type="response"))>0.5,"Real","Fake")
acc_lr_bow <- mean(pred_lr_bow==as.character(wf_test$label))
cat("LR-BoW accuracy:", acc_lr_bow, "\n")

lr_tfidf <- glmnet(train_tfidf, y_train_bin, family="binomial", alpha=1, lambda=FIXED_LAMBDA)
pred_lr_tfidf <- ifelse(as.numeric(predict(lr_tfidf, newx=test_tfidf, type="response"))>0.5,"Real","Fake")
acc_lr_tfidf <- mean(pred_lr_tfidf==as.character(wf_test$label))
cat("LR-TFIDF accuracy:", acc_lr_tfidf, "\n")

cat("\n== NB ==\n")
nb_bow <- naive_bayes(x=as.data.frame(train_bow), y=wf_train$label, laplace=0, usekernel=FALSE)
pred_nb_bow <- predict(nb_bow, as.data.frame(test_bow))
acc_nb_bow <- mean(pred_nb_bow==wf_test$label)
cat("NB-BoW accuracy:", acc_nb_bow, "\n")

nb_tfidf <- naive_bayes(x=as.data.frame(train_tfidf), y=wf_train$label, laplace=0, usekernel=FALSE)
pred_nb_tfidf <- predict(nb_tfidf, as.data.frame(test_tfidf))
acc_nb_tfidf <- mean(pred_nb_tfidf==wf_test$label)
cat("NB-TFIDF accuracy:", acc_nb_tfidf, "\n")

beta <- as.matrix(lr_bow$beta)
ord <- order(-abs(beta[,1]))
cat("\nTop 10 full-WELFake LR-BoW coefficients:\n")
print(data.frame(token=rownames(beta)[ord][1:10], coef=beta[ord,1][1:10]))

saveRDS(list(acc_lr_bow=acc_lr_bow, acc_lr_tfidf=acc_lr_tfidf, acc_nb_bow=acc_nb_bow, acc_nb_tfidf=acc_nb_tfidf,
             lr_bow=lr_bow), "rds/welfake_full_train_results.rds")
cat("\nDone.\n")
