suppressMessages({ library(tm) })
# Why does the ISOT model drop to ~79% on WELFake? Test the artifact hypothesis
# directly: split WELFake Real/Fake docs by whether they contain the ISOT
# model's top Real-artifact tokens (reuter / any weekday), and compare recall.
res <- readRDS("rds/isot_to_welfake_transfer_results.rds")
split_v2 <- readRDS("rds/welfake_minus_overlap_split_v2.rds")
wf <- rbind(split_v2$wfm_train, split_v2$wfm_test)
stopifnot(nrow(wf) == length(res$pred_bow))
tok <- strsplit(wf$text_final, "\\s+")
has_reuter <- vapply(tok, function(w) "reuter" %in% w, logical(1))
wd <- c("monday","tuesday","wednesday","thursday","friday","saturday","sunday")
has_wd <- vapply(tok, function(w) any(wd %in% w), logical(1))
has_art <- has_reuter | has_wd
correct <- res$pred_bow == res$actual
for (cls in c("Real","Fake")) {
  cat(sprintf("\n--- WELFake %s docs (n=%d) ---\n", cls, sum(res$actual==cls)))
  for (g in list(list("contains 'reuter'", has_reuter), list("contains reuter OR a weekday", has_art), list("contains NEITHER", !has_art))) {
    m <- res$actual==cls & g[[2]]
    cat(sprintf("  %-30s n=%6d (%.1f%% of class)  accuracy=%.4f\n", g[[1]], sum(m), 100*sum(m)/sum(res$actual==cls), mean(correct[m])))
  }
}
saveRDS(list(has_reuter=has_reuter, has_art=has_art), "rds/transfer_mechanism.rds")
