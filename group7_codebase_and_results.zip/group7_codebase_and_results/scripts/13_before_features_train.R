suppressMessages({ library(tm); library(caret); library(glmnet); library(naivebayes) })

bp <- readRDS("rds/before_pipeline_docs.rds")
before_train <- bp$before_train; before_test <- bp$before_test

train_corpus <- VCorpus(VectorSource(before_train$text_final))
train_dtm <- DocumentTermMatrix(train_corpus)
train_dtm_pruned <- removeSparseTerms(train_dtm, 0.99)
cat("Before-pipeline terms surviving pruning:", ncol(train_dtm_pruned), "\n")
train_mat <- as.matrix(train_dtm_pruned)
term_freq <- colSums(train_mat)
vocab500_before <- names(sort(term_freq, decreasing=TRUE))[1:500]

build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control=list(dictionary=vocab))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab, colnames(mat))
  if (length(missing_cols)>0) { addmat <- matrix(0,nrow=nrow(mat),ncol=length(missing_cols),dimnames=list(NULL,missing_cols)); mat <- cbind(mat,addmat) }
  mat[, vocab, drop=FALSE]
}

before_train_bow <- build_bow(before_train$text_final, vocab500_before)
before_test_bow  <- build_bow(before_test$text_final, vocab500_before)

N_train <- nrow(before_train_bow); df_train <- colSums(before_train_bow>0)
idf <- log2(N_train/df_train); idf[is.infinite(idf)] <- 0
tfidf_from_bow <- function(bow, idfv) { rs <- rowSums(bow); rs[rs==0]<-1; sweep(bow/rs, 2, idfv, `*`) }
before_train_tfidf <- tfidf_from_bow(before_train_bow, idf)
before_test_tfidf  <- tfidf_from_bow(before_test_bow, idf)

y_train <- ifelse(before_train$label=="Real",1,0)
# Train lightweight glmnet LR at same lambda grid via cv.glmnet for speed, pick lambda minimizing CV deviance closest to paper's approach (5-fold CV, grid 1e-4 to 1e-1, 10 pts)
lambda_grid <- 10^seq(log10(1e-4), log10(1e-1), length.out=10)

fit_lr <- function(X, y, seed=123) {
  set.seed(seed)
  cvfit <- cv.glmnet(X, y, family="binomial", alpha=1, lambda=lambda_grid, nfolds=5, type.measure="class")
  best_lambda <- cvfit$lambda.min
  final <- glmnet(X, y, family="binomial", alpha=1, lambda=best_lambda)
  list(fit=final, lambda=best_lambda)
}

lr_bow_before <- fit_lr(before_train_bow, y_train)
lr_tfidf_before <- fit_lr(before_train_tfidf, y_train)
cat("Before LR-BoW lambda:", lr_bow_before$lambda, " LR-TFIDF lambda:", lr_tfidf_before$lambda, "\n")

eval_acc <- function(fit, X, y_true_label) {
  p <- as.numeric(predict(fit, newx=X, type="response"))
  pred <- ifelse(p>0.5,"Real","Fake")
  mean(pred == y_true_label)
}
acc_lr_bow_before <- eval_acc(lr_bow_before$fit, before_test_bow, as.character(before_test$label))
acc_lr_tfidf_before <- eval_acc(lr_tfidf_before$fit, before_test_tfidf, as.character(before_test$label))
cat("LR-BoW before-pipeline test accuracy:", acc_lr_bow_before, "\n")
cat("LR-TFIDF before-pipeline test accuracy:", acc_lr_tfidf_before, "\n")

# Naive Bayes via caret (quick, no heavy CV needed for sanity - use direct naive_bayes package)
nb_bow_fit <- naive_bayes(x=as.data.frame(before_train_bow), y=factor(before_train$label), laplace=0, usekernel=FALSE)
nb_tfidf_fit <- naive_bayes(x=as.data.frame(before_train_tfidf), y=factor(before_train$label), laplace=0, usekernel=FALSE)
acc_nb_bow <- mean(predict(nb_bow_fit, as.data.frame(before_test_bow)) == before_test$label)
acc_nb_tfidf <- mean(predict(nb_tfidf_fit, as.data.frame(before_test_tfidf)) == before_test$label)
cat("NB-BoW before-pipeline test accuracy:", acc_nb_bow, "\n")
cat("NB-TFIDF before-pipeline test accuracy:", acc_nb_tfidf, "\n")

saveRDS(list(vocab500_before=vocab500_before, lr_bow_before=lr_bow_before, lr_tfidf_before=lr_tfidf_before,
             nb_bow_fit=nb_bow_fit, nb_tfidf_fit=nb_tfidf_fit, idf=idf,
             acc_lr_bow_before=acc_lr_bow_before, acc_lr_tfidf_before=acc_lr_tfidf_before,
             acc_nb_bow=acc_nb_bow, acc_nb_tfidf=acc_nb_tfidf),
        "rds/before_models.rds")
cat("Saved before_models.rds\n")
