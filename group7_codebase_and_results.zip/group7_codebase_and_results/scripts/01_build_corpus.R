# Rebuild ISOT corpus: load, combine, dedup, dateline-strip, shuffle, clean
suppressMessages({
  library(dplyr); library(stringr); library(tm); library(SnowballC)
})

set.seed(123)

true_df <- read.csv("data/True.csv", stringsAsFactors = FALSE, encoding = "UTF-8")
fake_df <- read.csv("data/Fake.csv", stringsAsFactors = FALSE, encoding = "UTF-8")

cat("Raw counts: True=", nrow(true_df), " Fake=", nrow(fake_df), " Total=", nrow(true_df)+nrow(fake_df), "\n")

true_df$label <- "Real"
fake_df$label <- "Fake"
combined <- rbind(true_df, fake_df)
cat("Combined raw rows:", nrow(combined), "\n")

# --- Deduplication (exact text match, first occurrence kept) ---
dup_idx <- duplicated(combined$text)
n_dup <- sum(dup_idx)
cat("Exact-duplicate rows:", n_dup, sprintf("(%.2f%%)\n", 100*n_dup/nrow(combined)))
dup_by_label <- table(combined$label[dup_idx])
print(dup_by_label)

deduped <- combined[!dup_idx, ]
cat("After dedup:", nrow(deduped), " | Fake:", sum(deduped$label=="Fake"), " Real:", sum(deduped$label=="Real"), "\n")

# --- Dateline stripping: "City (Reuters) -- " pattern ---
deduped$text <- str_replace(deduped$text, "^[A-Za-z\\.,' ]+\\(Reuters\\)\\s*-\\s*", "")

# --- Shuffle ---
deduped <- deduped[sample(nrow(deduped)), ]

saveRDS(deduped, "rds/deduped_raw.rds")
cat("Saved deduped_raw.rds with", nrow(deduped), "rows\n")
