suppressMessages(library(tm))
# Combine the 37_xai_expanded.R chunks and summarize, with 95% percentile
# bootstrap CIs (B=2000, resampling documents) and paired tests.
set.seed(2025); B <- 2000
ci <- function(v) quantile(v, c(.025, .975), names = FALSE)
pb <- function(d) 2 * min(mean(d <= 0), mean(d >= 0))
bmean <- function(v) replicate(B, mean(v[sample.int(length(v), length(v), TRUE)]))

files <- sort(list.files("rds", pattern = "^xai_expanded_chunk_.*\\.rds$", full.names = TRUE))
docs <- do.call(c, lapply(files, readRDS))
stopifnot(length(docs) == 300, !anyDuplicated(sapply(docs, `[[`, "idx")))
strat <- sapply(docs, `[[`, "stratum")
cat("Documents:", length(docs), "\n"); print(table(strat))

## ---- normalized AOPC per document ----
aopc <- t(sapply(docs, function(d) colMeans(d$conf)))          # docs x 4 methods, mean over k=1..10
naopc <- aopc[, c("exact","shap","lime")] - aopc[, "random"]
summ <- function(sel, label) {
  cat(sprintf("\n=== Normalized AOPC, %s (n=%d) ===\n", label, sum(sel)))
  X <- naopc[sel, , drop = FALSE]
  for (m in colnames(X)) { b <- bmean(X[, m]); cat(sprintf("  %-6s %.4f [%.4f, %.4f]\n", m, mean(X[, m]), ci(b)[1], ci(b)[2])) }
  for (p in list(c("exact","shap"), c("exact","lime"), c("lime","shap"))) {
    dv <- X[, p[1]] - X[, p[2]]; b <- bmean(dv)
    w <- suppressWarnings(wilcox.test(X[, p[1]], X[, p[2]], paired = TRUE))$p.value
    cat(sprintf("  %-5s - %-5s %+.4f [%+.4f, %+.4f]  bootstrap p=%.4f  Wilcoxon p=%.4g\n", p[1], p[2], mean(dv), ci(b)[1], ci(b)[2], pb(b), w))
  }
}
summ(rep(TRUE, length(docs)), "all 300 documents")
summ(strat != "Misclassified", "correctly classified (240)")
summ(strat == "Misclassified", "misclassified (60)")

## ---- LIME same-document stability ----
is_st <- sapply(docs, `[[`, "stability_doc")
jac <- sapply(docs[is_st], `[[`, "stab_jaccard"); sst <- strat[is_st]
cat(sprintf("\n=== Text-mode LIME same-document stability @5,000 perms, 5 repeats (n=%d docs) ===\n", length(jac)))
b <- bmean(jac); cat(sprintf("  All:            %.4f [%.4f, %.4f]\n", mean(jac), ci(b)[1], ci(b)[2]))
for (s in c("Real-correct","Fake-correct","Misclassified")) {
  v <- jac[sst == s]; b <- bmean(v); cat(sprintf("  %-15s %.4f [%.4f, %.4f] (n=%d)\n", s, mean(v), ci(b)[1], ci(b)[2], length(v)))
}
cat(sprintf("  Docs with perfect agreement across all 5 repeats (Jaccard=1): %d of %d\n", sum(jac == 1), length(jac)))
cat(sprintf("  Docs below 0.5: %d of %d\n", sum(jac < 0.5), length(jac)))

# random baseline on THIS sample: two independent random top-10 draws from each doc's own present words
core <- readRDS("rds/lime_text_core.rds"); test_docs <- readRDS("rds/test_docs_light.rds")
vocab500 <- readRDS("rds/vocab500.rds")   # preprocess_bow() looks this up in the global env
rb <- unlist(lapply(docs[is_st], function(d) {
  pw <- names(which(core$preprocess_bow(test_docs$text_final[d$idx])[1, ] > 0))
  replicate(40, { a <- sample(pw, 10); bb <- sample(pw, 10); length(intersect(a, bb)) / length(union(a, bb)) })
}))
cat(sprintf("  Random present-word baseline on this sample: %.4f (n=%d pairs)\n", mean(rb), length(rb)))

## ---- replication check vs the original samples ----
cat("\n=== Replication vs. original samples ===\n")
cat("  Original: normalized AOPC exact/shap/lime = 0.1565 / 0.1383 / 0.1542 (n=97); stability @5000 = 0.8899 (n=20)\n")
cat(sprintf("  Expanded: normalized AOPC exact/shap/lime = %.4f / %.4f / %.4f (n=300); stability @5000 = %.4f (n=%d)\n",
            mean(naopc[, "exact"]), mean(naopc[, "shap"]), mean(naopc[, "lime"]), mean(jac), length(jac)))
saveRDS(list(naopc = naopc, strat = strat, jac = jac, jac_strat = sst, random_baseline = rb), "rds/xai_expanded_summary.rds")
cat("\nDone.\n")
