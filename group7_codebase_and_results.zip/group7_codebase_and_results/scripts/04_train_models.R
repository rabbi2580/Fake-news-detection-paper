suppressMessages({
  library(dplyr); library(caret); library(glmnet); library(naivebayes)
})

feat <- readRDS("rds/features.rds")
train_docs <- feat$train_docs; test_docs <- feat$test_docs

compute_metrics <- function(pred, actual, positive="Real") {
  cm <- confusionMatrix(factor(pred, levels=c("Fake","Real")), factor(actual, levels=c("Fake","Real")), positive=positive)
  list(cm=cm, accuracy=cm$overall["Accuracy"], f1=cm$byClass["F1"])
}

set.seed(123)
cv_ctrl <- trainControl(method="cv", number=5)

results <- list()

run_combo <- function(train_X, test_X, train_y, test_y, model_type, repr_name) {
  set.seed(123)
  df_train <- data.frame(train_X, label=train_y, check.names = FALSE)
  if (model_type == "nb") {
    fit <- train(label ~ ., data=df_train, method="naive_bayes",
                 trControl=cv_ctrl, tuneGrid=data.frame(laplace=0, usekernel=FALSE, adjust=1))
  } else {
    lambda_grid <- 10^seq(log10(1e-4), log10(1e-1), length.out=10)
    fit <- train(label ~ ., data=df_train, method="glmnet", family="binomial",
                 trControl=cv_ctrl, tuneGrid=expand.grid(alpha=1, lambda=lambda_grid))
  }
  df_test <- data.frame(test_X, check.names=FALSE)
  pred <- predict(fit, df_test)
  m <- compute_metrics(pred, test_y)
  cat(sprintf("%s %s: Accuracy=%.4f F1=%.4f\n", model_type, repr_name, m$accuracy, m$f1))
  if (model_type == "lr") cat("  Selected lambda:", fit$bestTune$lambda, "\n")
  list(fit=fit, pred=pred, metrics=m)
}

results$nb_bow <- run_combo(feat$train_bow, feat$test_bow, train_docs$label, test_docs$label, "nb", "BoW")
results$nb_tfidf <- run_combo(feat$train_tfidf, feat$test_tfidf, train_docs$label, test_docs$label, "nb", "TFIDF")
results$lr_bow <- run_combo(feat$train_bow, feat$test_bow, train_docs$label, test_docs$label, "lr", "BoW")
results$lr_tfidf <- run_combo(feat$train_tfidf, feat$test_tfidf, train_docs$label, test_docs$label, "lr", "TFIDF")

saveRDS(results, "rds/model_results.rds")
cat("Saved model_results.rds\n")
