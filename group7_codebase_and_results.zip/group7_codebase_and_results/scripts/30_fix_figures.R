outdir <- "paper/figures"

## ---- Fig 1: accuracy_comparison.png (corrected canonical numbers) ----
acc <- c(0.8792, 0.9013, 0.9738, 0.9740)
labs <- c("NB\nBoW", "NB\nTF-IDF", "LR\nBoW", "LR\nTF-IDF")
png(file.path(outdir, "accuracy_comparison.png"), width=1000, height=700, res=150)
par(mar=c(4,5,2,1))
bp <- barplot(acc, names.arg=labs, ylim=c(0,1), col=c("#9ecae1","#9ecae1","#3182bd","#3182bd"),
              ylab="Test accuracy", main="Test accuracy by model and representation", cex.names=1.0, cex.axis=1.0)
text(bp, acc+0.03, sprintf("%.4f", acc), cex=0.9)
dev.off()
cat("Saved accuracy_comparison.png (corrected)\n")

## ---- leakage_ablation_barplot.png (corrected: 8 tokens, canonical baseline) ----
acc_full <- c(0.9738, 0.9740)
acc_abl  <- c(0.9594, 0.9653)
m <- rbind(acc_full, acc_abl)
colnames(m) <- c("BoW","TF-IDF")
png(file.path(outdir, "leakage_ablation_barplot.png"), width=900, height=700, res=150)
par(mar=c(4,5,2,1))
bp <- barplot(m, beside=TRUE, ylim=c(0.9,1.0), col=c("#3182bd","#de2d26"),
              ylab="Test accuracy", main="Logistic Regression accuracy before/after\nremoving 8 leakage tokens",
              legend.text=c("Full vocabulary","8 tokens removed"), args.legend=list(x="bottomleft", bty="n", cex=0.85))
text(bp, m+0.003, sprintf("%.4f", m), cex=0.8)
dev.off()
cat("Saved leakage_ablation_barplot.png (corrected)\n")
