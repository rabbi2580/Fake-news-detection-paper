suppressMessages({ library(LiblineaR); library(caret) })

# Linear SVM baseline (L2-regularized, L2-loss SVC; LiblineaR type=2) on the
# SAME train/test split and the SAME 500-term BoW / TF-IDF features as the
# canonical Naive Bayes / Logistic Regression models (04_train_models.R).
# Cost C is chosen by 5-fold CV on the training set only.

set.seed(123)
feat <- readRDS("rds/features.rds")
y_tr <- factor(feat$train_docs$label, levels = c("Fake","Real"))
y_te <- as.character(feat$test_docs$label)
res_lr <- readRDS("rds/model_results.rds")

costs <- c(0.001, 0.01, 0.1, 1, 10, 100)  # extended after C=10 was the grid edge for TF-IDF
run_svm <- function(Xtr, Xte, name) {
  cat(sprintf("\n== Linear SVM, %s ==\n", name))
  cv_acc <- sapply(costs, function(C) { set.seed(123); LiblineaR(Xtr, y_tr, type = 2, cost = C, cross = 5) })
  for (i in seq_along(costs)) cat(sprintf("  C=%-6g 5-fold CV accuracy=%.4f\n", costs[i], cv_acc[i]))
  bestC <- costs[which.max(cv_acc)]
  fit <- LiblineaR(Xtr, y_tr, type = 2, cost = bestC)
  pred <- as.character(predict(fit, Xte)$predictions)
  cm <- confusionMatrix(factor(pred, levels = c("Fake","Real")), factor(y_te, levels = c("Fake","Real")), positive = "Real")
  cat(sprintf("  Selected C=%g  Test accuracy=%.4f  F1=%.4f\n", bestC, cm$overall["Accuracy"], cm$byClass["F1"]))
  list(fit = fit, pred = pred, acc = unname(cm$overall["Accuracy"]), f1 = unname(cm$byClass["F1"]), C = bestC)
}

svm_bow   <- run_svm(feat$train_bow,   feat$test_bow,   "BoW")
svm_tfidf <- run_svm(feat$train_tfidf, feat$test_tfidf, "TF-IDF")

cat("\n== McNemar: SVM vs. Logistic Regression (same representation) ==\n")
for (r in c("bow","tfidf")) {
  s <- get(paste0("svm_", r))$pred == y_te
  l <- as.character(res_lr[[paste0("lr_", r)]]$pred) == y_te
  mc <- mcnemar.test(table(s, l))
  cat(sprintf("  %-5s SVM %.4f vs LR %.4f   discordant: SVM-only-correct=%d, LR-only-correct=%d, p=%.4g\n",
              r, mean(s), mean(l), sum(s & !l), sum(!s & l), mc$p.value))
}

saveRDS(list(svm_bow = svm_bow[c("fit","pred","acc","f1","C")], svm_tfidf = svm_tfidf[c("fit","pred","acc","f1","C")]),
        "rds/svm_results.rds")
cat("\nDone.\n")
