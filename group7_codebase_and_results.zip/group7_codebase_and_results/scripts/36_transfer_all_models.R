suppressMessages({ library(tm); library(caret); library(glmnet); library(LiblineaR); library(xgboost); library(naivebayes) })

# Cross-dataset transfer for EVERY ISOT-trained BoW model, plus the
# 8-token-ablated Logistic Regression: each is trained on ISOT only, with
# ISOT's fixed 500-term vocabulary, and scored on the WELFake v2
# overlap-filtered set (n=42,448; no exact/normalized/near-duplicate ISOT
# article in it). Two questions:
#   (a) does a stronger in-distribution model (XGBoost) also transfer better?
#   (b) does removing the source-artifact tokens HELP transfer?
# 95% percentile bootstrap CIs (B=2000) over WELFake documents; paired
# differences vs. the canonical LR-BoW on the same resampled documents.

set.seed(2024); B <- 2000
ci <- function(v) quantile(v, c(.025, .975), names = FALSE)

feat <- readRDS("rds/features.rds")
vocab500 <- feat$vocab500
artifact <- c("reuter","monday","tuesday","wednesday","thursday","friday","saturday","sunday")
keep <- setdiff(vocab500, artifact)
rm(feat); invisible(gc())

sp <- readRDS("rds/welfake_minus_overlap_split_v2.rds")
wf <- rbind(sp$wfm_train, sp$wfm_test); act <- as.character(wf$label)
corpus <- VCorpus(VectorSource(wf$text_final))
dtm <- DocumentTermMatrix(corpus, control = list(dictionary = vocab500))[, vocab500]
stopifnot(identical(colnames(dtm), vocab500))
X <- as.matrix(dtm); rm(corpus, dtm); invisible(gc())
cat("WELFake v2 transfer set:", nrow(X), "docs;", round(100*mean(act=="Real"),1), "% Real (majority baseline)\n\n")

preds <- list()
# memory-lean: pull only the small fitted NB model out of the 185MB results object
nb_fm <- readRDS("rds/model_results.rds")$nb_bow$fit$finalModel; invisible(gc())
Xdf <- data.frame(X, check.names = FALSE)
# caret's formula interface stored the R-reserved-word term "next" as "`next`"; match that name so the
# bare finalModel uses all 500 features (verified: gives predictions identical to caret's predict on ISOT test)
Xnb <- Xdf; names(Xnb)[names(Xnb) == "next"] <- "`next`"
preds$`NB (BoW)` <- as.character(predict(nb_fm, Xnb)); rm(nb_fm, Xnb); invisible(gc())
lr_fit <- readRDS("rds/lr_bow_fit.rds")        # canonical Table I model (same object as model_results$lr_bow$fit)
preds$`LR (BoW), canonical` <- as.character(predict(lr_fit, Xdf)); rm(lr_fit, Xdf); invisible(gc())
svm <- readRDS("rds/svm_results.rds")$svm_bow$fit
preds$`Linear SVM (BoW)` <- as.character(predict(svm, X)$predictions)
xgbm <- xgb.load("rds/xgb_model_bow.ubj")
preds$`XGBoost (BoW)` <- ifelse(predict(xgbm, xgb.DMatrix(X)) > 0.5, "Real", "Fake")
abl <- readRDS("rds/leakage_ablation_dedup.rds")
preds$`LR (BoW), 8 artifact tokens removed` <- as.character(predict(abl$fit_abl_bow, data.frame(X[, keep], check.names = FALSE)))

balacc <- function(p, a) (mean(p[a=="Real"]=="Real") + mean(p[a=="Fake"]=="Fake")) / 2
mcc <- function(p, a) { tp <- as.numeric(sum(p=="Real"&a=="Real")); tn <- as.numeric(sum(p=="Fake"&a=="Fake"))
  fp <- as.numeric(sum(p=="Real"&a=="Fake")); fn <- as.numeric(sum(p=="Fake"&a=="Real"))
  (tp*tn-fp*fn)/sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) }

n <- length(act)
ref <- preds$`LR (BoW), canonical` == act
# one shared set of bootstrap resamples for all models (paired), generated on the fly -- no n x B index matrix in memory
Cm <- sapply(preds, function(p) p == act); Pm <- sapply(preds, function(p) p == "Real"); isReal <- act == "Real"
boot <- array(NA_real_, dim = c(B, length(preds), 3), dimnames = list(NULL, names(preds), c("acc","bal","diff")))
for (b in 1:B) {
  i <- sample.int(n, n, TRUE); r <- isReal[i]
  acc <- colMeans(Cm[i, , drop = FALSE])
  bal <- (colMeans(Pm[i, , drop = FALSE][r, , drop = FALSE]) + colMeans(!Pm[i, , drop = FALSE][!r, , drop = FALSE])) / 2
  boot[b, , ] <- cbind(acc, bal, acc - mean(ref[i]))
}
tab <- data.frame()
cat(sprintf("%-38s %-24s %-24s %-7s %s\n", "Model (ISOT-trained)", "Accuracy [95% CI]", "Balanced acc [95% CI]", "MCC", "Acc - LR canonical [95% CI]"))
for (nm in names(preds)) {
  p <- preds[[nm]]; c1 <- p == act
  ba <- boot[, nm, "acc"]; bb <- boot[, nm, "bal"]; bd <- boot[, nm, "diff"]
  cat(sprintf("%-38s %.4f [%.4f, %.4f]  %.4f [%.4f, %.4f]  %.4f  %+.2f [%+.2f, %+.2f] pts\n", nm,
              mean(c1), ci(ba)[1], ci(ba)[2], balacc(p, act), ci(bb)[1], ci(bb)[2], mcc(p, act),
              100*(mean(c1)-mean(ref)), 100*ci(bd)[1], 100*ci(bd)[2]))
  tab <- rbind(tab, data.frame(model = nm, acc = mean(c1), acc_lo = ci(ba)[1], acc_hi = ci(ba)[2],
                               balacc = balacc(p, act), bal_lo = ci(bb)[1], bal_hi = ci(bb)[2], mcc = mcc(p, act),
                               real_recall = mean(p[act=="Real"]=="Real"), fake_recall = mean(p[act=="Fake"]=="Fake"),
                               d_vs_lr = mean(c1)-mean(ref), d_lo = ci(bd)[1], d_hi = ci(bd)[2]))
}
cat("\nPer-class recall:\n"); print(tab[, c("model","real_recall","fake_recall")], row.names = FALSE, digits = 4)
saveRDS(list(table = tab, preds = preds, actual = act), "rds/transfer_all_models.rds")
cat("\nDone.\n")
