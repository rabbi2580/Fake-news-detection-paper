suppressMessages({ library(stringr) })

# Strengthened ISOT<->WELFake overlap audit. The original 15_overlap_check.R
# computed exact full-text match AND a 200-char-prefix near-duplicate match,
# but the prefix-match number was never actually used to build the
# "overlap-free" WFM subset (17_welfake_minus_overlap_split.R used only the
# exact-match flag) -- so near-duplicate articles may have leaked into what
# was called an "overlap-free" retrain. This script re-derives the overlap
# flag using THREE criteria and reports how much each one additionally
# catches, so the paper can state precisely which notion of "overlap" the
# retrained subset actually excludes.

isot_final <- readRDS("rds/final_corpus.rds")
wf_deduped <- readRDS("rds/welfake_deduped.rds")

cat("ISOT final:", nrow(isot_final), " WELFake deduped:", nrow(wf_deduped), "\n")

isot_text <- isot_final$text
wf_text <- wf_deduped$text

# ---- Criterion 1: exact raw-text match (as in 15_overlap_check.R) ----
exact_match <- isot_text %in% wf_text
wf_exact_match <- wf_text %in% isot_text
cat(sprintf("\n[1] Exact raw-text match: %d ISOT docs (%.2f%%), %d WELFake docs (%.2f%%)\n",
            sum(exact_match), 100*mean(exact_match), sum(wf_exact_match), 100*mean(wf_exact_match)))

# ---- Criterion 2: normalized-text exact match ----
# lowercase, collapse whitespace, strip punctuation -- catches docs that
# differ only in capitalization/spacing/punctuation but are otherwise identical.
normalize_text <- function(x) {
  x <- tolower(x)
  x <- str_replace_all(x, "[^a-z0-9\\s]", " ")
  x <- str_replace_all(x, "\\s+", " ")
  str_trim(x)
}
isot_norm <- normalize_text(isot_text)
wf_norm <- normalize_text(wf_text)
norm_match <- isot_norm %in% wf_norm
wf_norm_match <- wf_norm %in% isot_norm
cat(sprintf("[2] Normalized-text exact match: %d ISOT docs (%.2f%%), %d WELFake docs (%.2f%%)\n",
            sum(norm_match), 100*mean(norm_match), sum(wf_norm_match), 100*mean(wf_norm_match)))
cat(sprintf("    Additional ISOT docs caught beyond [1]: %d\n", sum(norm_match & !exact_match)))

# ---- Criterion 3: near-duplicate via 200-char normalized-prefix match (bidirectional) ----
isot_prefix <- substr(isot_norm, 1, 200)
wf_prefix <- substr(wf_norm, 1, 200)
prefix_match <- isot_prefix %in% wf_prefix
wf_prefix_match <- wf_prefix %in% isot_prefix
cat(sprintf("[3] 200-char normalized-prefix match: %d ISOT docs (%.2f%%), %d WELFake docs (%.2f%%)\n",
            sum(prefix_match), 100*mean(prefix_match), sum(wf_prefix_match), 100*mean(wf_prefix_match)))
cat(sprintf("    Additional ISOT docs caught beyond [1]+[2]: %d\n", sum(prefix_match & !exact_match & !norm_match)))

# ---- Criterion 4: near-duplicate via 100-char normalized-prefix (looser, sanity bound) ----
isot_prefix100 <- substr(isot_norm, 1, 100)
wf_prefix100 <- substr(wf_norm, 1, 100)
prefix100_match <- isot_prefix100 %in% wf_prefix100
wf_prefix100_match <- wf_prefix100 %in% isot_prefix100
cat(sprintf("[4] 100-char normalized-prefix match: %d ISOT docs (%.2f%%), %d WELFake docs (%.2f%%)\n",
            sum(prefix100_match), 100*mean(prefix100_match), sum(wf_prefix100_match), 100*mean(wf_prefix100_match)))

# ---- Union: the flag actually used going forward ----
union_match <- exact_match | norm_match | prefix_match
wf_union_match <- wf_exact_match | wf_norm_match | wf_prefix_match
cat(sprintf("\n[UNION of 1+2+3] ISOT docs flagged as overlapping WELFake: %d (%.2f%%)\n",
            sum(union_match), 100*mean(union_match)))
cat(sprintf("[UNION of 1+2+3] WELFake docs flagged as overlapping ISOT: %d (%.2f%%)\n",
            sum(wf_union_match), 100*mean(wf_union_match)))

cat(sprintf("\nBy class (ISOT side), exact match: Fake %.2f%%  Real %.2f%%\n",
            100*mean(exact_match[isot_final$label=="Fake"]), 100*mean(exact_match[isot_final$label=="Real"])))
cat(sprintf("By class (ISOT side), union match:  Fake %.2f%%  Real %.2f%%\n",
            100*mean(union_match[isot_final$label=="Fake"]), 100*mean(union_match[isot_final$label=="Real"])))

saveRDS(list(exact_match=exact_match, wf_exact_match=wf_exact_match,
             norm_match=norm_match, wf_norm_match=wf_norm_match,
             prefix_match=prefix_match, wf_prefix_match=wf_prefix_match,
             prefix100_match=prefix100_match, wf_prefix100_match=wf_prefix100_match,
             union_match=union_match, wf_union_match=wf_union_match),
        "rds/overlap_results_v2.rds")
cat("\nSaved overlap_results_v2.rds\n")
