suppressMessages({ library(stringr); library(dplyr) })

# For every ISOT document that matches a WELFake document (union flag from
# 25_overlap_check_v2.R: exact OR normalized-text OR 200-char normalized
# prefix), do the two corpora assign the SAME label to that article?
# Matching key = 200-char normalized prefix (exact match implies normalized
# match implies prefix match, so this key covers the whole union).

isot <- readRDS("rds/final_corpus.rds")
wf   <- readRDS("rds/welfake_deduped.rds")
ov2  <- readRDS("rds/overlap_results_v2.rds")

normalize_text <- function(x) {
  x <- tolower(x); x <- str_replace_all(x, "[^a-z0-9\\s]", " ")
  x <- str_replace_all(x, "\\s+", " "); str_trim(x)
}
isot_key <- substr(normalize_text(isot$text), 1, 200)
wf_key   <- substr(normalize_text(wf$text), 1, 200)

wf_lab <- data.frame(key = wf_key, wf_label = wf$label_name, stringsAsFactors = FALSE) %>%
  group_by(key) %>%
  summarise(n_wf = n(), wf_labels = paste(sort(unique(wf_label)), collapse = "/"), .groups = "drop")

m <- data.frame(key = isot_key, isot_label = isot$label, matched = ov2$union_match, stringsAsFactors = FALSE) %>%
  filter(matched) %>%
  left_join(wf_lab, by = "key")
stopifnot(!any(is.na(m$wf_labels)))
cat("Matched ISOT docs:", nrow(m), "\n")
cat("  of which match >1 WELFake doc:", sum(m$n_wf > 1), "\n")
cat("  of which matched WELFake docs carry BOTH labels:", sum(m$wf_labels == "Fake/Real"), "\n\n")

m$agree <- ifelse(m$wf_labels == "Fake/Real", NA, m$isot_label == m$wf_labels)

cat("=== Label agreement, ISOT label vs WELFake label for the same article ===\n")
tab <- table(ISOT = m$isot_label, WELFake = m$wf_labels)
print(tab)
cat(sprintf("\nOverall agreement (excluding mixed-label keys): %d / %d = %.2f%%\n",
            sum(m$agree, na.rm = TRUE), sum(!is.na(m$agree)), 100 * mean(m$agree, na.rm = TRUE)))
for (cls in c("Fake", "Real")) {
  s <- m[m$isot_label == cls, ]
  cat(sprintf("  ISOT-%s matched docs: %d, agreement %.2f%%\n", cls, nrow(s), 100 * mean(s$agree, na.rm = TRUE)))
}

# Show a few disagreeing examples (title-level) for qualitative inspection
dis <- which(m$agree %in% FALSE)
if (length(dis)) {
  cat("\nFirst 5 disagreeing ISOT documents (ISOT label -> WELFake label), text prefix:\n")
  for (i in head(dis, 5)) cat(sprintf("  [%s -> %s] %s...\n", m$isot_label[i], m$wf_labels[i], substr(m$key[i], 1, 90)))
}
saveRDS(list(table = tab, matched = m), "rds/overlap_label_agreement.rds")
cat("\nDone.\n")
