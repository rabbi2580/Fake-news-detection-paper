suppressMessages({ library(naivebayes) })
bp <- readRDS("rds/before_pipeline_docs.rds")
before_train <- bp$before_train; before_test <- bp$before_test
before_train_bow <- readRDS("rds/before_train_bow.rds")
before_test_bow <- readRDS("rds/before_test_bow.rds")

nb_bow_fit <- naive_bayes(x=as.data.frame(before_train_bow), y=factor(before_train$label), laplace=0, usekernel=FALSE)
acc_nb_bow <- mean(predict(nb_bow_fit, as.data.frame(before_test_bow)) == before_test$label)
cat("NB-BoW before-pipeline test accuracy:", acc_nb_bow, "\n")
saveRDS(nb_bow_fit, "rds/nb_bow_before.rds")
rm(nb_bow_fit, before_train_bow, before_test_bow); gc()

before_train_tfidf <- readRDS("rds/before_train_tfidf.rds")
before_test_tfidf <- readRDS("rds/before_test_tfidf.rds")
nb_tfidf_fit <- naive_bayes(x=as.data.frame(before_train_tfidf), y=factor(before_train$label), laplace=0, usekernel=FALSE)
acc_nb_tfidf <- mean(predict(nb_tfidf_fit, as.data.frame(before_test_tfidf)) == before_test$label)
cat("NB-TFIDF before-pipeline test accuracy:", acc_nb_tfidf, "\n")
saveRDS(nb_tfidf_fit, "rds/nb_tfidf_before.rds")
cat("Done.\n")
