suppressMessages({ library(lime); library(tm); library(glmnet) })

core <- readRDS("rds/lime_text_core.rds")
glmnet_wrap <- core$glmnet_wrap
preprocess_bow <- core$preprocess_bow
vocab500 <- readRDS("rds/vocab500.rds")
test_docs <- readRDS("rds/test_docs_light.rds")
correct_idx <- readRDS("rds/correct_idx.rds")$correct_idx
lr_bow_glmnet <- readRDS("rds/lr_bow_glmnet.rds")
train_means <- readRDS("rds/train_bow_colmeans.rds")

predict_model.glmnet_wrap <- function(x, newdata, type, ...) {
  p1 <- as.numeric(predict(x$fit, newx = as.matrix(newdata), type = "response"))
  data.frame(Fake = 1 - p1, Real = p1)
}
model_type.glmnet_wrap <- function(x, ...) "classification"
assign("predict_model.glmnet_wrap", predict_model.glmnet_wrap, envir = .GlobalEnv)
assign("model_type.glmnet_wrap", model_type.glmnet_wrap, envir = .GlobalEnv)

beta <- as.numeric(coef(lr_bow_glmnet))[-1]
names(beta) <- rownames(coef(lr_bow_glmnet))[-1]

p_real <- function(bow_row) as.numeric(predict(lr_bow_glmnet, newx = matrix(bow_row, nrow=1, dimnames=list(NULL, vocab500)), type="response"))

set.seed(2024)
real_pool <- correct_idx[test_docs$label[correct_idx] == "Real"]
fake_pool <- correct_idx[test_docs$label[correct_idx] == "Fake"]
samp_idx <- c(sample(real_pool, 50), sample(fake_pool, 50))

explainer_full <- lime(test_docs$text_final[samp_idx], model = glmnet_wrap, preprocess = preprocess_bow)

K <- 10
methods <- c("exact","shap","lime","random")
# arrays: [doc, k, method] absolute |deltaP(Real)|; and signed confidence-drop for AOPC
abs_arr <- array(NA, dim=c(length(samp_idx), K, length(methods)), dimnames=list(NULL, 1:K, methods))
conf_drop_arr <- array(NA, dim=c(length(samp_idx), K, length(methods)), dimnames=list(NULL, 1:K, methods))
n_present_vec <- rep(NA, length(samp_idx))

t_start <- Sys.time()
for (i in seq_along(samp_idx)) {
  idx <- samp_idx[i]
  txt <- test_docs$text_final[idx]
  bow_row <- preprocess_bow(txt)[1,]
  present_words <- names(bow_row)[bow_row > 0]
  n_present_vec[i] <- length(present_words)
  if (length(present_words) < K) next

  orig_p <- p_real(bow_row)
  pred_class <- ifelse(orig_p > 0.5, "Real", "Fake")
  orig_conf <- ifelse(pred_class == "Real", orig_p, 1 - orig_p)

  contrib <- bow_row[present_words] * beta[present_words]
  exact_order <- present_words[order(-abs(contrib))]

  shap_vals <- beta[present_words] * (bow_row[present_words] - train_means[present_words])
  shap_order <- present_words[order(-abs(shap_vals))]

  set.seed(3000+i)
  e <- tryCatch(explain(txt, explainer_full, n_labels=1, n_features=min(K,length(present_words)), n_permutations=5000),
                error=function(e) NULL)
  if (!is.null(e)) {
    lime_order <- intersect(e$feature[order(-abs(e$feature_weight))], present_words)
  } else lime_order <- character(0)

  set.seed(4000+i)
  rand_order <- sample(present_words)

  orders <- list(exact=exact_order, shap=shap_order, lime=lime_order, random=rand_order)
  for (m in methods) {
    word_order <- orders[[m]]
    for (k in 1:K) {
      cols <- intersect(word_order[1:min(k,length(word_order))], vocab500)
      modified <- bow_row
      if (length(cols) > 0) modified[cols] <- 0
      new_p <- p_real(modified)
      new_conf <- ifelse(pred_class == "Real", new_p, 1 - new_p)
      abs_arr[i,k,m] <- abs(orig_p - new_p)
      conf_drop_arr[i,k,m] <- orig_conf - new_conf  # positive = confidence in predicted class dropped (good)
    }
  }
  if (i %% 25 == 0) cat("Processed", i, "/", length(samp_idx), " elapsed:", as.numeric(Sys.time()-t_start,units="secs"), "s\n")
}
cat("Total time:", as.numeric(Sys.time()-t_start,units="secs"), "sec\n")

valid <- n_present_vec >= K
cat("n valid docs (>=10 present words):", sum(valid), "/", length(samp_idx), "\n")

cat("\n=== Mean |deltaP(Real)| deletion curve (top-1..10) ===\n")
curve_abs <- apply(abs_arr[valid,,,drop=FALSE], c(2,3), mean, na.rm=TRUE)
print(round(curve_abs, 4))

cat("\n=== AOPC (mean confidence-drop in predicted class, top-1..10) ===\n")
curve_conf <- apply(conf_drop_arr[valid,,,drop=FALSE], c(2,3), mean, na.rm=TRUE)
print(round(curve_conf, 4))

aopc <- colMeans(curve_conf)
cat("\nAOPC (avg over k=1..10):\n"); print(round(aopc,4))
aopc_norm <- aopc - aopc["random"]
cat("\nNormalized AOPC (AOPC - random-order AOPC):\n"); print(round(aopc_norm,4))

saveRDS(list(abs_arr=abs_arr, conf_drop_arr=conf_drop_arr, n_present_vec=n_present_vec, valid=valid,
             curve_abs=curve_abs, curve_conf=curve_conf, aopc=aopc, aopc_norm=aopc_norm, samp_idx=samp_idx),
        "rds/deletion_curve_full.rds")
