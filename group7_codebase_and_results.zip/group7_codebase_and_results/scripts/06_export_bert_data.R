Sys.setlocale("LC_CTYPE", "C.UTF-8")
feat <- readRDS("rds/features.rds")
train_docs <- feat$train_docs
test_docs <- feat$test_docs

# Full training set (not 4000-doc subsample) - dateline-stripped raw text
train_out <- data.frame(text = train_docs$text, label = ifelse(train_docs$label=="Real", 1L, 0L))
test_out  <- data.frame(text = test_docs$text, label = ifelse(test_docs$label=="Real", 1L, 0L))

cat("Train (full):", nrow(train_out), "| Test:", nrow(test_out), "\n")
stopifnot(length(intersect(train_out$text, test_out$text)) == 0)
cat("Zero train/test overlap: VERIFIED\n")

write.csv(train_out, "data2/bert_train_full.csv", row.names = FALSE, fileEncoding = "UTF-8")
write.csv(test_out, "data2/bert_test.csv", row.names = FALSE, fileEncoding = "UTF-8")

# verify no corruption artifacts
chk <- readLines("data2/bert_train_full.csv", n = 2000, encoding = "UTF-8")
n_bad <- sum(grepl("<U\\+[0-9A-Fa-f]{4}>", chk))
cat("Corruption-pattern check (first 2000 lines):", n_bad, "\n")
