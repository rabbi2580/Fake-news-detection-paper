suppressMessages({ library(lime); library(tm); library(glmnet) })

# Re-derives, on the CURRENT deduplicated-corpus model, the cross-method
# agreement and tabular-path LIME numbers that earlier drafts reported
# (0.859 / 0.020 / 0.083 / 0.011) but that no script in the current pipeline
# produces (they trace to an older pipeline generation). Also adds the
# comparison that was missing: exact coefficients vs. TEXT-MODE LIME.
#
# Part A (agreement, 100 docs = the same 100-doc sample used for AOPC in
#   11_deletion_curve_full.R): top-10 Jaccard between exact present-word
#   contributions, closed-form SHAP (present-word / full-vocabulary),
#   tabular-path LIME (300 perm.) and text-mode LIME (5,000 perm.).
# Part B (stability + collapse, the same 20 docs as 09_lime_text_stability.R):
#   tabular-path LIME, 5 repeats at 300 and 5,000 perm.; cross-document
#   similarity of explanations to test the "collapse to a document-independent
#   ranking" claim, for tabular vs. text mode.
# Usage: Rscript scripts/38_agreement_tabular_rerun.R A <start> <end>   |   Rscript ... B

args <- commandArgs(trailingOnly = TRUE); part <- args[1]
core <- readRDS("rds/lime_text_core.rds"); glmnet_wrap <- core$glmnet_wrap; preprocess_bow <- core$preprocess_bow
vocab500 <- readRDS("rds/vocab500.rds")
test_docs <- readRDS("rds/test_docs_light.rds")
lr <- readRDS("rds/lr_bow_glmnet.rds"); train_means <- readRDS("rds/train_bow_colmeans.rds")
predict_model.glmnet_wrap <- function(x, newdata, type, ...) {
  p1 <- as.numeric(predict(x$fit, newx = as.matrix(newdata), type = "response")); data.frame(Fake = 1 - p1, Real = p1) }
model_type.glmnet_wrap <- function(x, ...) "classification"
assign("predict_model.glmnet_wrap", predict_model.glmnet_wrap, envir = .GlobalEnv)
assign("model_type.glmnet_wrap", model_type.glmnet_wrap, envir = .GlobalEnv)
beta <- as.numeric(coef(lr))[-1]; names(beta) <- rownames(coef(lr))[-1]
J <- function(a, b) length(intersect(a, b)) / length(union(a, b))
top <- function(v, k = 10) names(v)[order(-abs(v))][1:min(k, length(v))]

# Tabular explainer: lime() on the numeric 500-column training BoW matrix, bin_continuous=FALSE
# -- the original misconfiguration this paper diagnoses.
feat <- readRDS("rds/features.rds"); train_df <- as.data.frame(feat$train_bow, check.names = FALSE); rm(feat); invisible(gc())
tab_explainer <- lime(train_df, glmnet_wrap, bin_continuous = FALSE); rm(train_df); invisible(gc())
lime_tab <- function(row, n_perm, seed) { set.seed(seed)
  e <- explain(as.data.frame(t(row), check.names = FALSE), tab_explainer, n_labels = 1, n_features = 10, n_permutations = n_perm)
  e$feature[order(-abs(e$feature_weight))] }

if (part == "A") {
  s0 <- as.integer(args[2]); s1 <- as.integer(args[3])
  samp <- readRDS("rds/deletion_curve_full.rds")$samp_idx
  txt_explainer <- lime(test_docs$text_final[samp], model = glmnet_wrap, preprocess = preprocess_bow)
  out <- list()
  for (i in s0:s1) {
    idx <- samp[i]; txt <- test_docs$text_final[idx]; row <- preprocess_bow(txt)[1, ]
    present <- names(row)[row > 0]; if (length(present) < 10) next
    exact <- top((row * beta)[present]); shap_full_v <- beta * (row - train_means)
    shap_p <- top(shap_full_v[present]); shap_f <- top(shap_full_v)
    ltab <- lime_tab(row, 300, 7000 + i)
    set.seed(8000 + i)
    e <- explain(txt, txt_explainer, n_labels = 1, n_features = 10, n_permutations = 5000)
    ltxt <- e$feature[order(-abs(e$feature_weight))]
    out[[as.character(i)]] <- c(idx = idx, exact_shapP = J(exact, shap_p), exact_shapF = J(exact, shap_f),
                                exact_limeTab = J(exact, ltab), exact_limeText = J(exact, ltxt),
                                shapF_limeTab = J(shap_f, ltab), shapP_limeText = J(shap_p, ltxt))
  }
  saveRDS(do.call(rbind, out), sprintf("rds/agreement_rerun_%03d_%03d.rds", s0, s1))
  cat(sprintf("Part A docs %d-%d done (%d valid)\n", s0, s1, length(out)))
}

if (part == "B") {
  sel <- readRDS("rds/lime_text_sensitivity_sweep.rds"); sel_idx <- sel$sel_idx
  res <- list()
  for (np in c(300, 5000)) {
    t0 <- Sys.time(); tops <- list()
    for (i in seq_along(sel_idx)) {
      row <- preprocess_bow(test_docs$text_final[sel_idx[i]])[1, ]
      tops[[i]] <- lapply(1:5, function(r) lime_tab(row, np, 1000 + i * 100 + r))
    }
    within <- sapply(tops, function(rp) mean(combn(5, 2, function(p) J(rp[[p[1]]], rp[[p[2]]]))))
    first <- lapply(tops, `[[`, 1)
    across <- mean(combn(length(first), 2, function(p) J(first[[p[1]]], first[[p[2]]])))
    n_distinct <- length(unique(lapply(first, sort)))
    cat(sprintf("Tabular LIME %5d perm.: same-doc stability %.4f (sd %.4f, n=%d docs); cross-doc similarity %.4f; distinct top-10 sets %d/20  [%.0fs]\n",
                np, mean(within), sd(within), length(within), across, n_distinct, as.numeric(Sys.time() - t0, units = "secs")))
    res[[paste0("tab_", np)]] <- list(within = within, across = across, n_distinct = n_distinct, first = first)
  }
  for (np in c("5000", "10000")) {
    first <- lapply(sel[[paste0("res_", np)]], function(x) x$repeats[[1]])
    across <- mean(combn(length(first), 2, function(p) J(first[[p[1]]], first[[p[2]]])))
    cat(sprintf("Text-mode LIME %5s perm.: cross-doc similarity %.4f; distinct top-10 sets %d/20\n", np, across, length(unique(lapply(first, sort)))))
    res[[paste0("text_", np)]] <- list(across = across)
  }
  set.seed(99); rb <- replicate(4000, J(sample(vocab500, 10), sample(vocab500, 10)))
  cat(sprintf("Random full-vocabulary baseline (two random 10-of-500 sets): %.4f\n", mean(rb)))
  res$random_full_vocab <- mean(rb)
  saveRDS(res, "rds/tabular_stability_rerun.rds")
}
