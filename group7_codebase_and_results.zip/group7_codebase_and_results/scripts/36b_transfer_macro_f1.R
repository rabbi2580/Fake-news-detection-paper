# Macro-F1 for every ISOT->WELFake transfer model (for comparison with prior
# work that reports macro-F1, e.g. Haroon 2026), with 95% bootstrap CIs.
set.seed(2027); B <- 1000
tr <- readRDS("rds/transfer_all_models.rds"); act <- tr$actual; n <- length(act)
f1c <- function(p, a, cls) { tp <- sum(p==cls & a==cls); fp <- sum(p==cls & a!=cls); fn <- sum(p!=cls & a==cls); 2*tp/(2*tp+fp+fn) }
mf1 <- function(p, a) (f1c(p, a, "Real") + f1c(p, a, "Fake")) / 2
for (nm in names(tr$preds)) {
  p <- tr$preds[[nm]]
  b <- replicate(B, { i <- sample.int(n, n, TRUE); mf1(p[i], act[i]) }); q <- quantile(b, c(.025, .975))
  cat(sprintf("%-38s macro-F1 %.4f [%.4f, %.4f]\n", nm, mf1(p, act), q[1], q[2]))
}
