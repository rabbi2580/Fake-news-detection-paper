suppressMessages({ library(glmnet); library(caret) })

# Logs every paper number that was previously computed only interactively,
# so each one is reproducible from a script + log:
#   Table II confusion matrices, error-asymmetry binomial tests, Holm-corrected
#   McNemar tests (NB vs LR family), Table III top coefficients (ranked),
#   ablation weight shifts, and the number of test predictions on which the
#   caret-CV model (Table I) and the direct glmnet refit (explanations) differ.

res  <- readRDS("rds/model_results.rds")
feat <- readRDS("rds/features.rds")
y <- factor(feat$test_docs$label, levels = c("Fake","Real"))

cat("=== Table II: confusion matrices (rows = predicted, cols = actual) ===\n")
for (nm in c("nb_bow","lr_bow")) {
  tab <- table(Predicted = factor(res[[nm]]$pred, levels = c("Fake","Real")), Actual = y)
  cat("\n", nm, "\n"); print(tab)
  fr <- tab["Real","Fake"]; rf <- tab["Fake","Real"]
  bt <- binom.test(fr, fr + rf, 0.5)
  cat(sprintf("  error asymmetry: predicted-Real-but-Fake=%d vs predicted-Fake-but-Real=%d, exact binomial p=%.3g\n", fr, rf, bt$p.value))
}

cat("\n=== Holm-corrected McNemar tests, NB/LR family ===\n")
pairs <- list(c("nb_bow","lr_bow"), c("nb_tfidf","lr_tfidf"), c("nb_bow","nb_tfidf"), c("lr_bow","lr_tfidf"), c("nb_bow","lr_tfidf"), c("nb_tfidf","lr_bow"))
pv <- sapply(pairs, function(p) mcnemar.test(table(res[[p[1]]]$pred == y, res[[p[2]]]$pred == y))$p.value)
names(pv) <- sapply(pairs, paste, collapse = " vs ")
print(data.frame(raw_p = signif(pv, 3), holm_p = signif(p.adjust(pv, "holm"), 3)))

cat("\n=== McNemar p for added baselines vs LR (raw; bootstrap CIs in 33_bootstrap_ci.log) ===\n")
svm <- readRDS("rds/svm_results.rds")
for (r in c("bow","tfidf")) {
  l <- as.character(res[[paste0("lr_", r)]]$pred) == y
  s <- svm[[paste0("svm_", r)]]$pred == y
  x <- readRDS(sprintf("rds/xgb_results_%s.rds", r))$pred == y
  cat(sprintf("  %-5s SVM vs LR p=%.3g | XGB vs LR p=%.3g\n", r, mcnemar.test(table(s, l))$p.value, mcnemar.test(table(x, l))$p.value))
}

cat("\n=== Table III: top-5 BoW LR coefficients in each direction (canonical caret model) ===\n")
fit <- res$lr_bow$fit
b <- as.matrix(coef(fit$finalModel, s = fit$bestTune$lambda))[-1, 1]
b <- b[b != 0]
cat("Toward Real:\n"); print(round(head(sort(b, decreasing = TRUE), 5), 3))
cat("Toward Fake:\n"); print(round(head(sort(b), 5), 3))

cat("\n=== Weight shift after removing the 8 artifact tokens (21_leakage_ablation_dedup.R models) ===\n")
abl <- readRDS("rds/leakage_ablation_dedup.rds")
bf <- as.matrix(coef(abl$fit_full_bow$finalModel, s = abl$fit_full_bow$bestTune$lambda))[, 1]
ba <- as.matrix(coef(abl$fit_abl_bow$finalModel,  s = abl$fit_abl_bow$bestTune$lambda))[, 1]
for (t in c("minist","spokesman","presidenti","getti","via","pic"))
  cat(sprintf("  %-10s full=%7.3f  ablated=%7.3f  change=%+.3f\n", t, bf[t], ba[t], ba[t] - bf[t]))

cat("\n=== caret-CV model (Table I) vs direct glmnet refit (explanation experiments) ===\n")
g <- readRDS("rds/lr_bow_glmnet.rds")
pg <- ifelse(as.numeric(predict(g, newx = feat$test_bow, type = "response")) > 0.5, "Real", "Fake")
pc <- as.character(res$lr_bow$pred)
cat(sprintf("  accuracy caret=%.6f  glmnet refit=%.6f; test predictions that differ: %d of %d\n",
            mean(pc == y), mean(pg == y), sum(pc != pg), length(pc)))
cat("\nDone.\n")
