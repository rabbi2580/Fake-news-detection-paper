import nbformat as nbf

cells = []
md = lambda s: cells.append(nbf.v4.new_markdown_cell(s))
code = lambda s: cells.append(nbf.v4.new_code_cell(s))

md("""# DistilBERT: retrain on ISOT, then cross-corpus transfer (Colab, GPU)

Runtime -> Change runtime type -> **T4 GPU**. Then run every cell in order (about 20-30 minutes for 3 seeds).

What this does:
1. Fine-tunes DistilBERT on the 30,873-document ISOT training set with the **same settings as the paper** (1 epoch, AdamW, lr 5e-5, batch 16, max 128 tokens), for 3 seeds.
2. Evaluates each run on (a) the ISOT test set (7,718), (b) the 42,448 WELFake articles with **no ISOT match** (cross-corpus transfer), (c) 5,013 mainstream real-news articles from 10 publishers (CC-News probe).
3. Prints one summary block. **Copy the block that starts with `=== PASTE THIS BACK ===` and send it back**; the paper numbers come from it.

Input: the 4 parts of `distilbert_colab_data.zip` (4 CSVs exported by `scripts/06_export_bert_data.R` and `scripts/45_export_colab_data.R`).""")

code("""import torch, sys
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "NONE -- switch the runtime to GPU first")
!pip -q install -U "transformers>=4.44" "accelerate>=0.33" scikit-learn
import transformers; print("transformers", transformers.__version__, "| torch", torch.__version__, "| python", sys.version.split()[0])""")

md("""## 1. Upload the data (4 parts)
The data zip (~98 MB) is split into 4 parts because of the chat's file-size limit:
`distilbert_colab_data.part0.zip.bin` ... `part3.zip.bin`.
Option A: run the cell and select **all four** parts at once; they are rejoined and checked automatically.
Option B (faster if you re-run): put the four parts in a Google Drive folder, set `USE_DRIVE = True` and fix `DRIVE_DIR`.""")

code("""USE_DRIVE = False
DRIVE_DIR = "/content/drive/MyDrive/"
import os, glob, zipfile, hashlib, shutil
if USE_DRIVE:
    from google.colab import drive; drive.mount("/content/drive")
    parts = sorted(glob.glob(DRIVE_DIR + "distilbert_colab_data.part*.zip.bin"))
else:
    from google.colab import files; up = files.upload()
    parts = sorted(k for k in up if "distilbert_colab_data.part" in k)
assert len(parts) == 4, f"need all 4 parts, got {parts}"
with open("/content/distilbert_colab_data.zip", "wb") as out:
    for p in parts:
        with open(p, "rb") as f: shutil.copyfileobj(f, out)
sha = hashlib.sha256(open("/content/distilbert_colab_data.zip", "rb").read()).hexdigest()
print("sha256", sha[:16], "(expected 31c0c77384c20ca2)")
assert sha.startswith("31c0c77384c20ca2"), "parts corrupted or out of order -- re-upload"
zipfile.ZipFile("/content/distilbert_colab_data.zip").extractall("/content/data")
print(os.listdir("/content/data"))""")

code("""import pandas as pd, numpy as np
D = "/content/data/"
train_df = pd.read_csv(D + "bert_train_full.csv"); test_df = pd.read_csv(D + "bert_test.csv")
wf_df = pd.read_csv(D + "welfake_v2_transfer.csv"); cc_df = pd.read_csv(D + "ccnews_probe.csv")
for n, d in [("ISOT train", train_df), ("ISOT test", test_df), ("WELFake v2", wf_df), ("CC-News", cc_df)]:
    print(f"{n:11s} {len(d):6d} rows, {100*d.label.mean():.2f}% Real")
assert len(train_df) == 30873 and len(test_df) == 7718 and len(wf_df) == 42448 and len(cc_df) == 5013""")

md("## 2. Train + evaluate (one function, run for 3 seeds)")

code("""import time, random
from torch.utils.data import Dataset
from transformers import (DistilBertTokenizerFast, DistilBertForSequenceClassification, Trainer,
                          TrainingArguments, set_seed)
tok = DistilBertTokenizerFast.from_pretrained("distilbert-base-uncased")

class TextDS(Dataset):
    def __init__(self, texts, labels):
        self.enc = tok([str(t) for t in texts], truncation=True, padding="max_length", max_length=128)
        self.labels = list(labels)
    def __len__(self): return len(self.labels)
    def __getitem__(self, i):
        item = {k: torch.tensor(v[i]) for k, v in self.enc.items()}
        item["labels"] = torch.tensor(int(self.labels[i])); return item

t0 = time.time()
ds_train = TextDS(train_df.text, train_df.label); ds_test = TextDS(test_df.text, test_df.label)
ds_wf = TextDS(wf_df.text, wf_df.label); ds_cc = TextDS(cc_df.text, cc_df.label)
print(f"tokenized in {time.time()-t0:.0f}s")

def run(seed):
    set_seed(seed)
    model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=2)
    args = TrainingArguments(output_dir=f"/content/out_{seed}", num_train_epochs=1, per_device_train_batch_size=16,
                             per_device_eval_batch_size=128, learning_rate=5e-5, seed=seed, save_strategy="no",
                             eval_strategy="no", logging_steps=200, report_to=[], fp16=torch.cuda.is_available())
    tr = Trainer(model=model, args=args, train_dataset=ds_train)
    t = time.time(); tr.train(); print(f"seed {seed}: trained in {time.time()-t:.0f}s")
    pred = lambda ds: np.argmax(tr.predict(ds).predictions, axis=1)
    out = {"test": pred(ds_test), "wf": pred(ds_wf), "cc": pred(ds_cc)}
    if seed == SEEDS[0]:
        tr.save_model(f"/content/distilbert_isot_seed{seed}"); tok.save_pretrained(f"/content/distilbert_isot_seed{seed}")
    del model, tr; torch.cuda.empty_cache()
    return out

SEEDS = [2025, 1, 2]
RES = {s: run(s) for s in SEEDS}""")

md("## 3. Metrics with 95% bootstrap CIs, and the summary block to send back")

code("""from sklearn.metrics import f1_score
rng = np.random.default_rng(2032)
def boot_ci(y, p, fn, B=2000):
    n = len(y); v = [fn(y[i], p[i]) for i in (rng.integers(0, n, n) for _ in range(B))]
    return np.percentile(v, [2.5, 97.5])
acc = lambda y, p: float(np.mean(y == p))
bal = lambda y, p: float((np.mean(p[y == 1] == 1) + np.mean(p[y == 0] == 0)) / 2)
mf1 = lambda y, p: float(f1_score(y, p, average="macro"))
yt, yw = test_df.label.values, wf_df.label.values
noart = (~wf_df.has_artifact.values)

lines = ["=== PASTE THIS BACK ===", f"transformers {transformers.__version__}, torch {torch.__version__}, GPU {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none'}"]
for s in SEEDS:
    r = RES[s]; pt, pw, pc = r["test"], r["wf"], r["cc"]
    lo, hi = boot_ci(yt, pt, acc); wlo, whi = boot_ci(yw, pw, acc)
    lines += [f"--- seed {s} ---",
              f"ISOT test: acc {acc(yt,pt):.4f} [{lo:.4f},{hi:.4f}] macroF1 {mf1(yt,pt):.4f}",
              f"WELFake v2 transfer: acc {acc(yw,pw):.4f} [{wlo:.4f},{whi:.4f}] bal {bal(yw,pw):.4f} macroF1 {mf1(yw,pw):.4f} "
              f"realRecall {np.mean(pw[yw==1]==1):.4f} fakeRecall {np.mean(pw[yw==0]==0):.4f}",
              f"  WELFake Real with reuter: {np.mean(pw[(yw==1)&wf_df.has_reuter.values]==1):.4f} | Real with neither reuter nor weekday: {np.mean(pw[(yw==1)&noart]==1):.4f}",
              f"  WELFake v2 TEST fold only (n={int((wf_df.split=='wfm_test').sum())}): acc {acc(yw[wf_df.split.values=='wfm_test'], pw[wf_df.split.values=='wfm_test']):.4f}",
              "CC-News % called Real: " + ", ".join(f"{d}={100*np.mean(pc[cc_df.domain.values==d]==1):.1f}" for d in sorted(cc_df.domain.unique())),
              f"  all non-Reuters: {100*np.mean(pc[cc_df.domain.values!='uk.reuters.com']==1):.1f}"]
A = np.array([[acc(yt, RES[s]["test"]), acc(yw, RES[s]["wf"]), bal(yw, RES[s]["wf"]),
               np.mean(RES[s]["cc"][cc_df.domain.values != "uk.reuters.com"] == 1)] for s in SEEDS])
lines += ["--- mean (SD) over seeds ---",
          "ISOT test acc {:.4f} ({:.4f}) | WELFake transfer acc {:.4f} ({:.4f}) bal {:.4f} ({:.4f}) | CC-News non-Reuters %Real {:.1f} ({:.1f})".format(
              A[:,0].mean(), A[:,0].std(ddof=1), A[:,1].mean(), A[:,1].std(ddof=1), A[:,2].mean(), A[:,2].std(ddof=1), 100*A[:,3].mean(), 100*A[:,3].std(ddof=1))]
print("\\n".join(lines))
import json; json.dump({str(s): {k: v.tolist() for k, v in RES[s].items()} for s in SEEDS}, open("/content/distilbert_predictions.json", "w"))""")

md("""## 4. (Optional) keep the trained model and the per-document predictions
Download `distilbert_predictions.json` (needed for paired comparisons with the R models) and, if you want, the saved seed-2025 model folder.""")

code("""from google.colab import files
files.download("/content/distilbert_predictions.json")
# Optional: zip and download the model (~250 MB)
# !cd /content && zip -qr distilbert_isot_seed2025.zip distilbert_isot_seed2025 && echo ok
# files.download("/content/distilbert_isot_seed2025.zip")""")

nb = nbf.v4.new_notebook(); nb["cells"] = cells
nb["metadata"] = {"kernelspec": {"name": "python3", "display_name": "Python 3"}, "accelerator": "GPU",
                  "colab": {"provenance": [], "gpuType": "T4"}, "language_info": {"name": "python"}}
nbf.validate(nb); nbf.write(nb, "/tmp/colab/distilbert_retrain_transfer_colab.ipynb"); print("ok", len(cells))
