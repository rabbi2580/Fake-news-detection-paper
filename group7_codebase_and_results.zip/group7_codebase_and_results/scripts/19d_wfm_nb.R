suppressMessages(library(naivebayes))
split <- readRDS("rds/welfake_minus_overlap_split.rds")
wfm_train <- split$wfm_train; wfm_test <- split$wfm_test
wfm_train_bow <- readRDS("rds/wfm_train_bow.rds")
wfm_test_bow <- readRDS("rds/wfm_test_bow.rds")

metrics_full <- function(pred, actual, positive="Real") {
  tp <- as.numeric(sum(pred==positive & actual==positive)); tn <- as.numeric(sum(pred!=positive & actual!=positive))
  fp <- as.numeric(sum(pred==positive & actual!=positive)); fn <- as.numeric(sum(pred!=positive & actual==positive))
  acc <- (tp+tn)/(tp+tn+fp+fn); prec<-tp/(tp+fp); rec<-tp/(tp+fn); f1<-2*prec*rec/(prec+rec)
  sens<-tp/(tp+fn); spec<-tn/(tn+fp); bal_acc<-(sens+spec)/2
  mcc <- (tp*tn-fp*fn)/sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
  f1_fake <- {tp2<-tn;fp2<-fn;fn2<-fp;p2<-tp2/(tp2+fp2);r2<-tp2/(tp2+fn2);2*p2*r2/(p2+r2)}
  list(acc=acc,f1=f1,bal_acc=bal_acc,mcc=mcc,macro_f1=mean(c(f1,f1_fake)))
}

nb_bow <- naive_bayes(x=as.data.frame(wfm_train_bow), y=factor(wfm_train$label), laplace=0, usekernel=FALSE)
pred <- as.character(predict(nb_bow, as.data.frame(wfm_test_bow)))
m <- metrics_full(pred, as.character(wfm_test$label))
cat("NB-BoW: acc=",m$acc," f1=",m$f1," macroF1=",m$macro_f1," balAcc=",m$bal_acc," MCC=",m$mcc,"\n")
saveRDS(list(nb_bow=nb_bow, m_nb_bow=m), "rds/wfm_nb_bow_results.rds")
rm(wfm_train_bow, wfm_test_bow); gc()

wfm_train_tfidf <- readRDS("rds/wfm_train_tfidf.rds")
wfm_test_tfidf <- readRDS("rds/wfm_test_tfidf.rds")
nb_tfidf <- naive_bayes(x=as.data.frame(wfm_train_tfidf), y=factor(wfm_train$label), laplace=0, usekernel=FALSE)
pred2 <- as.character(predict(nb_tfidf, as.data.frame(wfm_test_tfidf)))
m2 <- metrics_full(pred2, as.character(wfm_test$label))
cat("NB-TFIDF: acc=",m2$acc," f1=",m2$f1," macroF1=",m2$macro_f1," balAcc=",m2$bal_acc," MCC=",m2$mcc,"\n")
saveRDS(list(nb_tfidf=nb_tfidf, m_nb_tfidf=m2), "rds/wfm_nb_tfidf_results.rds")
cat("Done.\n")
