suppressMessages({ library(tm); library(slam) })
split <- readRDS("rds/welfake_minus_overlap_split.rds")
wfm_train <- split$wfm_train; wfm_test <- split$wfm_test

cat("WFM-train class balance: Real=", mean(wfm_train$label=="Real"), "\n")
cat("WFM-test class balance: Real=", mean(wfm_test$label=="Real"), "\n")
majority_baseline <- max(mean(wfm_test$label=="Real"), mean(wfm_test$label=="Fake"))
cat("Majority-class baseline accuracy on WFM-test:", majority_baseline, "\n")

train_corpus <- VCorpus(VectorSource(wfm_train$text_final))
train_dtm <- DocumentTermMatrix(train_corpus)
train_dtm_pruned <- removeSparseTerms(train_dtm, 0.99)
cat("Terms surviving pruning:", ncol(train_dtm_pruned), "\n")
term_freq <- slam::col_sums(train_dtm_pruned)
vocab500_wfm <- names(sort(term_freq, decreasing=TRUE))[1:500]
rm(train_dtm, train_dtm_pruned, train_corpus, term_freq); gc()

build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control=list(dictionary=vocab))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab, colnames(mat))
  if (length(missing_cols)>0) { addmat <- matrix(0,nrow=nrow(mat),ncol=length(missing_cols),dimnames=list(NULL,missing_cols)); mat <- cbind(mat,addmat) }
  mat[, vocab, drop=FALSE]
}
wfm_train_bow <- build_bow(wfm_train$text_final, vocab500_wfm)
saveRDS(wfm_train_bow, "rds/wfm_train_bow.rds")
rm(wfm_train_bow); gc()
wfm_test_bow <- build_bow(wfm_test$text_final, vocab500_wfm)
saveRDS(wfm_test_bow, "rds/wfm_test_bow.rds")
saveRDS(vocab500_wfm, "rds/vocab500_wfm.rds")
cat("Saved WFM BoW matrices.\n")
