suppressMessages({ library(tm); library(slam); library(caret); library(glmnet); library(naivebayes)
                   library(LiblineaR); library(xgboost) })

# Training-run variability: repeat the WHOLE ISOT pipeline for one split seed
# -- stratified 80/20 split, train-only 500-term vocabulary and IDF, Naive
# Bayes, CV-tuned Logistic Regression (same caret protocol as 04), CV-tuned
# linear SVM, CV-early-stopped XGBoost, the 8-token artifact ablation, and the
# ISOT -> WELFake v2 transfer test with this seed's vocabulary.
# Seed 123 is the paper's canonical split and should reproduce Table I.
# Usage: Rscript scripts/41_multiseed.R <seed>

seed <- as.integer(commandArgs(trailingOnly = TRUE)[1])
t0 <- Sys.time()
final <- readRDS("rds/final_corpus.rds"); final$label <- factor(final$label, levels = c("Fake","Real"))
set.seed(seed)
idx <- createDataPartition(final$label, p = 0.8, list = FALSE)
tr <- final[idx, ]; te <- final[-idx, ]; rm(final)
stopifnot(length(intersect(tr$text, te$text)) == 0)

dtm_tr <- removeSparseTerms(DocumentTermMatrix(VCorpus(VectorSource(tr$text_final))), 0.99)
vocab <- names(sort(col_sums(dtm_tr), decreasing = TRUE))[1:500]; rm(dtm_tr)
bow <- function(txt) { d <- DocumentTermMatrix(VCorpus(VectorSource(txt)), control = list(dictionary = vocab))[, vocab]
  stopifnot(identical(colnames(d), vocab)); as.matrix(d) }
Xtr <- bow(tr$text_final); Xte <- bow(te$text_final)
idf <- log2(nrow(Xtr) / colSums(Xtr > 0)); idf[is.infinite(idf)] <- 0
tfidf <- function(B) { rs <- rowSums(B); rs[rs == 0] <- 1; sweep(B / rs, 2, idf, `*`) }
Ttr <- tfidf(Xtr); Tte <- tfidf(Xte)
ytr <- tr$label; yte <- as.character(te$label); ytr01 <- as.numeric(ytr == "Real")
acc <- function(p) mean(as.character(p) == yte)
res <- list(seed = seed)

nbfit <- function(X) naive_bayes(x = as.data.frame(X, check.names = FALSE), y = ytr, laplace = 0, usekernel = FALSE)
res$nb_bow   <- acc(predict(nbfit(Xtr), as.data.frame(Xte, check.names = FALSE)))
res$nb_tfidf <- acc(predict(nbfit(Ttr), as.data.frame(Tte, check.names = FALSE)))

cvc <- trainControl(method = "cv", number = 5); grid <- expand.grid(alpha = 1, lambda = 10^seq(-4, -1, length.out = 10))
lrfit <- function(X) { set.seed(123); train(label ~ ., data = data.frame(X, label = ytr, check.names = FALSE),
                                             method = "glmnet", family = "binomial", trControl = cvc, tuneGrid = grid) }
lr_b <- lrfit(Xtr); p_lr <- predict(lr_b, data.frame(Xte, check.names = FALSE)); res$lr_bow <- acc(p_lr)
res$lr_tfidf <- acc(predict(lrfit(Ttr), data.frame(Tte, check.names = FALSE)))

art <- intersect(c("reuter","monday","tuesday","wednesday","thursday","friday","saturday","sunday"), vocab)
keep <- setdiff(vocab, art)
lr_a <- lrfit(Xtr[, keep]); res$lr_bow_ablated <- acc(predict(lr_a, data.frame(Xte[, keep], check.names = FALSE)))
res$n_artifact_in_vocab <- length(art)

costs <- c(0.01, 0.1, 1, 10)
cvs <- sapply(costs, function(C) { set.seed(123); LiblineaR(Xtr, ytr, type = 2, cost = C, cross = 5) })
svm <- LiblineaR(Xtr, ytr, type = 2, cost = costs[which.max(cvs)])
res$svm_bow <- acc(predict(svm, Xte)$predictions)

set.seed(123)
dtr <- xgb.DMatrix(Xtr, label = ytr01)
prm <- list(objective = "binary:logistic", eval_metric = "error", eta = 0.1, max_depth = 6, subsample = 0.8, colsample_bytree = 0.8, nthread = 2)
cvx <- xgb.cv(params = prm, data = dtr, nrounds = 400, nfold = 5, early_stopping_rounds = 25, verbose = 0)
nr <- if (!is.null(cvx$early_stop$best_iteration)) cvx$early_stop$best_iteration else cvx$best_iteration
xg <- xgb.train(params = prm, data = dtr, nrounds = nr, verbose = 0)
res$xgb_bow <- acc(ifelse(predict(xg, xgb.DMatrix(Xte)) > 0.5, "Real", "Fake"))

# ---- ISOT -> WELFake v2 transfer with THIS seed's vocabulary ----
sp <- readRDS("rds/welfake_minus_overlap_split_v2.rds"); wf <- rbind(sp$wfm_train, sp$wfm_test); rm(sp)
act <- as.character(wf$label); Xw <- bow(wf$text_final)
tok <- strsplit(wf$text_final, "\\s+")
no_art <- !vapply(tok, function(w) any(c("reuter","monday","tuesday","wednesday","thursday","friday","saturday","sunday") %in% w), logical(1))
pw_lr <- as.character(predict(lr_b, data.frame(Xw, check.names = FALSE)))
pw_xg <- ifelse(predict(xg, xgb.DMatrix(Xw)) > 0.5, "Real", "Fake")
bal <- function(p) (mean(p[act == "Real"] == "Real") + mean(p[act == "Fake"] == "Fake")) / 2
res$transfer_lr <- mean(pw_lr == act); res$transfer_lr_bal <- bal(pw_lr)
res$transfer_xgb <- mean(pw_xg == act); res$transfer_xgb_bal <- bal(pw_xg)
res$transfer_lr_real_no_artifact <- mean(pw_lr[act == "Real" & no_art] == "Real")

cat(sprintf("seed %d done in %.0fs\n", seed, as.numeric(Sys.time() - t0, units = "secs")))
print(round(unlist(res), 4))
saveRDS(res, sprintf("rds/multiseed_%d.rds", seed))
