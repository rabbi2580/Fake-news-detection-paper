suppressMessages({ library(glmnet); library(naivebayes) })
split <- readRDS("rds/welfake_minus_overlap_split_v2.rds")
wfm_train <- split$wfm_train; wfm_test <- split$wfm_test
wfm_train_bow <- readRDS("rds/wfm_train_bow_v2.rds")
wfm_test_bow <- readRDS("rds/wfm_test_bow_v2.rds")

N_train <- nrow(wfm_train_bow); df_train <- colSums(wfm_train_bow>0)
idf <- log2(N_train/df_train); idf[is.infinite(idf)] <- 0
tfidf_from_bow <- function(bow, idfv) { rs<-rowSums(bow); rs[rs==0]<-1; sweep(bow/rs,2,idfv,`*`) }
wfm_train_tfidf <- tfidf_from_bow(wfm_train_bow, idf)
wfm_test_tfidf <- tfidf_from_bow(wfm_test_bow, idf)
saveRDS(idf, "rds/wfm_idf_v2.rds")

y_train <- ifelse(wfm_train$label=="Real",1,0)
FIXED_LAMBDA <- 4.641589e-4  # same lambda used throughout this paper's ISOT/WELFake LR fits

metrics_full <- function(pred, actual, positive="Real") {
  tp <- sum(pred==positive & actual==positive); tn <- sum(pred!=positive & actual!=positive)
  fp <- sum(pred==positive & actual!=positive); fn <- sum(pred!=positive & actual==positive)
  acc <- (tp+tn)/(tp+tn+fp+fn)
  prec <- tp/(tp+fp); rec <- tp/(tp+fn); f1 <- 2*prec*rec/(prec+rec)
  sens <- tp/(tp+fn); spec <- tn/(tn+fp); bal_acc <- (sens+spec)/2
  mcc_num <- (as.numeric(tp)*as.numeric(tn) - as.numeric(fp)*as.numeric(fn))
  mcc_den <- sqrt(as.numeric(tp+fp)*as.numeric(tp+fn)*as.numeric(tn+fp)*as.numeric(tn+fn))
  mcc <- ifelse(mcc_den==0, NA, mcc_num/mcc_den)
  f1_fake <- {tp2<-tn; fp2<-fn; fn2<-fp; prec2<-tp2/(tp2+fp2); rec2<-tp2/(tp2+fn2); 2*prec2*rec2/(prec2+rec2)}
  macro_f1 <- mean(c(f1, f1_fake))
  list(acc=acc, f1=f1, bal_acc=bal_acc, mcc=mcc, macro_f1=macro_f1)
}

cat("== LR (fixed lambda, direct glmnet) ==\n")
lr_bow_fit <- glmnet(wfm_train_bow, y_train, family="binomial", alpha=1, lambda=FIXED_LAMBDA)
pred_bow <- ifelse(as.numeric(predict(lr_bow_fit, newx=wfm_test_bow, type="response"))>0.5,"Real","Fake")
m_lr_bow <- metrics_full(pred_bow, as.character(wfm_test$label))
cat("LR-BoW: acc=",m_lr_bow$acc," f1=",m_lr_bow$f1," macroF1=",m_lr_bow$macro_f1," balAcc=",m_lr_bow$bal_acc," MCC=",m_lr_bow$mcc,"\n")

lr_tfidf_fit <- glmnet(wfm_train_tfidf, y_train, family="binomial", alpha=1, lambda=FIXED_LAMBDA)
pred_tfidf <- ifelse(as.numeric(predict(lr_tfidf_fit, newx=wfm_test_tfidf, type="response"))>0.5,"Real","Fake")
m_lr_tfidf <- metrics_full(pred_tfidf, as.character(wfm_test$label))
cat("LR-TFIDF: acc=",m_lr_tfidf$acc," f1=",m_lr_tfidf$f1," macroF1=",m_lr_tfidf$macro_f1," balAcc=",m_lr_tfidf$bal_acc," MCC=",m_lr_tfidf$mcc,"\n")

cat("\n== NB ==\n")
nb_bow_fit <- naive_bayes(x=as.data.frame(wfm_train_bow), y=factor(wfm_train$label), laplace=0, usekernel=FALSE)
pred_nb_bow <- as.character(predict(nb_bow_fit, as.data.frame(wfm_test_bow)))
m_nb_bow <- metrics_full(pred_nb_bow, as.character(wfm_test$label))
cat("NB-BoW: acc=",m_nb_bow$acc," f1=",m_nb_bow$f1," macroF1=",m_nb_bow$macro_f1," balAcc=",m_nb_bow$bal_acc," MCC=",m_nb_bow$mcc,"\n")

nb_tfidf_fit <- naive_bayes(x=as.data.frame(wfm_train_tfidf), y=factor(wfm_train$label), laplace=0, usekernel=FALSE)
pred_nb_tfidf <- as.character(predict(nb_tfidf_fit, as.data.frame(wfm_test_tfidf)))
m_nb_tfidf <- metrics_full(pred_nb_tfidf, as.character(wfm_test$label))
cat("NB-TFIDF: acc=",m_nb_tfidf$acc," f1=",m_nb_tfidf$f1," macroF1=",m_nb_tfidf$macro_f1," balAcc=",m_nb_tfidf$bal_acc," MCC=",m_nb_tfidf$mcc,"\n")

beta <- as.matrix(lr_bow_fit$beta)
ord <- order(-abs(beta[,1]))
cat("\nTop 10 WFM-v2-LR-BoW coefficients:\n")
print(data.frame(token=rownames(beta)[ord][1:10], coef=beta[ord,1][1:10]))

saveRDS(list(m_lr_bow=m_lr_bow, m_lr_tfidf=m_lr_tfidf, m_nb_bow=m_nb_bow, m_nb_tfidf=m_nb_tfidf,
             lr_bow_fit=lr_bow_fit, lr_tfidf_fit=lr_tfidf_fit, lambda=FIXED_LAMBDA),
        "rds/wfm_results_v2.rds")
cat("\nDone.\n")
