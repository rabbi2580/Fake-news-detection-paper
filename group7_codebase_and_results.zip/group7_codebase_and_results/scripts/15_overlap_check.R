suppressMessages({ library(stringr) })

isot_final <- readRDS("rds/final_corpus.rds")  # 38,591 rows, has $text (original, dateline-stripped)
wf_deduped <- readRDS("rds/welfake_deduped.rds")  # 62,718 rows, has $text (raw)

cat("ISOT final:", nrow(isot_final), " WELFake deduped:", nrow(wf_deduped), "\n")

isot_text <- isot_final$text
wf_text <- wf_deduped$text

exact_match <- isot_text %in% wf_text
cat("Exact full-text match: ISOT docs matching WELFake:", sum(exact_match),
    sprintf(" (%.2f%% of ISOT)\n", 100*mean(exact_match)))

wf_exact_match <- wf_text %in% isot_text
cat("Exact full-text match: WELFake docs matching ISOT:", sum(wf_exact_match),
    sprintf(" (%.2f%% of WELFake)\n", 100*mean(wf_exact_match)))

# 200-char prefix match
isot_prefix <- substr(str_trim(isot_text), 1, 200)
wf_prefix <- substr(str_trim(wf_text), 1, 200)
prefix_match <- isot_prefix %in% wf_prefix
cat("200-char prefix match: ISOT docs matching WELFake:", sum(prefix_match),
    sprintf(" (%.2f%% of ISOT)\n", 100*mean(prefix_match)))

saveRDS(list(exact_match=exact_match, wf_exact_match=wf_exact_match, prefix_match=prefix_match),
        "rds/overlap_results.rds")
cat("Saved overlap_results.rds\n")
