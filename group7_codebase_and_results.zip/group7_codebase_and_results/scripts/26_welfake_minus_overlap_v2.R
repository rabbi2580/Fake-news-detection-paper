suppressMessages({ library(caret) })

# Rebuilds the WFM ("WELFake minus ISOT overlap") subset using the UNION of
# exact-match + normalized-text-match + near-duplicate-prefix-match
# (overlap_results_v2.rds), instead of exact raw-text match alone
# (overlap_results.rds, used by the original 17_welfake_minus_overlap_split.R).
# This directly addresses the audit finding that near-duplicate articles
# (identical apart from case/whitespace/punctuation -- 1,978 extra ISOT docs,
# ~1,988 extra WELFake docs) were not excluded by the original "overlap-free"
# construction.

wf_final <- readRDS("rds/welfake_final.rds")
wf_deduped <- readRDS("rds/welfake_deduped.rds")
ov2 <- readRDS("rds/overlap_results_v2.rds")
stopifnot(nrow(wf_deduped) == length(ov2$wf_union_match))

# Join v2 overlap flags onto wf_final by exact text match (wf_final is a
# filtered subset of wf_deduped with the same $text values).
idx <- match(wf_final$text, wf_deduped$text)
stopifnot(!any(is.na(idx)))
wf_final$isot_overlap_v2 <- ov2$wf_union_match[idx]

cat("Full WELFake (", nrow(wf_final), "):\n")
cat("  exact-match-only flag (original): ", sum(wf_final$isot_overlap), " overlap docs\n")
cat("  union flag (v2, this script):     ", sum(wf_final$isot_overlap_v2), " overlap docs\n")

wf_minus_v2 <- wf_final[!wf_final$isot_overlap_v2, ]
wf_minus_v2$label <- factor(wf_minus_v2$label_name, levels=c("Fake","Real"))
cat("\nWFM-v2 (WELFake minus union-overlap):", nrow(wf_minus_v2),
    "| Fake:", sum(wf_minus_v2$label=="Fake"), "Real:", sum(wf_minus_v2$label=="Real"), "\n")
cat(sprintf("Retained %.2f%% of WELFake after removing union-overlap docs (vs.\\ %.2f%% under exact-match-only)\n",
            100*nrow(wf_minus_v2)/nrow(wf_final), 100*sum(!wf_final$isot_overlap)/nrow(wf_final)))

set.seed(123)
idx2 <- createDataPartition(wf_minus_v2$label, p=0.8, list=FALSE)
wfm_train_v2 <- wf_minus_v2[idx2,]; wfm_test_v2 <- wf_minus_v2[-idx2,]
cat("WFM-v2-train:", nrow(wfm_train_v2), " WFM-v2-test:", nrow(wfm_test_v2), "\n")
stopifnot(length(intersect(wfm_train_v2$text, wfm_test_v2$text))==0)
cat("Zero train/test overlap verified.\n")

saveRDS(list(wfm_train=wfm_train_v2, wfm_test=wfm_test_v2), "rds/welfake_minus_overlap_split_v2.rds")
cat("Saved welfake_minus_overlap_split_v2.rds\n")
