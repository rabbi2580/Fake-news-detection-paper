suppressMessages({ library(xgboost); library(caret) })

# Gradient-boosted trees baseline (XGBoost) -- a non-linear model, on the SAME
# split and SAME 500-term features as every other ISOT model. Number of
# boosting rounds is chosen by 5-fold CV with early stopping on the TRAINING
# set only; other hyperparameters are fixed, common defaults (eta=0.1,
# max_depth=6), disclosed here rather than tuned against the test set.
# Usage: Rscript scripts/35_xgboost_baseline.R bow   (or tfidf)

args <- commandArgs(trailingOnly = TRUE); rep_name <- if (length(args)) args[1] else "bow"
set.seed(123)
feat <- readRDS("rds/features.rds")
Xtr <- feat[[paste0("train_", rep_name)]]; Xte <- feat[[paste0("test_", rep_name)]]
y_tr <- as.numeric(feat$train_docs$label == "Real"); y_te <- as.character(feat$test_docs$label)
rm(feat); invisible(gc())

dtr <- xgb.DMatrix(Xtr, label = y_tr)
params <- list(objective = "binary:logistic", eval_metric = "error", eta = 0.1, max_depth = 6,
               subsample = 0.8, colsample_bytree = 0.8, nthread = 2)

cat(sprintf("== XGBoost, %s: 5-fold CV for nrounds (max 400, early stop 25) ==\n", rep_name))
t0 <- Sys.time()
cvr <- xgb.cv(params = params, data = dtr, nrounds = 400, nfold = 5, early_stopping_rounds = 25, verbose = 0)
best_n <- if (!is.null(cvr$early_stop$best_iteration)) cvr$early_stop$best_iteration else cvr$best_iteration
el <- cvr$evaluation_log
cv_err <- el[[grep("test.*error.*mean", names(el))]][best_n]
cat(sprintf("  best nrounds=%d  CV accuracy=%.4f  (CV took %.0fs)\n", best_n, 1 - cv_err, as.numeric(Sys.time() - t0, units = "secs")))

fit <- xgb.train(params = params, data = dtr, nrounds = best_n, verbose = 0)
p <- predict(fit, xgb.DMatrix(Xte))
pred <- ifelse(p > 0.5, "Real", "Fake")
cm <- confusionMatrix(factor(pred, levels = c("Fake","Real")), factor(y_te, levels = c("Fake","Real")), positive = "Real")
cat(sprintf("  Test accuracy=%.4f  F1=%.4f\n", cm$overall["Accuracy"], cm$byClass["F1"]))

lr <- readRDS("rds/model_results.rds")[[paste0("lr_", rep_name)]]
s <- pred == y_te; l <- as.character(lr$pred) == y_te
mc <- mcnemar.test(table(s, l))
cat(sprintf("  McNemar vs LR-%s (%.4f): XGB-only-correct=%d, LR-only-correct=%d, p=%.4g\n",
            rep_name, mean(l), sum(s & !l), sum(!s & l), mc$p.value))

imp <- xgb.importance(model = fit)
cat("  Top 10 features by gain:\n"); print(head(imp[, 1:2], 10))

saveRDS(list(pred = pred, acc = unname(cm$overall["Accuracy"]), f1 = unname(cm$byClass["F1"]),
             nrounds = best_n, importance = head(imp, 20)),
        sprintf("rds/xgb_results_%s.rds", rep_name))
xgb.save(fit, sprintf("rds/xgb_model_%s.ubj", rep_name))
cat("Done.\n")
