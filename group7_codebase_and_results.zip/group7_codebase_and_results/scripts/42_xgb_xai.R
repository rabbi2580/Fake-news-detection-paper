suppressMessages({ library(lime); library(tm); library(xgboost) })

# Explanation audit for a NON-LINEAR model: the canonical XGBoost-BoW model
# (35_xgboost_baseline.R). Unlike Logistic Regression, no attribution here is
# trivially optimal for deletion, so the faithfulness comparison is not
# circular. Methods compared on each document:
#   - TreeSHAP (xgboost predcontrib, path-dependent; exact Shapley values for
#     the tree ensemble under that formulation), ranked over present words;
#   - text-mode LIME (5,000 permutations) on the XGBoost model;
#   - leave-one-out occlusion (drop each present word alone, rank by the change
#     in P(Real)) -- assumption-light, and by construction optimal at k=1 only;
#   - random order of present words (baseline).
# Measures: top-10 agreement, LIME same-document stability (5 reruns, on a
# 40-document subset), deletion faithfulness (confidence drop, k=1..10).
# 100 test docs, stratified on XGBoost's own predictions: 40 correct-Real,
# 40 correct-Fake, 20 misclassified; >= 10 vocabulary words present.
# Usage: Rscript scripts/42_xgb_xai.R <start> <end>   (positions 1..100)

a <- as.integer(commandArgs(trailingOnly = TRUE)); s0 <- a[1]; s1 <- a[2]
vocab500 <- readRDS("rds/vocab500.rds")
core <- readRDS("rds/lime_text_core.rds"); preprocess_bow <- core$preprocess_bow
test_docs <- readRDS("rds/test_docs_light.rds")
xgbm <- xgb.load("rds/xgb_model_bow.ubj")
xgb_pred <- readRDS("rds/xgb_results_bow.rds")$pred
stopifnot(length(xgb_pred) == nrow(test_docs))

xgb_wrap <- structure(list(fit = xgbm), class = "xgb_wrap")
predict_model.xgb_wrap <- function(x, newdata, type, ...) {
  m <- as.matrix(newdata); colnames(m) <- vocab500
  p1 <- predict(x$fit, xgb.DMatrix(m)); data.frame(Fake = 1 - p1, Real = p1) }
model_type.xgb_wrap <- function(x, ...) "classification"
assign("predict_model.xgb_wrap", predict_model.xgb_wrap, envir = .GlobalEnv)
assign("model_type.xgb_wrap", model_type.xgb_wrap, envir = .GlobalEnv)
p_real <- function(r) { m <- matrix(r, nrow = 1, dimnames = list(NULL, vocab500)); predict(xgbm, xgb.DMatrix(m)) }
J <- function(x, y) length(intersect(x, y)) / length(union(x, y))

## ---- fixed design (identical in every chunk) ----
set.seed(4242)
n_present <- sapply(test_docs$text_final, function(t) sum(preprocess_bow(t)[1, ] > 0))
ok <- which(n_present >= 10); lab <- as.character(test_docs$label); cor <- xgb_pred == lab
pick <- function(pool, n) sample(pool, n)
design <- data.frame(idx = c(pick(intersect(ok, which(cor & lab == "Real")), 40), pick(intersect(ok, which(cor & lab == "Fake")), 40),
                             pick(intersect(ok, which(!cor)), 20)),
                     stratum = rep(c("Real-correct","Fake-correct","Misclassified"), c(40, 40, 20)),
                     stability = rep(c(TRUE, FALSE, TRUE, FALSE, TRUE, FALSE), c(16, 24, 16, 24, 8, 12)))
design <- design[sample(nrow(design)), ]; design$pos <- seq_len(nrow(design))
if (s0 == 1) { saveRDS(design, "rds/xgb_xai_design.rds"); cat("XGBoost misclassified test docs available:", sum(!cor), "\n") }

explainer <- lime(test_docs$text_final[design$idx], model = xgb_wrap, preprocess = preprocess_bow)
lime_top <- function(txt, k, seed) { set.seed(seed)
  e <- tryCatch(explain(txt, explainer, n_labels = 1, n_features = k, n_permutations = 5000), error = function(e) NULL)
  if (is.null(e)) character(0) else e$feature[order(-abs(e$feature_weight))] }

K <- 10; methods <- c("treeshap", "lime", "occlusion", "random"); out <- list(); t0 <- Sys.time()
for (pos in s0:s1) {
  d <- design[design$pos == pos, ]; txt <- test_docs$text_final[d$idx]
  row <- preprocess_bow(txt)[1, ]; present <- names(row)[row > 0]
  op <- p_real(row); pc <- ifelse(op > 0.5, "Real", "Fake"); oc <- ifelse(pc == "Real", op, 1 - op)
  shp <- predict(xgbm, xgb.DMatrix(matrix(row, nrow = 1, dimnames = list(NULL, vocab500))), predcontrib = TRUE)[1, vocab500]
  occ <- sapply(present, function(w) { r <- row; r[w] <- 0; op - p_real(r) })
  reps <- lapply(1:(if (d$stability) 5 else 1), function(r) lime_top(txt, min(K, length(present)), 70000 + pos * 10 + r))
  set.seed(80000 + pos)
  ord <- list(treeshap = present[order(-abs(shp[present]))], lime = intersect(reps[[1]], present),
              occlusion = present[order(-abs(occ))], random = sample(present))
  conf <- matrix(NA, K, 4, dimnames = list(1:K, methods))
  for (m in methods) for (k in 1:K) {
    r <- row; cols <- ord[[m]][seq_len(min(k, length(ord[[m]])))]; if (length(cols)) r[cols] <- 0
    np <- p_real(r); conf[k, m] <- oc - ifelse(pc == "Real", np, 1 - np)
  }
  top10 <- lapply(ord[c("treeshap","lime","occlusion")], function(v) v[1:min(10, length(v))])
  shap_full <- names(shp)[order(-abs(shp))][1:10]
  agree <- c(shap_lime = J(top10$treeshap, top10$lime), shap_occ = J(top10$treeshap, top10$occlusion),
             lime_occ = J(top10$lime, top10$occlusion), shapfull_shappresent = J(shap_full, top10$treeshap),
             shapfull_absent_share = mean(!(shap_full %in% present)))
  stab <- if (d$stability) mean(combn(5, 2, function(p) J(reps[[p[1]]][1:10], reps[[p[2]]][1:10]))) else NA
  out[[as.character(pos)]] <- list(pos = pos, idx = d$idx, stratum = d$stratum, conf = conf, agree = agree,
                                   stab = stab, top10 = top10, shap_full = shap_full)
}
cat(sprintf("XGBoost XAI docs %d-%d done in %.0fs\n", s0, s1, as.numeric(Sys.time() - t0, units = "secs")))
saveRDS(out, sprintf("rds/xgb_xai_chunk_%03d_%03d.rds", s0, s1))
