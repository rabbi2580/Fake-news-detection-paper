suppressMessages({ library(lime); library(tm); library(glmnet) })

# Expanded, pre-registered-style REPLICATION of the explanation-validation
# results on a NEW, larger document sample, disjoint from the original
# 100-doc AOPC sample (11_deletion_curve_full.R) and 20-doc stability sample
# (09_lime_text_stability.R), and including MISCLASSIFIED documents:
#   - 300 docs total: 120 correctly-classified Real, 120 correctly-classified
#     Fake, 60 misclassified (of the model's 201 test errors);
#   - deletion-faithfulness / AOPC on all 300 (text-mode LIME @ 5,000 perms);
#   - same-document LIME stability (5 repeats @ 5,000 perms) on a 100-doc
#     stratified subset (40 / 40 / 20).
# Run in chunks so each call fits a 10-minute budget; per-document seeds
# depend only on the document's position, so chunking cannot change results.
# Usage: Rscript scripts/37_xai_expanded.R <chunk_start> <chunk_end>   (positions 1..300)

args <- as.integer(commandArgs(trailingOnly = TRUE)); c0 <- args[1]; c1 <- args[2]

core <- readRDS("rds/lime_text_core.rds")
glmnet_wrap <- core$glmnet_wrap; preprocess_bow <- core$preprocess_bow
vocab500 <- readRDS("rds/vocab500.rds")
test_docs <- readRDS("rds/test_docs_light.rds")
correct_idx <- readRDS("rds/correct_idx.rds")$correct_idx
lr_bow_glmnet <- readRDS("rds/lr_bow_glmnet.rds")
train_means <- readRDS("rds/train_bow_colmeans.rds")
old_aopc_idx <- readRDS("rds/deletion_curve_full.rds")$samp_idx
old_stab_idx <- readRDS("rds/lime_text_sensitivity_sweep.rds")$sel_idx

predict_model.glmnet_wrap <- function(x, newdata, type, ...) {
  p1 <- as.numeric(predict(x$fit, newx = as.matrix(newdata), type = "response")); data.frame(Fake = 1 - p1, Real = p1) }
model_type.glmnet_wrap <- function(x, ...) "classification"
assign("predict_model.glmnet_wrap", predict_model.glmnet_wrap, envir = .GlobalEnv)
assign("model_type.glmnet_wrap", model_type.glmnet_wrap, envir = .GlobalEnv)

beta <- as.numeric(coef(lr_bow_glmnet))[-1]; names(beta) <- rownames(coef(lr_bow_glmnet))[-1]
p_real <- function(r) as.numeric(predict(lr_bow_glmnet, newx = matrix(r, nrow = 1, dimnames = list(NULL, vocab500)), type = "response"))
jaccard <- function(a, b) length(intersect(a, b)) / length(union(a, b))

## ---- fixed sample design (identical in every chunk) ----
set.seed(31337)
excl <- union(old_aopc_idx, old_stab_idx)
n_present <- sapply(test_docs$text_final, function(t) sum(preprocess_bow(t)[1, ] > 0))  # need >= 10 present vocab words
eligible <- setdiff(which(n_present >= 10), excl)
mis_pool  <- setdiff(seq_len(nrow(test_docs)), correct_idx)
real_pool <- intersect(correct_idx[test_docs$label[correct_idx] == "Real"], eligible)
fake_pool <- intersect(correct_idx[test_docs$label[correct_idx] == "Fake"], eligible)
mis_pool  <- intersect(mis_pool, eligible)
cat(sprintf("Eligible pools (>=10 present words, not in original samples): Real-correct %d, Fake-correct %d, misclassified %d\n",
            length(real_pool), length(fake_pool), length(mis_pool)))
r_s <- sample(real_pool, 120); f_s <- sample(fake_pool, 120); m_s <- sample(mis_pool, 60)
design <- data.frame(idx = c(r_s, f_s, m_s),
                     stratum = rep(c("Real-correct","Fake-correct","Misclassified"), c(120, 120, 60)),
                     stability = c(rep(c(TRUE, FALSE), c(40, 80)), rep(c(TRUE, FALSE), c(40, 80)), rep(c(TRUE, FALSE), c(20, 40))))
design <- design[sample(nrow(design)), ]          # interleave strata so every chunk has a mix
design$pos <- seq_len(nrow(design))
if (c0 == 1) saveRDS(design, "rds/xai_expanded_design.rds")

explainer <- lime(test_docs$text_final[design$idx], model = glmnet_wrap, preprocess = preprocess_bow)
lime_top <- function(txt, n_feat, seed) {
  set.seed(seed)
  e <- tryCatch(explain(txt, explainer, n_labels = 1, n_features = n_feat, n_permutations = 5000), error = function(e) NULL)
  if (is.null(e)) character(0) else e$feature[order(-abs(e$feature_weight))]
}

K <- 10; methods <- c("exact","shap","lime","random")
out <- list(); t0 <- Sys.time()
for (pos in c0:c1) {
  d <- design[design$pos == pos, ]; txt <- test_docs$text_final[d$idx]
  row <- preprocess_bow(txt)[1, ]; present <- names(row)[row > 0]
  op <- p_real(row); pc <- ifelse(op > 0.5, "Real", "Fake"); oc <- ifelse(pc == "Real", op, 1 - op)
  contrib <- row[present] * beta[present]
  shapv <- beta[present] * (row[present] - train_means[present])
  n_rep <- if (d$stability) 5 else 1
  reps <- lapply(1:n_rep, function(r) lime_top(txt, min(K, length(present)), 50000 + pos * 10 + r))
  set.seed(60000 + pos)
  orders <- list(exact = present[order(-abs(contrib))], shap = present[order(-abs(shapv))],
                 lime = intersect(reps[[1]], present), random = sample(present))
  conf <- matrix(NA, K, 4, dimnames = list(1:K, methods))
  for (m in methods) for (k in 1:K) {
    mod <- row; cols <- intersect(orders[[m]][1:min(k, length(orders[[m]]))], vocab500)
    if (length(cols)) mod[cols] <- 0
    np <- p_real(mod); conf[k, m] <- oc - ifelse(pc == "Real", np, 1 - np)
  }
  stab <- if (d$stability) { pr <- combn(5, 2); mean(apply(pr, 2, function(p) jaccard(reps[[p[1]]][1:10], reps[[p[2]]][1:10]))) } else NA
  out[[as.character(pos)]] <- list(pos = pos, idx = d$idx, stratum = d$stratum, stability_doc = d$stability,
                                   conf = conf, stab_jaccard = stab, lime_top = reps[[1]])
}
cat(sprintf("Chunk %d-%d done: %d docs in %.0fs\n", c0, c1, length(out), as.numeric(Sys.time() - t0, units = "secs")))
saveRDS(out, sprintf("rds/xai_expanded_chunk_%03d_%03d.rds", c0, c1))
