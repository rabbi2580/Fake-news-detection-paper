suppressMessages({ library(tm); library(caret); library(glmnet) })

# THE genuine cross-dataset generalization test: the ISOT-trained canonical
# LR-BoW model (04_train_models.R / lr_bow_fit.rds), with its ISOT-derived
# vocabulary and TF-IDF weights held fixed, scored directly on WELFake
# documents it has never seen -- the overlap-filtered v2 WELFake subset
# (every ISOT exact/normalized/near-duplicate match removed), so there is no
# possibility of the same underlying article appearing on both sides.
# Everything prior to this script in the project (05/16/17-19/26-29) was a
# WITHIN-corpus evaluation; this is the first and only cross-corpus one.

feat <- readRDS("rds/features.rds")
vocab500 <- feat$vocab500
idf_isot <- feat$idf
rm(feat); gc()

lr_bow_fit <- readRDS("rds/lr_bow_fit.rds")   # canonical caret model, Table I

split_v2 <- readRDS("rds/welfake_minus_overlap_split_v2.rds")
wf_transfer <- rbind(split_v2$wfm_train, split_v2$wfm_test)  # full overlap-filtered WELFake; none of it was used to train the ISOT model
cat("WELFake transfer-test set (v2 overlap-filtered, train+test combined):", nrow(wf_transfer),
    "| Fake:", sum(wf_transfer$label=="Fake"), "Real:", sum(wf_transfer$label=="Real"), "\n")

build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control = list(dictionary = vocab))
  dtm <- dtm[, vocab]   # tm's dictionary= doesn't guarantee column order -- force it, with a hard check
  stopifnot(identical(colnames(dtm), vocab))
  as.matrix(dtm)
}

cat("Building WELFake BoW matrix using ISOT's fixed 500-term vocabulary...\n")
wf_bow_isotvocab <- build_bow(wf_transfer$text_final, vocab500)
cat("wf_bow_isotvocab dim:", dim(wf_bow_isotvocab), "\n")

tfidf_from_bow <- function(bow, idfv) { rs <- rowSums(bow); rs[rs==0] <- 1; sweep(bow/rs, 2, idfv, `*`) }
wf_tfidf_isotvocab <- tfidf_from_bow(wf_bow_isotvocab, idf_isot)

metrics_full <- function(pred, actual, positive="Real") {
  tp <- sum(pred==positive & actual==positive); tn <- sum(pred!=positive & actual!=positive)
  fp <- sum(pred==positive & actual!=positive); fn <- sum(pred!=positive & actual==positive)
  acc <- (tp+tn)/(tp+tn+fp+fn)
  prec <- tp/(tp+fp); rec <- tp/(tp+fn); f1 <- 2*prec*rec/(prec+rec)
  sens <- tp/(tp+fn); spec <- tn/(tn+fp); bal_acc <- (sens+spec)/2
  mcc_num <- (as.numeric(tp)*as.numeric(tn) - as.numeric(fp)*as.numeric(fn))
  mcc_den <- sqrt(as.numeric(tp+fp)*as.numeric(tp+fn)*as.numeric(tn+fp)*as.numeric(tn+fn))
  mcc <- ifelse(mcc_den==0, NA, mcc_num/mcc_den)
  list(acc=acc, f1=f1, bal_acc=bal_acc, mcc=mcc, tp=tp,tn=tn,fp=fp,fn=fn)
}

cat("\n=== ISOT-trained LR-BoW model, scored on WELFake (v2 overlap-filtered), BoW features ===\n")
pred_bow <- as.character(predict(lr_bow_fit, newdata = data.frame(wf_bow_isotvocab, check.names=FALSE)))
m_bow <- metrics_full(pred_bow, as.character(wf_transfer$label))
cat(sprintf("Accuracy=%.4f  F1=%.4f  BalAcc=%.4f  MCC=%.4f\n", m_bow$acc, m_bow$f1, m_bow$bal_acc, m_bow$mcc))
cat("Confusion: TP(Real)=",m_bow$tp," TN(Fake)=",m_bow$tn," FP=",m_bow$fp," FN=",m_bow$fn,"\n")

majority_baseline <- max(mean(wf_transfer$label=="Real"), mean(wf_transfer$label=="Fake"))
cat("Majority-class baseline on this test set:", majority_baseline, "\n")

cat("\n=== Same, LR-TFIDF canonical model ===\n")
lr_tfidf_fit <- readRDS("rds/lr_tfidf_fit.rds")
pred_tfidf <- as.character(predict(lr_tfidf_fit, newdata = data.frame(wf_tfidf_isotvocab, check.names=FALSE)))
m_tfidf <- metrics_full(pred_tfidf, as.character(wf_transfer$label))
cat(sprintf("Accuracy=%.4f  F1=%.4f  BalAcc=%.4f  MCC=%.4f\n", m_tfidf$acc, m_tfidf$f1, m_tfidf$bal_acc, m_tfidf$mcc))

cat("\n=== For comparison: within-WELFake (v2-filtered, own-trained) LR-BoW was 0.9380 (28_wfm_train_v2.R) ===\n")
cat(sprintf("Transfer-test accuracy (%.4f) vs. within-corpus accuracy (0.9380): gap = %.4f points\n",
            m_bow$acc, 100*(0.9380-m_bow$acc)))

# By-class breakdown (is the model just predicting majority class, or genuinely discriminating?)
cat("\nPer-class recall (BoW): Real sensitivity =", m_bow$tp/(m_bow$tp+m_bow$fn),
    " Fake specificity =", m_bow$tn/(m_bow$tn+m_bow$fp), "\n")

saveRDS(list(m_bow=m_bow, m_tfidf=m_tfidf, n=nrow(wf_transfer), majority_baseline=majority_baseline,
             pred_bow=pred_bow, actual=as.character(wf_transfer$label)),
        "rds/isot_to_welfake_transfer_results.rds")
cat("\nDone.\n")
