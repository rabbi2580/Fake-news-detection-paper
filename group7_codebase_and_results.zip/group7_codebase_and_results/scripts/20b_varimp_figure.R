feat <- readRDS("rds/features.rds")
train_tfidf <- feat$train_tfidf
test_tfidf  <- feat$test_tfidf
train_label <- factor(feat$train_docs$label, levels=c("Fake","Real"))
test_label  <- factor(feat$test_docs$label, levels=c("Fake","Real"))
vocab500 <- feat$vocab500
rm(feat); gc()

n_train <- nrow(train_tfidf)
idx_fake <- which(train_label == "Fake")
idx_real <- which(train_label == "Real")
prior <- c(Fake = length(idx_fake)/n_train, Real = length(idx_real)/n_train)

# Gaussian NB per-feature per-class mean/sd (laplace irrelevant for gaussian numeric features)
mean_fake <- colMeans(train_tfidf[idx_fake, , drop=FALSE])
mean_real <- colMeans(train_tfidf[idx_real, , drop=FALSE])
sd_fake   <- apply(train_tfidf[idx_fake, , drop=FALSE], 2, sd)
sd_real   <- apply(train_tfidf[idx_real, , drop=FALSE], 2, sd)
sd_fake[sd_fake < 1e-8] <- 1e-8
sd_real[sd_real < 1e-8] <- 1e-8
cat("Fit done.\n")

n_test <- nrow(test_tfidf)
ld_fake <- matrix(0, n_test, 500)
ld_real <- matrix(0, n_test, 500)
for (j in 1:500) {
  ld_fake[, j] <- dnorm(test_tfidf[, j], mean_fake[j], sd_fake[j], log = TRUE)
  ld_real[, j] <- dnorm(test_tfidf[, j], mean_real[j], sd_real[j], log = TRUE)
}
sum_fake <- rowSums(ld_fake) + log(prior["Fake"])
sum_real <- rowSums(ld_real) + log(prior["Real"])
base_pred <- ifelse(sum_real > sum_fake, "Real", "Fake")
base_acc <- mean(base_pred == as.character(test_label))
cat("Baseline NB-TFIDF (manual Gaussian NB) test accuracy:", base_acc, "\n")

set.seed(456)
imp <- numeric(500)
for (j in 1:500) {
  perm_x <- sample(test_tfidf[, j])
  ld_fake_j <- dnorm(perm_x, mean_fake[j], sd_fake[j], log = TRUE)
  ld_real_j <- dnorm(perm_x, mean_real[j], sd_real[j], log = TRUE)
  sf <- sum_fake - ld_fake[, j] + ld_fake_j
  sr <- sum_real - ld_real[, j] + ld_real_j
  pred <- ifelse(sr > sf, "Real", "Fake")
  acc <- mean(pred == as.character(test_label))
  imp[j] <- base_acc - acc
}
names(imp) <- vocab500
saveRDS(list(imp = imp, base_acc = base_acc), "rds/nb_tfidf_permimp.rds")

top20 <- sort(imp, decreasing = TRUE)[1:20]
cat("Top 20:\n"); print(top20)

dir.create("paper/figures", showWarnings = FALSE, recursive = TRUE)
png("paper/figures/varimp_nb_tfidf.png", width = 1100, height = 900, res = 150)
par(mar = c(4, 7, 2, 1))
barplot(rev(top20), horiz = TRUE, las = 1, col = "#6baed6",
        xlab = "Permutation importance (accuracy drop)",
        main = "Naive Bayes (TF-IDF) permutation variable importance\n(top 20 features, deduplicated corpus)",
        cex.names = 0.85)
dev.off()
cat("Saved varimp_nb_tfidf.png\n")
