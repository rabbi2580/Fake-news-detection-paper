feat <- readRDS("rds/features.rds")
results <- readRDS("rds/model_results.rds")

lr_bow_fit <- results$lr_bow$fit
lr_tfidf_fit <- results$lr_tfidf$fit
vocab500 <- feat$vocab500
test_docs <- feat$test_docs
train_docs <- feat$train_docs
test_bow <- feat$test_bow
train_bow <- feat$train_bow

saveRDS(lr_bow_fit, "rds/lr_bow_fit.rds")
saveRDS(lr_tfidf_fit, "rds/lr_tfidf_fit.rds")
saveRDS(vocab500, "rds/vocab500.rds")
saveRDS(test_docs, "rds/test_docs.rds")
saveRDS(train_docs, "rds/train_docs.rds")
saveRDS(test_bow, "rds/test_bow.rds")
saveRDS(train_bow, "rds/train_bow.rds")
cat("Light objects saved.\n")
print(object.size(lr_bow_fit), units="MB")
print(object.size(test_docs), units="MB")
