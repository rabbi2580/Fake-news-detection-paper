suppressMessages({ library(naivebayes) })

dir.create("paper/figures", showWarnings = FALSE, recursive = TRUE)
outdir <- "paper/figures"

## ---- Fig 1: accuracy_comparison.png ----
acc <- c(0.8792, 0.9013, 0.9738, 0.9740)  # canonical, from 04_train_models.R
labs <- c("NB\nBoW", "NB\nTF-IDF", "LR\nBoW", "LR\nTF-IDF")
png(file.path(outdir, "accuracy_comparison.png"), width=1000, height=700, res=150)
par(mar=c(4,5,2,1))
bp <- barplot(acc, names.arg=labs, ylim=c(0,1), col=c("#9ecae1","#9ecae1","#3182bd","#3182bd"),
              ylab="Test accuracy", main="Test accuracy by model and representation", cex.names=1.0, cex.axis=1.0)
text(bp, acc+0.03, sprintf("%.4f", acc), cex=0.9)
dev.off()
cat("Saved accuracy_comparison.png\n")

## ---- Fig 4 (data-driven, no model needed): agreement_barplot.png ----
means <- c(0.859, 0.530, 0.020, 0.065)
sds   <- c(0.117, 0.206, 0.034, 0.042)
labs2 <- c("Exact coef.\nvs SHAP\n(present)", "Exact coef.\nvs SHAP\n(full vocab)", "Exact coef.\nvs LIME", "SHAP (full)\nvs LIME")
png(file.path(outdir, "agreement_barplot.png"), width=1100, height=750, res=150)
par(mar=c(6,5,2,1))
bp <- barplot(means, names.arg=labs2, ylim=c(0,1.05), col="#74c476",
              ylab="Mean top-10 Jaccard overlap", main="Explanation-method agreement (n=100 docs)",
              las=1, cex.names=0.85)
arrows(bp, means-sds, bp, means+sds, angle=90, code=3, length=0.05)
dev.off()
cat("Saved agreement_barplot.png\n")

## ---- Fig 5: stability_barplot.png ----
means3 <- c(0.083, 0.020, 0.859)
sds3   <- c(0.008, 0.034, 0.117)
labs3 <- c("LIME, same doc\n5 repeats", "LIME vs exact coef.\n100 diff docs", "Exact coef vs SHAP\n(present), 100 diff docs")
png(file.path(outdir, "stability_barplot.png"), width=1100, height=750, res=150)
par(mar=c(7,5,2,1))
bp <- barplot(means3, names.arg=labs3, ylim=c(0,1.05), col=c("#fd8d3c","#9ecae1","#9ecae1"),
              ylab="Mean top-10 Jaccard overlap", main="Tabular-path LIME: self-consistency vs. cross-method agreement",
              las=1, cex.names=0.8)
arrows(bp, means3-sds3, bp, means3+sds3, angle=90, code=3, length=0.05)
dev.off()
cat("Saved stability_barplot.png\n")

## ---- Fig: leakage_ablation_barplot.png ----
acc_full <- c(0.9738, 0.9740)  # canonical, from 21_leakage_ablation_dedup.R
acc_abl  <- c(0.9594, 0.9653)
m <- rbind(acc_full, acc_abl)
colnames(m) <- c("BoW","TF-IDF")
png(file.path(outdir, "leakage_ablation_barplot.png"), width=900, height=700, res=150)
par(mar=c(4,5,2,1))
bp <- barplot(m, beside=TRUE, ylim=c(0.9,1.0), col=c("#3182bd","#de2d26"),
              ylab="Test accuracy", main="Logistic Regression accuracy before/after\nremoving 8 leakage tokens",
              legend.text=c("Full vocabulary","8 tokens removed"), args.legend=list(x="bottomleft", bty="n", cex=0.85))
text(bp, m+0.003, sprintf("%.4f", m), cex=0.8)
dev.off()
cat("Saved leakage_ablation_barplot.png\n")

## ---- Fig 2: varimp_nb_tfidf.png (requires actual permutation importance) ----
feat <- readRDS("rds/features.rds")
train_tfidf <- feat$train_tfidf
test_tfidf <- feat$test_tfidf
train_label <- factor(feat$train_docs$label, levels=c("Fake","Real"))
test_label  <- factor(feat$test_docs$label, levels=c("Fake","Real"))
vocab500 <- feat$vocab500
rm(feat); gc()

set.seed(123)
nb_fit <- naive_bayes(x=as.data.frame(train_tfidf), y=train_label, laplace=0, usekernel=FALSE)
base_pred <- predict(nb_fit, newdata=as.data.frame(test_tfidf))
base_acc <- mean(base_pred == test_label)
cat("Baseline NB-TFIDF test accuracy:", base_acc, "\n")

set.seed(456)
imp <- numeric(500)
test_df <- as.data.frame(test_tfidf)
for (j in 1:500) {
  td <- test_df
  td[[j]] <- sample(td[[j]])
  p <- predict(nb_fit, newdata=td)
  imp[j] <- base_acc - mean(p == test_label)
  if (j %% 100 == 0) cat("done", j, "/500\n")
}
names(imp) <- vocab500
saveRDS(list(imp=imp, base_acc=base_acc), "rds/nb_tfidf_permimp.rds")

top20 <- sort(imp, decreasing=TRUE)[1:20]
png(file.path(outdir, "varimp_nb_tfidf.png"), width=1100, height=900, res=150)
par(mar=c(4,7,2,1))
barplot(rev(top20), horiz=TRUE, las=1, col="#6baed6",
        xlab="Permutation importance (accuracy drop)",
        main="Naive Bayes (TF-IDF) permutation variable importance\n(top 20 features, deduplicated corpus)",
        cex.names=0.85)
dev.off()
cat("Saved varimp_nb_tfidf.png\n")
cat("Top 20:\n"); print(top20)
