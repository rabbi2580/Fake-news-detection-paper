gc()
results <- readRDS("rds/model_results.rds")
lr_bow_fit <- results$lr_bow$fit
lr_tfidf_fit <- results$lr_tfidf$fit
saveRDS(lr_bow_fit, "rds/lr_bow_fit.rds")
saveRDS(lr_tfidf_fit, "rds/lr_tfidf_fit.rds")
cat("Fits saved.\n")
print(object.size(lr_bow_fit), units="MB")
rm(results); gc()
cat("done\n")
