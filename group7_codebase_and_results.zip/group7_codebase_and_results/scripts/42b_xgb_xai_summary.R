# Summarize the XGBoost explanation audit (42_xgb_xai.R) with 95% percentile
# bootstrap CIs over documents (B=2000) and paired tests.
set.seed(2028); B <- 2000
ci <- function(v) quantile(v, c(.025, .975), names = FALSE)
pb <- function(d) 2 * min(mean(d <= 0), mean(d >= 0))
bmean <- function(v) replicate(B, mean(v[sample.int(length(v), length(v), TRUE)]))
f <- function(v) { b <- bmean(v); sprintf("%.3f [%.3f, %.3f]", mean(v), ci(b)[1], ci(b)[2]) }

docs <- do.call(c, lapply(sort(list.files("rds", "^xgb_xai_chunk_[0-9]{3}_[0-9]{3}\\.rds$", full.names = TRUE)), readRDS))
stopifnot(length(docs) == 100, !anyDuplicated(sapply(docs, `[[`, "idx")))
strat <- sapply(docs, `[[`, "stratum"); print(table(strat))

A <- t(sapply(docs, `[[`, "agree"))
cat("\n=== Top-10 agreement (Jaccard), XGBoost-BoW, n=100 ===\n")
lab <- c(shap_lime = "TreeSHAP vs LIME text (5,000)", shap_occ = "TreeSHAP vs occlusion",
         lime_occ = "LIME text vs occlusion", shapfull_shappresent = "TreeSHAP full-vocab vs present-word ranking")
for (k in names(lab)) cat(sprintf("  %-46s %s\n", lab[k], f(A[, k])))
cat(sprintf("  Share of TreeSHAP full-vocab top-10 words ABSENT from the document: %s\n", f(A[, "shapfull_absent_share"])))

aopc <- t(sapply(docs, function(d) colMeans(d$conf)))
na <- aopc[, c("treeshap","lime","occlusion")] - aopc[, "random"]
for (sel in list(list("all (n=100)", rep(TRUE, 100)), list("correct (n=80)", strat != "Misclassified"), list("misclassified (n=20)", strat == "Misclassified"))) {
  X <- na[sel[[2]], , drop = FALSE]
  cat(sprintf("\n=== Normalized AOPC, %s ===\n", sel[[1]]))
  for (m in colnames(X)) cat(sprintf("  %-10s %s\n", m, f(X[, m])))
  for (p in list(c("treeshap","lime"), c("occlusion","treeshap"), c("occlusion","lime"))) {
    dv <- X[, p[1]] - X[, p[2]]; b <- bmean(dv)
    w <- suppressWarnings(wilcox.test(X[, p[1]], X[, p[2]], paired = TRUE))$p.value
    cat(sprintf("  %-9s - %-9s %+.4f [%+.4f, %+.4f]  bootstrap p=%.4f  Wilcoxon p=%.3g\n", p[1], p[2], mean(dv), ci(b)[1], ci(b)[2], pb(b), w))
  }
}

st <- sapply(docs, `[[`, "stab"); ss <- strat[!is.na(st)]; st <- st[!is.na(st)]
cat(sprintf("\n=== LIME text-mode stability on XGBoost, 5 reruns @5,000 (n=%d) ===\n  all: %s\n", length(st), f(st)))
for (s in unique(ss)) cat(sprintf("  %-14s %s (n=%d)\n", s, f(st[ss == s]), sum(ss == s)))

# global picture: which words most often appear in each method's top-10
cat("\n=== Most frequent top-10 words across the 100 documents ===\n")
for (m in c("treeshap","lime")) { w <- table(unlist(lapply(docs, function(d) d$top10[[m]])))
  cat(sprintf("  %-9s %s\n", m, paste(names(sort(w, decreasing = TRUE))[1:12], collapse = ", "))) }
saveRDS(list(agree = A, naopc = na, strat = strat, stab = st), "rds/xgb_xai_summary.rds")
cat("\nDone.\n")
