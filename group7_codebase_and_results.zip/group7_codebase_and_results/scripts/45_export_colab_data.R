suppressMessages({ library(stringr) })
Sys.setlocale("LC_CTYPE", "C.UTF-8")   # same UTF-8 safeguard as 06_export_bert_data.R

# Exports the two extra evaluation sets for the DistilBERT Colab notebook
# (the ISOT train/test CSVs already exist from 06_export_bert_data.R):
#   welfake_v2_transfer.csv : 42,448 WELFake articles with no ISOT match
#   ccnews_probe.csv        : 5,013 mainstream real-news articles, 10 publishers
# Text gets the same dateline strip as the ISOT BERT input; flags mark the
# dateline-artifact tokens (computed on the cleaned/stemmed text, as in 31b).
strip <- function(x) str_replace(x, "^[A-Za-z\\.,' ]+\\(Reuters\\)\\s*-\\s*", "")
wd <- c("monday","tuesday","wednesday","thursday","friday","saturday","sunday")
flags <- function(tf) { tok <- strsplit(tf, "\\s+")
  data.frame(has_reuter = vapply(tok, function(w) "reuter" %in% w, logical(1)),
             has_artifact = vapply(tok, function(w) any(c("reuter", wd) %in% w), logical(1))) }

sp <- readRDS("rds/welfake_minus_overlap_split_v2.rds"); wf <- rbind(sp$wfm_train, sp$wfm_test)
out <- data.frame(text = strip(wf$text), label = as.integer(wf$label == "Real"), flags(wf$text_final),
                  split = rep(c("wfm_train","wfm_test"), c(nrow(sp$wfm_train), nrow(sp$wfm_test))))
write.csv(out, "data2/welfake_v2_transfer.csv", row.names = FALSE, fileEncoding = "UTF-8")
cat("welfake_v2_transfer.csv:", nrow(out), "rows,", round(100 * mean(out$label), 2), "% Real\n")

cc <- readRDS("rds/ccnews_probe.rds")$data
raw <- read.csv("data3/ccnews_2017_mainstream_sample.csv", stringsAsFactors = FALSE, encoding = "UTF-8")
stopifnot(nrow(raw) == nrow(cc), identical(raw$domain, cc$domain))
write.csv(data.frame(text = strip(raw$text), domain = raw$domain, label = 1L, has_reuter = cc$has_reuter),
          "data2/ccnews_probe.csv", row.names = FALSE, fileEncoding = "UTF-8")
cat("ccnews_probe.csv:", nrow(raw), "rows\n")
chk <- readLines("data2/welfake_v2_transfer.csv", n = 3000, encoding = "UTF-8")
cat("Corruption-pattern check (<U+XXXX>) in first 3000 lines:", sum(grepl("<U\\+[0-9A-Fa-f]{4}>", chk)), "\n")
