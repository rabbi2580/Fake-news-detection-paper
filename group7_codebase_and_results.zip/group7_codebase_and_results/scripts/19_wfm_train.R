suppressMessages({ library(glmnet); library(naivebayes) })
split <- readRDS("rds/welfake_minus_overlap_split.rds")
wfm_train <- split$wfm_train; wfm_test <- split$wfm_test
wfm_train_bow <- readRDS("rds/wfm_train_bow.rds")
wfm_test_bow <- readRDS("rds/wfm_test_bow.rds")

N_train <- nrow(wfm_train_bow); df_train <- colSums(wfm_train_bow>0)
idf <- log2(N_train/df_train); idf[is.infinite(idf)] <- 0
tfidf_from_bow <- function(bow, idfv) { rs<-rowSums(bow); rs[rs==0]<-1; sweep(bow/rs,2,idfv,`*`) }
wfm_train_tfidf <- tfidf_from_bow(wfm_train_bow, idf)
wfm_test_tfidf <- tfidf_from_bow(wfm_test_bow, idf)
saveRDS(idf, "rds/wfm_idf.rds")
saveRDS(wfm_train_tfidf, "rds/wfm_train_tfidf.rds")
saveRDS(wfm_test_tfidf, "rds/wfm_test_tfidf.rds")

y_train <- ifelse(wfm_train$label=="Real",1,0)
lambda_grid <- 10^seq(log10(1e-4), log10(1e-1), length.out=10)
fit_lr <- function(X,y,seed=123) {
  set.seed(seed)
  cvfit <- cv.glmnet(X,y,family="binomial",alpha=1,lambda=lambda_grid,nfolds=5,type.measure="class")
  final <- glmnet(X,y,family="binomial",alpha=1,lambda=cvfit$lambda.min)
  list(fit=final, lambda=cvfit$lambda.min)
}
metrics_full <- function(pred, actual, positive="Real") {
  tp <- sum(pred==positive & actual==positive); tn <- sum(pred!=positive & actual!=positive)
  fp <- sum(pred==positive & actual!=positive); fn <- sum(pred!=positive & actual==positive)
  acc <- (tp+tn)/(tp+tn+fp+fn)
  prec <- tp/(tp+fp); rec <- tp/(tp+fn); f1 <- 2*prec*rec/(prec+rec)
  sens <- tp/(tp+fn); spec <- tn/(tn+fp); bal_acc <- (sens+spec)/2
  mcc_num <- (tp*tn - fp*fn); mcc_den <- sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
  mcc <- ifelse(mcc_den==0, NA, mcc_num/mcc_den)
  f1_fake <- {tp2<-tn; fp2<-fn; fn2<-fp; prec2<-tp2/(tp2+fp2); rec2<-tp2/(tp2+fn2); 2*prec2*rec2/(prec2+rec2)}
  macro_f1 <- mean(c(f1, f1_fake))
  list(acc=acc, f1=f1, bal_acc=bal_acc, mcc=mcc, macro_f1=macro_f1)
}

lr_bow <- fit_lr(wfm_train_bow, y_train)
pred_bow <- ifelse(as.numeric(predict(lr_bow$fit, newx=wfm_test_bow, type="response"))>0.5,"Real","Fake")
m_lr_bow <- metrics_full(pred_bow, as.character(wfm_test$label))
cat("LR-BoW (lambda=",lr_bow$lambda,"): acc=",m_lr_bow$acc," f1=",m_lr_bow$f1," macroF1=",m_lr_bow$macro_f1," balAcc=",m_lr_bow$bal_acc," MCC=",m_lr_bow$mcc,"\n")

lr_tfidf <- fit_lr(wfm_train_tfidf, y_train)
pred_tfidf <- ifelse(as.numeric(predict(lr_tfidf$fit, newx=wfm_test_tfidf, type="response"))>0.5,"Real","Fake")
m_lr_tfidf <- metrics_full(pred_tfidf, as.character(wfm_test$label))
cat("LR-TFIDF (lambda=",lr_tfidf$lambda,"): acc=",m_lr_tfidf$acc," f1=",m_lr_tfidf$f1," macroF1=",m_lr_tfidf$macro_f1," balAcc=",m_lr_tfidf$bal_acc," MCC=",m_lr_tfidf$mcc,"\n")

saveRDS(list(lr_bow=lr_bow, lr_tfidf=lr_tfidf, m_lr_bow=m_lr_bow, m_lr_tfidf=m_lr_tfidf), "rds/wfm_lr_results.rds")
rm(wfm_train_bow, wfm_test_bow, wfm_train_tfidf, wfm_test_tfidf); gc()
cat("Done LR.\n")
