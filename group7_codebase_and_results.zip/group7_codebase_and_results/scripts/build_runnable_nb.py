# Builds group7_pipeline_runnable.ipynb: the whole R pipeline as runnable cells,
# one script per cell, in dependency order, from raw data to every paper number.
import nbformat as nbf, os, re

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = lambda n: open(os.path.join(PROJ, "scripts", n)).read().rstrip() + "\n"
cells = []
md = lambda s: cells.append(nbf.v4.new_markdown_cell(s.strip()))
CLEAN = "rm(list = ls()); invisible(gc())\n"

def body(name):
    src = S(name).replace("commandArgs(trailingOnly = TRUE)", "CELL_ARGS")
    if name == "23_vocab_size_sweep_dedup.R":   # the 2,482-term point runs out of memory here; cell 23b does it
        old = "sizes <- c(500, 1000, length(vocab_full))  # 500 = canonical baseline, full = 2,482"
        assert old in src
        src = src.replace(old, "sizes <- c(500, 1000)  # 500 = canonical baseline; the full 2,482-term point is the next cell (23b), sparse, to avoid running out of memory")
    return src

def run(name, args=None, loop=None, note=None):
    head = f"# ===== scripts/{name} =====\n" + (f"# {note}\n" if note else "")
    src = body(name)
    if loop is not None:
        lst = ", ".join("c(" + ", ".join(f'"{a}"' for a in x) + ")" for x in loop)
        code = head + CLEAN + f"for (CELL_ARGS in list({lst})) {{\n" + src + "}\n"
    else:
        pre = ("CELL_ARGS <- c(" + ", ".join(f'"{a}"' for a in args) + ")\n") if args else ""
        code = head + CLEAN + pre + src
    assert ("CELL_ARGS" in code) == ("commandArgs" in S(name)), name
    cells.append(nbf.v4.new_code_cell(code.rstrip()))

def py(name, path, run_dir, cmd, toggle=None, pip=None, imports=None):
    code = open(os.path.join(PROJ, path)).read()
    assert ")---\"" not in code
    lines = [f"# ===== {name} (Python, run from R) =====", CLEAN.strip()]
    if toggle: lines += [f"{toggle} <- FALSE   # set TRUE to run this step", f"if ({toggle}) {{"]
    lines += [f'py_code <- r"---({code.rstrip()}\n)---"', f'writeLines(py_code, "{path}")']
    if pip: lines += [f'cat(system("python3 -c \'import {imports}\' 2>/dev/null || python3 -m pip install -q {pip} 2>&1", intern = TRUE), sep = "\\n")   # install only if missing']
    lines += [f'out <- system("cd {run_dir} && {cmd} 2>&1", intern = TRUE)', 'cat(tail(out, 60), sep = "\\n")']
    if toggle: lines += ["} else cat(\"Skipped (toggle is FALSE).\\n\")"]
    cells.append(nbf.v4.new_code_cell("\n".join(lines)))

md("""# Group 7: full pipeline, runnable cell by cell (raw data → every number in the paper)

**Kernel: R (IRkernel).** Works in Jupyter / VS Code with the R kernel, in Google Colab with the
*R* runtime, or by pasting each cell into RStudio in order. Every cell is self-contained: it reads its
inputs from `rds/` and writes its outputs back there, so a cell can be re-run on its own once the
cells above it have run once.

Before you start:
1. Put the raw data in the project folder (set `PROJECT_DIR` in the first cell):
   `data/True.csv`, `data/Fake.csv` (ISOT) and `data2/welfake_raw.csv` (WELFake_Dataset.csv, renamed).
2. Run the cells **top to bottom**. Total time is roughly 2–3 hours on a 2-core / 8 GB machine
   (slowest: the LIME cells and the five-seed cell). The optional CPU DistilBERT cell adds ~2 hours.
3. Every R-based number in the paper (v12) comes from the canonical run: R 4.6.1 with the package
   versions printed by the setup cell (`renv.lock` and `Dockerfile` in the repository pin this
   environment). A different environment can shift accuracies in the third decimal, the selected
   lambda, and the significance of small effects. An independent Google Colab run of an earlier
   revision of this notebook gave NB-BoW 0.8777 (canonical 0.8792), an 8-token ablation drop of
   1.19 points (canonical 1.44), no significant exact-minus-SHAP/LIME faithfulness difference for
   Logistic Regression, and no significant occlusion-minus-LIME difference for XGBoost (+0.019,
   CI -0.014 to +0.052), while the headline findings did not change: WELFake transfer 79.6%
   (79.35%), CC-News non-Reuters 44.7% (43.0%), real WELFake articles with / without Reuters
   markers 99.4% / 26.3% (99.3% / 25.8%).

`00_extract_light_objects.R`, `13_before_features_train.R` and `19_wfm_train.R` are left out on
purpose: their outputs are superseded by `00b`/`00c`, `13a`–`13c` and `19b`, and nothing downstream
reads them.""")

md("## 0. Setup: project folder, packages, raw-data check")
cells.append(nbf.v4.new_code_cell(r'''PROJECT_DIR <- "~/group7_project"   # <-- change to your folder (Colab R runtime: "/content/group7_project")
dir.create(PROJECT_DIR, recursive = TRUE, showWarnings = FALSE); setwd(PROJECT_DIR)
for (d in c("data", "data2", "data3", "rds", "logs", "scripts", "paper/figures"))
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
cat("Working directory:", getwd(), "\n")

pkgs <- c("dplyr", "stringr", "tm", "SnowballC", "caret", "e1071", "glmnet", "naivebayes",
          "lime", "slam", "Matrix", "LiblineaR", "xgboost")
# On Linux, Posit Package Manager serves prebuilt binaries (xgboost otherwise compiles for a long time)
osr <- if (file.exists("/etc/os-release")) readLines("/etc/os-release") else character(0)
cn <- sub("^VERSION_CODENAME=", "", grep("^VERSION_CODENAME=", osr, value = TRUE))
if (Sys.info()[["sysname"]] == "Linux" && length(cn) == 1 && nzchar(cn)) {
  options(repos = c(CRAN = sprintf("https://packagemanager.posit.co/cran/__linux__/%s/latest", cn)),
          HTTPUserAgent = sprintf("R/%s R (%s)", getRversion(),
                                  paste(getRversion(), R.version$platform, R.version$arch, R.version$os)))
} else options(repos = c(CRAN = "https://cloud.r-project.org"))
miss <- setdiff(pkgs, rownames(installed.packages()))
if (length(miss)) install.packages(miss, Ncpus = max(1L, parallel::detectCores()))

# exact versions of the canonical run (R 4.6.1); renv.lock pins the full dependency tree
pinned <- c(dplyr = "1.2.1", stringr = "1.6.0", tm = "0.7-20", SnowballC = "0.7.1", caret = "7.0-1",
            e1071 = "1.7-17", glmnet = "5.1", naivebayes = "1.0.0", lime = "0.5.4", slam = "0.1-56",
            Matrix = "1.7-6", LiblineaR = "2.10-26", xgboost = "3.2.1.1")
ip <- installed.packages()
print(data.frame(installed = ip[pkgs, "Version"], canonical_run = pinned[pkgs]))
cat(R.version.string, "(canonical run: R 4.6.1)\n")

# lime checks whether each input string is an image FILE PATH before explaining it as text. On newer R
# versions that check warns "expanded path length ... would be too long" for every long document
# (harmless, but it floods the output). Our inputs are never image files, so skip the check.
# Results are unchanged: the check returned FALSE for these inputs anyway.
invisible(loadNamespace("lime"))
assignInNamespace("is.image_file", function(x) FALSE, ns = "lime")

need <- c("data/True.csv", "data/Fake.csv", "data2/welfake_raw.csv")
if (any(!file.exists(need)))
  stop("Missing raw data: ", paste(need[!file.exists(need)], collapse = ", "),
       "\n  ISOT True.csv + Fake.csv -> data/ ;  WELFake_Dataset.csv -> data2/welfake_raw.csv")
cat("Raw data found. Ready.\n")'''))

md("## 1. ISOT corpus: load, exact-dedup, dateline-strip, clean, split, features, canonical models (Table I)")
for n in ["01_build_corpus.R", "02_clean_corpus.R", "03_split_features_models.R", "04_train_models.R"]: run(n)

md("## 2. Light cached objects used by the explanation scripts")
for n in ["00b_extract_fits.R", "00c_light_refit.R", "00d_train_means.R"]: run(n)

md("## 3. Pre-dedup comparison and composition-shift decomposition")
for n in ["12_before_pipeline.R", "13a_before_vocab_bow.R", "13b_before_tfidf_lr.R", "13c_before_nb.R",
          "14_composition_shift_test.R"]: run(n)

md("## 4. Leakage ablation (8 source-artifact tokens)")
for n in ["21_leakage_ablation_dedup.R", "22_leakage_ablation_curve_fix.R"]: run(n)

md("## 5. Vocabulary-size sweep and time-aware split")
for n in ["23_vocab_size_sweep_dedup.R", "23b_vocab_sweep_full2482.R", "24_time_aware_split_dedup.R"]: run(n)

md("## 6. LIME: tabular-path misspecification vs text mode; deletion faithfulness and AOPC")
for n in ["07_lime_textmode_setup.R", "08_lime_text_core.R", "09_lime_text_stability.R",
          "10_deletion_faithfulness_v2.R", "11_deletion_curve_full.R"]: run(n)

md("## 7. WELFake: load, overlap audit with ISOT (v1 and strengthened v2), within-corpus models")
for n in ["05_welfake_pipeline.R", "15_overlap_check.R", "16_welfake_clean.R", "29_welfake_full_train.R",
          "25_overlap_check_v2.R", "17b_overlap_breakdown.R"]: run(n)

md("## 8. WELFake minus ISOT overlap (WFM): v1 (exact match) and v2 (exact + normalized + near-duplicate)")
for n in ["17_welfake_minus_overlap_split.R", "18_wfm_features.R", "19b_wfm_train_fast.R",
          "19c_wfm_fix_mcc_coefs.R", "19d_wfm_nb.R", "26_welfake_minus_overlap_v2.R",
          "27_wfm_features_v2.R", "28_wfm_train_v2.R"]: run(n)

md("""## 9. DistilBERT, original single CPU run (optional)
`06` exports the CSVs. The training cell is **off by default** (about 2 hours on CPU). The GPU notebook
`distilbert_retrain_transfer_colab.ipynb` (section 21) repeats this with 3 seeds and adds the transfer tests.""")
run("06_export_bert_data.R")
py("scripts/train_distilbert_full.py", "scripts/train_distilbert_full.py", ".", "python3 scripts/train_distilbert_full.py",
   toggle="RUN_DISTILBERT_CPU", pip="torch transformers datasets accelerate scikit-learn pandas", imports="torch, transformers, datasets, accelerate, sklearn, pandas")

md("## 10. Figures")
for n in ["20_make_figures.R", "20b_varimp_figure.R", "30_fix_figures.R"]: run(n)

md("## 11. Stronger baselines: linear SVM and XGBoost (BoW, then TF-IDF)")
run("34_svm_baseline.R")
run("35_xgboost_baseline.R", loop=[["bow"], ["tfidf"]])

md("## 12. Cross-corpus transfer: ISOT-trained models on WELFake v2 (no ISOT match)")
for n in ["31_isot_to_welfake_transfer.R", "31b_transfer_mechanism.R", "36_transfer_all_models.R",
          "36b_transfer_macro_f1.R"]: run(n)

md("## 13. Label agreement of overlapping ISOT/WELFake articles, and bootstrap CIs")
for n in ["32_overlap_label_agreement.R", "33_bootstrap_ci.R"]: run(n)

md("""## 14. 300-document explanation replication
Runs in chunks of 50 documents. Per-document seeds depend only on the document's position, so the
chunking does not change any result (the same cell run in five chunks of different sizes gives identical output).""")
run("37_xai_expanded.R", loop=[[str(a), str(a + 49)] for a in range(1, 300, 50)], note="300 documents in 6 chunks of 50 (~30-40 min in total)")
run("37b_xai_expanded_summary.R")

md("## 15. Agreement (part A, 100 docs) and tabular-LIME stability/collapse (part B); Fig. 2")
run("38_agreement_tabular_rerun.R", loop=[["A", "1", "50"], ["A", "51", "100"], ["B"]])
for n in ["38b_agreement_summary.R", "39_lime_collapse_figure.R"]: run(n)

md("## 16. Confusion matrices, McNemar/Holm, top words, misc. paper statistics")
run("40_paper_extra_stats.R")

md("## 17. Five random splits (seeds 123, 2024, 7, 42, 999)")
run("41_multiseed.R", loop=[["123"], ["2024"], ["7"], ["42"], ["999"]], note="~8 min per seed")
run("41b_multiseed_summary.R")

md("## 18. Non-linear explanation audit: XGBoost TreeSHAP vs text-mode LIME vs occlusion (100 docs)")
run("42_xgb_xai.R", loop=[["1", "50"], ["51", "100"]])
run("42b_xgb_xai_summary.R")

md("## 19. Real news from 10 other publishers (CC-News probe)")
py("data3/ccnews_extract.py", "data3/ccnews_extract.py", "data3", "python3 ccnews_extract.py", pip="pandas pyarrow", imports="pandas, pyarrow")
run("43_ccnews_publisher_probe.R")

md("## 20. Reverse transfer (WELFake → ISOT) and remaining CIs")
for n in ["44_reverse_transfer.R", "46_extra_cis.R"]: run(n)

md("""## 21. Export data for the GPU DistilBERT notebook
Writes `data2/welfake_v2_transfer.csv` and `data2/ccnews_probe.csv`. Zip them together with
`data2/bert_train_full.csv` and `data2/bert_test.csv` and use `distilbert_retrain_transfer_colab.ipynb`
on a Colab T4 GPU.""")
run("45_export_colab_data.R")

nb = nbf.v4.new_notebook(); nb["cells"] = cells
nb["metadata"] = {"kernelspec": {"name": "ir", "display_name": "R", "language": "R"},
                  "language_info": {"name": "R"}}
nbf.validate(nb)
out = os.path.join(PROJ, "group7_pipeline_runnable.ipynb"); nbf.write(nb, out)
print("ok", len(cells), "cells,", sum(c.cell_type == "code" for c in cells), "code")
