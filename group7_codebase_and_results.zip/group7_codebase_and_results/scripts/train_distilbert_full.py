import time, json, os
t0 = time.time()
import pandas as pd
import numpy as np
import torch
from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification, Trainer, TrainingArguments
from torch.utils.data import Dataset

torch.manual_seed(2025)

train_df = pd.read_csv('data2/bert_train_full.csv')
test_df = pd.read_csv('data2/bert_test.csv')
print(f"Train: {len(train_df)}, Test: {len(test_df)}", flush=True)

tokenizer = DistilBertTokenizerFast.from_pretrained('distilbert-base-uncased')

class TextDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_len=128):
        self.texts = list(texts)
        self.labels = list(labels)
        self.tokenizer = tokenizer
        self.max_len = max_len
    def __len__(self):
        return len(self.texts)
    def __getitem__(self, idx):
        enc = self.tokenizer(str(self.texts[idx]), truncation=True, padding='max_length', max_length=self.max_len, return_tensors='pt')
        item = {k: v.squeeze(0) for k, v in enc.items()}
        item['labels'] = torch.tensor(self.labels[idx], dtype=torch.long)
        return item

train_ds = TextDataset(train_df['text'], train_df['label'], tokenizer)
test_ds = TextDataset(test_df['text'], test_df['label'], tokenizer)

model = DistilBertForSequenceClassification.from_pretrained('distilbert-base-uncased', num_labels=2)

args = TrainingArguments(
    output_dir='bert_out_full',
    num_train_epochs=1,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=32,
    learning_rate=5e-5,
    logging_steps=200,
    save_strategy='no',
    eval_strategy='no',
    report_to=[],
    use_cpu=True,
    dataloader_num_workers=2,
)

def compute_metrics(eval_pred):
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=1)
    return {
        'accuracy': accuracy_score(labels, preds),
        'f1': f1_score(labels, preds),
        'precision': precision_score(labels, preds),
        'recall': recall_score(labels, preds),
    }

trainer = Trainer(model=model, args=args, train_dataset=train_ds, eval_dataset=test_ds, compute_metrics=compute_metrics)

print(f"Setup done at {time.time()-t0:.1f}s. Starting training on {len(train_ds)} docs, 1 epoch...", flush=True)
trainer.train()
print(f"Training done at {time.time()-t0:.1f}s. Evaluating...", flush=True)
metrics = trainer.evaluate()
print("EVAL METRICS:", json.dumps(metrics), flush=True)

with open('rds/distilbert_full_metrics.json', 'w') as f:
    json.dump(metrics, f, indent=2)

print(f"Total time: {time.time()-t0:.1f}s", flush=True)
