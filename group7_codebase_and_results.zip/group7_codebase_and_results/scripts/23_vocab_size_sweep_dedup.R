suppressMessages({ library(tm); library(caret); library(glmnet) })

# Reproducible vocabulary-size sweep on the FINAL deduplicated corpus.
# Supersedes an earlier, undocumented sweep whose script no longer exists and
# whose reported numbers (97.45%->98.17%) do not match this pipeline's
# canonical baseline (97.38%) or any surviving log file.

feat <- readRDS("rds/features.rds")
train_docs <- feat$train_docs; test_docs <- feat$test_docs
y_train <- train_docs$label; y_test <- test_docs$label

# Rebuild the full-sparsity-pruned vocabulary (2,482 terms) from TRAIN only,
# exactly as in 03_split_features_models.R but without truncating to top-500.
train_corpus <- VCorpus(VectorSource(train_docs$text_final))
train_dtm <- DocumentTermMatrix(train_corpus)
train_dtm_pruned <- removeSparseTerms(train_dtm, 0.99)
cat("Terms surviving 0.99 sparsity pruning:", ncol(train_dtm_pruned), "\n")
train_mat <- as.matrix(train_dtm_pruned)
term_freq <- colSums(train_mat)
vocab_full <- names(sort(term_freq, decreasing = TRUE))  # all terms, ranked by frequency
rm(train_dtm, train_dtm_pruned, train_corpus); gc()

build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control = list(dictionary = vocab))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab, colnames(mat))
  if (length(missing_cols) > 0) {
    addmat <- matrix(0, nrow = nrow(mat), ncol = length(missing_cols), dimnames = list(NULL, missing_cols))
    mat <- cbind(mat, addmat)
  }
  mat[, vocab, drop = FALSE]
}

cv_ctrl <- trainControl(method="cv", number=5)
lambda_grid <- 10^seq(log10(1e-4), log10(1e-1), length.out=10)
fit_lr_caret <- function(X, y, seed=123) {
  set.seed(seed)
  df <- data.frame(X, label=y, check.names=FALSE)
  train(label ~ ., data=df, method="glmnet", family="binomial",
        trControl=cv_ctrl, tuneGrid=expand.grid(alpha=1, lambda=lambda_grid))
}
eval_caret <- function(fit, X, y) {
  pred <- predict(fit, data.frame(X, check.names=FALSE))
  mean(pred == y)
}

sizes <- c(500, 1000, length(vocab_full))  # 500 = canonical baseline, full = 2,482
results <- data.frame(vocab_size=sizes, accuracy=NA_real_, f1=NA_real_, lambda=NA_real_)

for (i in seq_along(sizes)) {
  k <- sizes[i]
  vocab_k <- vocab_full[1:k]
  cat(sprintf("\n== vocab size = %d ==\n", k))
  train_bow_k <- build_bow(train_docs$text_final, vocab_k)
  test_bow_k  <- build_bow(test_docs$text_final, vocab_k)
  fit_k <- fit_lr_caret(train_bow_k, y_train)
  pred_k <- predict(fit_k, data.frame(test_bow_k, check.names=FALSE))
  acc_k <- mean(pred_k == y_test)
  cm <- caret::confusionMatrix(factor(pred_k, levels=c("Fake","Real")), factor(y_test, levels=c("Fake","Real")), positive="Real")
  f1_k <- cm$byClass["F1"]
  results$accuracy[i] <- acc_k; results$f1[i] <- f1_k; results$lambda[i] <- fit_k$bestTune$lambda
  cat(sprintf("vocab=%d  LR-BoW accuracy=%.4f  F1=%.4f  lambda=%g\n", k, acc_k, f1_k, fit_k$bestTune$lambda))
  rm(train_bow_k, test_bow_k, fit_k); gc()
}

cat("\n=== Vocab-size sweep summary (LR, BoW) ===\n")
print(results)
saveRDS(results, "rds/vocab_size_sweep_dedup.rds")
cat("\nDone.\n")
