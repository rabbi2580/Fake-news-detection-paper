suppressMessages({ library(caret); library(glmnet) })

# Nonparametric bootstrap 95% CIs (percentile, B=2000) for every headline
# comparison in the paper, resampling the unit the claim is about:
#   - test DOCUMENTS for accuracy and accuracy differences (paired: same
#     resampled docs for both models);
#   - explained DOCUMENTS (n=97) for AOPC and AOPC differences (paired);
#   - explained DOCUMENTS (n=20) for LIME same-document stability.
# A paired difference whose CI excludes 0 is reported as significant at 5%;
# a Wilcoxon signed-rank test is given alongside the AOPC differences as a
# second, non-bootstrap check.

set.seed(2024)
B <- 2000
ci <- function(v) quantile(v, c(0.025, 0.975), names = FALSE)
fmt <- function(est, lo, hi, d = 4) sprintf(paste0("%.", d, "f  [%.", d, "f, %.", d, "f]"), est, lo, hi)
boot_acc <- function(correct) { n <- length(correct); replicate(B, mean(correct[sample.int(n, n, TRUE)])) }
boot_paired <- function(c1, c2) { n <- length(c1); replicate(B, { i <- sample.int(n, n, TRUE); mean(c1[i]) - mean(c2[i]) }) }
p_boot <- function(d) { 2 * min(mean(d <= 0), mean(d >= 0)) }   # two-sided bootstrap p

out <- list()

## ---------------- 1. ISOT test-set accuracy (n = 7,718) ----------------
cat("=== 1. Accuracy, ISOT deduplicated test set (n=7,718), 95% bootstrap CI ===\n")
res <- readRDS("rds/model_results.rds")
feat <- readRDS("rds/features.rds")
y <- as.character(feat$test_docs$label)
corr <- lapply(res, function(r) as.character(r$pred) == y)
for (nm in names(corr)) {
  b <- boot_acc(corr[[nm]]); out[[paste0("acc_", nm)]] <- c(mean(corr[[nm]]), ci(b))
  cat(sprintf("  %-9s %s\n", nm, fmt(mean(corr[[nm]]), ci(b)[1], ci(b)[2])))
}
cat("\n  Paired differences:\n")
pairs <- list(c("lr_bow","nb_bow"), c("lr_tfidf","nb_tfidf"), c("nb_tfidf","nb_bow"), c("lr_tfidf","lr_bow"))
for (p in pairs) {
  d <- boot_paired(corr[[p[1]]], corr[[p[2]]]); est <- mean(corr[[p[1]]]) - mean(corr[[p[2]]])
  out[[paste0("diff_", p[1], "_", p[2])]] <- c(est, ci(d))
  cat(sprintf("  %-9s - %-9s %s pts  (bootstrap p=%.4f)\n", p[1], p[2],
              fmt(100*est, 100*ci(d)[1], 100*ci(d)[2], 2), p_boot(d)))
}

## ---------------- 2. Leakage ablation drop (paired, n = 7,718) ----------------
cat("\n=== 2. Leakage-ablation accuracy drop (8 tokens, BoW), paired over test docs ===\n")
abl <- readRDS("rds/leakage_ablation_dedup.rds")
keep <- setdiff(feat$vocab500, c("reuter","monday","tuesday","wednesday","thursday","friday","saturday","sunday"))
p_full <- as.character(predict(abl$fit_full_bow, data.frame(feat$test_bow, check.names = FALSE)))
p_abl  <- as.character(predict(abl$fit_abl_bow,  data.frame(feat$test_bow[, keep], check.names = FALSE)))
c_full <- p_full == y; c_abl <- p_abl == y
d <- boot_paired(c_full, c_abl); est <- mean(c_full) - mean(c_abl)
out$ablation_drop <- c(est, ci(d))
cat(sprintf("  Full %.4f -> ablated %.4f; drop %s pts\n", mean(c_full), mean(c_abl), fmt(100*est, 100*ci(d)[1], 100*ci(d)[2], 2)))
rm(feat, res, abl); gc(verbose = FALSE)

## ---------------- 3. Cross-dataset transfer (ISOT -> WELFake v2) ----------------
cat("\n=== 3. ISOT-trained LR-BoW on WELFake (v2 overlap-filtered, n=42,448) ===\n")
tr <- readRDS("rds/isot_to_welfake_transfer_results.rds")
c_tr <- tr$pred_bow == tr$actual
b <- boot_acc(c_tr); out$transfer_acc <- c(mean(c_tr), ci(b))
cat(sprintf("  Accuracy %s\n", fmt(mean(c_tr), ci(b)[1], ci(b)[2])))
balacc <- function(pred, act) { (mean(pred[act=="Real"]=="Real") + mean(pred[act=="Fake"]=="Fake")) / 2 }
n <- length(c_tr)
bb <- replicate(B, { i <- sample.int(n, n, TRUE); balacc(tr$pred_bow[i], tr$actual[i]) })
out$transfer_balacc <- c(balacc(tr$pred_bow, tr$actual), ci(bb))
cat(sprintf("  Balanced accuracy %s\n", fmt(balacc(tr$pred_bow, tr$actual), ci(bb)[1], ci(bb)[2])))

# Paired gap on the WELFake v2 TEST docs (n=8,489): WELFake-trained vs ISOT-trained, same docs.
sp <- readRDS("rds/welfake_minus_overlap_split_v2.rds")
n_tr <- nrow(sp$wfm_train); n_te <- nrow(sp$wfm_test)
iso_te <- tr$pred_bow[(n_tr + 1):(n_tr + n_te)]; act_te <- tr$actual[(n_tr + 1):(n_tr + n_te)]
stopifnot(identical(act_te, as.character(sp$wfm_test$label)))
wr <- readRDS("rds/wfm_results_v2.rds"); Xte <- readRDS("rds/wfm_test_bow_v2.rds")
wf_te <- ifelse(as.numeric(predict(wr$lr_bow_fit, newx = Xte, type = "response")) > 0.5, "Real", "Fake")
c_w <- wf_te == act_te; c_i <- iso_te == act_te
d <- boot_paired(c_w, c_i); est <- mean(c_w) - mean(c_i)
out$within_minus_transfer <- c(est, ci(d))
cat(sprintf("  On the same %d WELFake v2 test docs: within-WELFake %.4f vs ISOT-transfer %.4f; gap %s pts\n",
            n_te, mean(c_w), mean(c_i), fmt(100*est, 100*ci(d)[1], 100*ci(d)[2], 2)))

## ---------------- 4. Normalized AOPC, per-document paired (n = 97) ----------------
cat("\n=== 4. Normalized AOPC, n=97 valid documents, paired bootstrap over documents ===\n")
dc <- readRDS("rds/deletion_curve_full.rds")
A <- dc$conf_drop_arr[dc$valid, , , drop = FALSE]   # same quantity as the paper's AOPC (11_deletion_curve_full.R uses conf_drop_arr)
aopc_doc <- apply(A, c(1, 3), mean)                      # docs x methods, mean over k=1..10
naopc_doc <- aopc_doc[, c("exact","shap","lime")] - aopc_doc[, "random"]
nd <- nrow(naopc_doc)
for (m in colnames(naopc_doc)) {
  b <- replicate(B, mean(naopc_doc[sample.int(nd, nd, TRUE), m]))
  out[[paste0("naopc_", m)]] <- c(mean(naopc_doc[, m]), ci(b))
  cat(sprintf("  %-6s %s\n", m, fmt(mean(naopc_doc[, m]), ci(b)[1], ci(b)[2])))
}
cat("\n  Paired differences in normalized AOPC:\n")
for (p in list(c("exact","shap"), c("exact","lime"), c("lime","shap"))) {
  dv <- naopc_doc[, p[1]] - naopc_doc[, p[2]]
  b <- replicate(B, mean(dv[sample.int(nd, nd, TRUE)]))
  w <- suppressWarnings(wilcox.test(naopc_doc[, p[1]], naopc_doc[, p[2]], paired = TRUE))
  out[[paste0("naopc_diff_", p[1], "_", p[2])]] <- c(mean(dv), ci(b), p_boot(b), w$p.value)
  cat(sprintf("  %-5s - %-5s %s  (bootstrap p=%.4f; Wilcoxon signed-rank p=%.4f)\n",
              p[1], p[2], fmt(mean(dv), ci(b)[1], ci(b)[2]), p_boot(b), w$p.value))
}

## ---------------- 5. LIME text-mode same-document stability (n = 20 docs) ----------------
cat("\n=== 5. LIME text-mode same-document stability (mean pairwise top-10 Jaccard), n=20 docs ===\n")
sw <- readRDS("rds/lime_text_sensitivity_sweep.rds")
for (bud in c("300","1000","5000","10000")) {
  v <- sapply(sw[[paste0("res_", bud)]], function(x) x$mean_jaccard)
  b <- replicate(B, mean(v[sample.int(length(v), length(v), TRUE)]))
  out[[paste0("lime_stab_", bud)]] <- c(mean(v), ci(b))
  cat(sprintf("  %5s perm.: %s\n", bud, fmt(mean(v), ci(b)[1], ci(b)[2])))
}
rb <- readRDS("rds/lime_text_random_baseline.rds")
cat(sprintf("  random present-word baseline: %.4f (n=%d pairs)\n", mean(rb), length(rb)))

## ---------------- 6. Added baselines (Linear SVM, XGBoost), ISOT test set ----------------
## Appended last so sections 1-5 above keep exactly the same random stream.
cat("\n=== 6. Added baselines on the ISOT test set (n=7,718); paired difference vs. LR, same representation ===\n")
svm <- readRDS("rds/svm_results.rds")
res2 <- readRDS("rds/model_results.rds"); feat2 <- readRDS("rds/features.rds")
y2 <- as.character(feat2$test_docs$label); rm(feat2)
for (r in c("bow","tfidf")) {
  lr_c <- as.character(res2[[paste0("lr_", r)]]$pred) == y2
  for (mdl in c("svm","xgb")) {
    pr <- if (mdl == "svm") svm[[paste0("svm_", r)]]$pred else readRDS(sprintf("rds/xgb_results_%s.rds", r))$pred
    cc <- pr == y2
    b <- boot_acc(cc); d <- boot_paired(cc, lr_c)
    out[[paste0("acc_", mdl, "_", r)]] <- c(mean(cc), ci(b))
    out[[paste0("diff_", mdl, "_lr_", r)]] <- c(mean(cc) - mean(lr_c), ci(d))
    cat(sprintf("  %-4s %-5s acc %s;  minus LR %s pts (bootstrap p=%.4f)\n", toupper(mdl), r,
                fmt(mean(cc), ci(b)[1], ci(b)[2]), fmt(100*(mean(cc)-mean(lr_c)), 100*ci(d)[1], 100*ci(d)[2], 2), p_boot(d)))
  }
}
rm(res2)

saveRDS(out, "rds/bootstrap_ci_results.rds")
cat("\nDone.\n")
