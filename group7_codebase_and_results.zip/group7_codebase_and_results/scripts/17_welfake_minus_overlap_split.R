suppressMessages({ library(caret) })
wf_final <- readRDS("rds/welfake_final.rds")
wf_final$label <- factor(wf_final$label_name, levels=c("Fake","Real"))

cat("Full WELFake (62,614):", table(wf_final$label), "\n")
wf_minus <- wf_final[!wf_final$isot_overlap, ]
cat("WELFake-minus-ISOT-overlap:", nrow(wf_minus), "| Fake:", sum(wf_minus$label=="Fake"), "Real:", sum(wf_minus$label=="Real"), "\n")
cat(sprintf("Retained %.2f%% of WELFake after removing ISOT-overlap docs\n", 100*nrow(wf_minus)/nrow(wf_final)))

set.seed(123)
idx <- createDataPartition(wf_minus$label, p=0.8, list=FALSE)
wfm_train <- wf_minus[idx,]; wfm_test <- wf_minus[-idx,]
cat("WFM-train:", nrow(wfm_train), " WFM-test:", nrow(wfm_test), "\n")
stopifnot(length(intersect(wfm_train$text, wfm_test$text))==0)
cat("Zero train/test overlap verified.\n")

saveRDS(list(wfm_train=wfm_train, wfm_test=wfm_test), "rds/welfake_minus_overlap_split.rds")
cat("Saved.\n")
