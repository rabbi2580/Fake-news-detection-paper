suppressMessages({ library(tm); library(glmnet); library(xgboost) })

# Reverse cross-corpus test: models trained on the WELFake v2 training split
# (which contains NO article matching ISOT under any criterion) are applied
# to the ISOT test set (7,718 docs). Because every ISOT-matching article was
# removed from this training data, ISOT test documents cannot have been seen
# in training, even those that also occur somewhere in WELFake.

sp <- readRDS("rds/welfake_minus_overlap_split_v2.rds"); wtr <- sp$wfm_train; rm(sp)
v_wf <- readRDS("rds/vocab500_wfm_v2.rds")
Xw <- readRDS("rds/wfm_train_bow_v2.rds"); stopifnot(identical(colnames(Xw), v_wf))
yw <- as.numeric(wtr$label == "Real")
te <- readRDS("rds/test_docs_light.rds"); yte <- as.character(te$label)
bow <- function(txt, vocab) { d <- DocumentTermMatrix(VCorpus(VectorSource(txt)), control = list(dictionary = vocab))[, vocab]
  stopifnot(identical(colnames(d), vocab)); as.matrix(d) }
Xi <- bow(te$text_final, v_wf)

lr <- readRDS("rds/wfm_results_v2.rds")$lr_bow_fit       # WELFake v2 LR-BoW (28_wfm_train_v2.R)
p_lr <- ifelse(as.numeric(predict(lr, newx = Xi, type = "response")) > 0.5, "Real", "Fake")

set.seed(123)
prm <- list(objective = "binary:logistic", eval_metric = "error", eta = 0.1, max_depth = 6, subsample = 0.8, colsample_bytree = 0.8, nthread = 2)
dtr <- xgb.DMatrix(Xw, label = yw)
cvx <- xgb.cv(params = prm, data = dtr, nrounds = 400, nfold = 5, early_stopping_rounds = 25, verbose = 0)
nr <- if (!is.null(cvx$early_stop$best_iteration)) cvx$early_stop$best_iteration else cvx$best_iteration
xg <- xgb.train(params = prm, data = dtr, nrounds = nr, verbose = 0)
p_xg <- ifelse(predict(xg, xgb.DMatrix(Xi)) > 0.5, "Real", "Fake")
cat("WELFake v2 XGBoost rounds:", nr, "\n")

set.seed(2031); B <- 2000; n <- length(yte)
rep_m <- function(p, name) {
  c1 <- p == yte; bal <- (mean(p[yte == "Real"] == "Real") + mean(p[yte == "Fake"] == "Fake")) / 2
  b <- replicate(B, mean(c1[sample.int(n, n, TRUE)])); q <- quantile(b, c(.025, .975))
  cat(sprintf("  %-26s accuracy %.4f [%.4f, %.4f]  balanced %.4f  Real recall %.4f  Fake recall %.4f\n", name, mean(c1), q[1], q[2], bal,
              mean(p[yte == "Real"] == "Real"), mean(p[yte == "Fake"] == "Fake")))
  c(acc = mean(c1), lo = q[[1]], hi = q[[2]], bal = bal)
}
cat(sprintf("\n=== WELFake v2 -> ISOT test (n=%d, %.1f%% Real; majority baseline %.4f) ===\n", n, 100 * mean(yte == "Real"), max(mean(yte == "Real"), mean(yte == "Fake"))))
r1 <- rep_m(p_lr, "WELFake-trained LR-BoW"); r2 <- rep_m(p_xg, "WELFake-trained XGBoost")
cat("  (in-distribution reference: ISOT-trained LR-BoW 0.9738, XGBoost 0.9821)\n")

tok <- strsplit(te$text_final, "\\s+"); hr <- vapply(tok, function(w) "reuter" %in% w, logical(1))
cat("\nBy presence of 'reuter' in the ISOT document (LR):\n")
for (cls in c("Real","Fake")) for (h in c(TRUE, FALSE)) { m <- yte == cls & hr == h
  cat(sprintf("  ISOT %s, %-13s n=%5d  accuracy %.4f\n", cls, if (h) "has reuter" else "no reuter", sum(m), mean(p_lr[m] == cls))) }
saveRDS(list(lr = r1, xgb = r2, p_lr = p_lr, p_xgb = p_xg), "rds/reverse_transfer.rds")
cat("\nDone.\n")
