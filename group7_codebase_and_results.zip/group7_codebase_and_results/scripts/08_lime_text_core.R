suppressMessages({ library(lime); library(tm); library(glmnet) })

lr_bow_glmnet <- readRDS("rds/lr_bow_glmnet.rds")
vocab500 <- readRDS("rds/vocab500.rds")
train_docs <- readRDS("rds/train_docs_light.rds")
test_docs <- readRDS("rds/test_docs_light.rds")

# Wrap glmnet model so lime can call predict_model/model_type on it
glmnet_wrap <- structure(list(fit = lr_bow_glmnet), class = "glmnet_wrap")

predict_model.glmnet_wrap <- function(x, newdata, type, ...) {
  p1 <- as.numeric(predict(x$fit, newx = as.matrix(newdata), type = "response"))
  data.frame(Fake = 1 - p1, Real = p1)
}
model_type.glmnet_wrap <- function(x, ...) "classification"

assign("predict_model.glmnet_wrap", predict_model.glmnet_wrap, envir = .GlobalEnv)
assign("model_type.glmnet_wrap", model_type.glmnet_wrap, envir = .GlobalEnv)

preprocess_bow <- function(texts) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control = list(dictionary = vocab500))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab500, colnames(mat))
  if (length(missing_cols) > 0) {
    addmat <- matrix(0, nrow = nrow(mat), ncol = length(missing_cols), dimnames = list(NULL, missing_cols))
    mat <- cbind(mat, addmat)
  }
  mat <- mat[, vocab500, drop = FALSE]
  mat
}

# quick sanity: predict on a few test docs via wrapper, compare to direct glmnet predict
samp_text <- test_docs$text_final[1:5]
samp_mat <- preprocess_bow(samp_text)
p_direct <- as.numeric(predict(lr_bow_glmnet, newx = samp_mat, type = "response"))
p_wrap <- predict_model.glmnet_wrap(glmnet_wrap, samp_mat, type="prob")
cat("Direct probs:", p_direct, "\n")
print(p_wrap)

pred_class <- ifelse(p_direct > 0.5, "Real","Fake")
cat("Predicted:", pred_class, "| Actual:", test_docs$label[1:5], "\n")

correct_idx <- which((ifelse(as.numeric(predict(lr_bow_glmnet, newx=preprocess_bow(test_docs$text_final), type="response"))>0.5,"Real","Fake")) == test_docs$label)
cat("N correctly classified:", length(correct_idx), "\n")
saveRDS(list(correct_idx=correct_idx), "rds/correct_idx.rds")

# Build text explainer and time one explain() call
explainer <- lime(test_docs$text_final[correct_idx[1]], model = glmnet_wrap, preprocess = preprocess_bow)
t0 <- Sys.time()
set.seed(42)
expl <- explain(test_docs$text_final[correct_idx[1]], explainer, n_labels = 1, n_features = 10, n_permutations = 300)
t1 <- Sys.time()
cat("Time for 1 doc, 300 perms (text mode):", as.numeric(t1-t0, units="secs"), "sec\n")
print(expl[order(-expl$feature_weight), c("feature","feature_weight","label")])

saveRDS(list(glmnet_wrap=glmnet_wrap, preprocess_bow=preprocess_bow), "rds/lime_text_core.rds")
