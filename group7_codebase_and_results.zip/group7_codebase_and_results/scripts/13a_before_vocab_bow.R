suppressMessages({ library(tm); library(slam) })

bp <- readRDS("rds/before_pipeline_docs.rds")
before_train <- bp$before_train; before_test <- bp$before_test

train_corpus <- VCorpus(VectorSource(before_train$text_final))
train_dtm <- DocumentTermMatrix(train_corpus)
train_dtm_pruned <- removeSparseTerms(train_dtm, 0.99)
cat("Terms surviving pruning:", ncol(train_dtm_pruned), "\n")

# Use slam::col_sums on the sparse matrix directly - no dense conversion
term_freq <- slam::col_sums(train_dtm_pruned)
vocab500_before <- names(sort(term_freq, decreasing=TRUE))[1:500]
saveRDS(vocab500_before, "rds/vocab500_before.rds")
rm(train_dtm, train_dtm_pruned, train_corpus, term_freq); gc()

build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control=list(dictionary=vocab))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab, colnames(mat))
  if (length(missing_cols)>0) { addmat <- matrix(0,nrow=nrow(mat),ncol=length(missing_cols),dimnames=list(NULL,missing_cols)); mat <- cbind(mat,addmat) }
  mat[, vocab, drop=FALSE]
}

before_train_bow <- build_bow(before_train$text_final, vocab500_before)
saveRDS(before_train_bow, "rds/before_train_bow.rds")
rm(before_train_bow); gc()

before_test_bow <- build_bow(before_test$text_final, vocab500_before)
saveRDS(before_test_bow, "rds/before_test_bow.rds")
cat("Saved before train/test BoW matrices.\n")
