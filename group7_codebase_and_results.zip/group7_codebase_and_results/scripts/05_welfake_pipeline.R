suppressMessages({
  library(dplyr); library(stringr); library(tm); library(SnowballC)
})
set.seed(123)

wf <- read.csv("data2/welfake_raw.csv", stringsAsFactors = FALSE, encoding = "UTF-8")
cat("WELFake raw shape:", nrow(wf), ncol(wf), "\n")
print(colnames(wf))
print(table(wf$label))

# drop rows with missing/empty text (exact empty string or NA, not whitespace-trimmed)
wf$text <- as.character(wf$text)
empty_text <- is.na(wf$text) | wf$text == ""
cat("Missing/empty text rows:", sum(empty_text), "\n")
wf <- wf[!empty_text, ]
cat("After dropping empty text:", nrow(wf), "\n")

# label polarity: content-verified label=0 -> Real, label=1 -> Fake (per paper)
wf$label_name <- ifelse(wf$label == 0, "Real", "Fake")
print(table(wf$label_name))

# Dedup on exact text match
dup_idx <- duplicated(wf$text)
n_dup <- sum(dup_idx)
cat("Exact-duplicate rows:", n_dup, sprintf("(%.2f%%)\n", 100*n_dup/nrow(wf)))
print(table(wf$label_name[dup_idx]))

wf_deduped <- wf[!dup_idx, ]
cat("After dedup:", nrow(wf_deduped), "\n")

saveRDS(wf_deduped, "rds/welfake_deduped.rds")
cat("Saved welfake_deduped.rds\n")
