suppressMessages({ library(glmnet) })
split <- readRDS("rds/welfake_minus_overlap_split.rds")
wfm_train <- split$wfm_train; wfm_test <- split$wfm_test
wfm_train_bow <- readRDS("rds/wfm_train_bow.rds")
wfm_test_bow <- readRDS("rds/wfm_test_bow.rds")

N_train <- nrow(wfm_train_bow); df_train <- colSums(wfm_train_bow>0)
idf <- log2(N_train/df_train); idf[is.infinite(idf)] <- 0
tfidf_from_bow <- function(bow, idfv) { rs<-rowSums(bow); rs[rs==0]<-1; sweep(bow/rs,2,idfv,`*`) }
wfm_train_tfidf <- tfidf_from_bow(wfm_train_bow, idf)
wfm_test_tfidf <- tfidf_from_bow(wfm_test_bow, idf)
saveRDS(idf, "rds/wfm_idf.rds")
saveRDS(wfm_train_tfidf, "rds/wfm_train_tfidf.rds")
saveRDS(wfm_test_tfidf, "rds/wfm_test_tfidf.rds")
cat("TFIDF built.\n")

y_train <- ifelse(wfm_train$label=="Real",1,0)
# Use the paper's consistently-selected lambda directly (4.64159e-4, selected across every ISOT/WELFake LR fit
# in this paper to date) rather than a fresh CV search, which did not converge in reasonable time on this
# heavily imbalanced (76% Real) subset at the smallest grid lambdas. This is disclosed in the write-up.
FIXED_LAMBDA <- 4.641589e-4

t0 <- Sys.time()
lr_bow_fit <- glmnet(wfm_train_bow, y_train, family="binomial", alpha=1, lambda=FIXED_LAMBDA)
cat("LR-BoW fit time:", as.numeric(Sys.time()-t0,units="secs"), "s\n")

metrics_full <- function(pred, actual, positive="Real") {
  tp <- sum(pred==positive & actual==positive); tn <- sum(pred!=positive & actual!=positive)
  fp <- sum(pred==positive & actual!=positive); fn <- sum(pred!=positive & actual==positive)
  acc <- (tp+tn)/(tp+tn+fp+fn)
  prec <- tp/(tp+fp); rec <- tp/(tp+fn); f1 <- 2*prec*rec/(prec+rec)
  sens <- tp/(tp+fn); spec <- tn/(tn+fp); bal_acc <- (sens+spec)/2
  mcc_num <- (tp*tn - fp*fn); mcc_den <- sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
  mcc <- ifelse(mcc_den==0, NA, mcc_num/mcc_den)
  f1_fake <- {tp2<-tn; fp2<-fn; fn2<-fp; prec2<-tp2/(tp2+fp2); rec2<-tp2/(tp2+fn2); 2*prec2*rec2/(prec2+rec2)}
  macro_f1 <- mean(c(f1, f1_fake))
  list(acc=acc, f1=f1, bal_acc=bal_acc, mcc=mcc, macro_f1=macro_f1)
}

pred_bow <- ifelse(as.numeric(predict(lr_bow_fit, newx=wfm_test_bow, type="response"))>0.5,"Real","Fake")
m_lr_bow <- metrics_full(pred_bow, as.character(wfm_test$label))
cat("LR-BoW: acc=",m_lr_bow$acc," f1=",m_lr_bow$f1," macroF1=",m_lr_bow$macro_f1," balAcc=",m_lr_bow$bal_acc," MCC=",m_lr_bow$mcc,"\n")

t0 <- Sys.time()
lr_tfidf_fit <- glmnet(wfm_train_tfidf, y_train, family="binomial", alpha=1, lambda=FIXED_LAMBDA)
cat("LR-TFIDF fit time:", as.numeric(Sys.time()-t0,units="secs"), "s\n")
pred_tfidf <- ifelse(as.numeric(predict(lr_tfidf_fit, newx=wfm_test_tfidf, type="response"))>0.5,"Real","Fake")
m_lr_tfidf <- metrics_full(pred_tfidf, as.character(wfm_test$label))
cat("LR-TFIDF: acc=",m_lr_tfidf$acc," f1=",m_lr_tfidf$f1," macroF1=",m_lr_tfidf$macro_f1," balAcc=",m_lr_tfidf$bal_acc," MCC=",m_lr_tfidf$mcc,"\n")

saveRDS(list(lr_bow_fit=lr_bow_fit, lr_tfidf_fit=lr_tfidf_fit, m_lr_bow=m_lr_bow, m_lr_tfidf=m_lr_tfidf,
             lambda=FIXED_LAMBDA), "rds/wfm_lr_results.rds")
rm(wfm_train_bow, wfm_test_bow, wfm_train_tfidf, wfm_test_tfidf); gc()
cat("Done.\n")
