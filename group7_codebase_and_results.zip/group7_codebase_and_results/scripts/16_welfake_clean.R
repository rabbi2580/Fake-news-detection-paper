suppressMessages({ library(stringr); library(tm); library(SnowballC) })

wf_deduped <- readRDS("rds/welfake_deduped.rds")
overlap <- readRDS("rds/overlap_results.rds")
wf_deduped$isot_overlap <- overlap$wf_exact_match
cat("WELFake rows flagged as ISOT-overlap:", sum(wf_deduped$isot_overlap), "\n")

clean_text <- function(txt) {
  txt <- tolower(txt)
  txt <- str_replace_all(txt, "http\\S+|www\\.\\S+", " ")
  txt <- str_replace_all(txt, "[^a-z\\s]", " ")
  txt <- str_replace_all(txt, "\\s+", " ")
  str_trim(txt)
}
remove_stopwords_stem <- function(txt) {
  words <- unlist(str_split(txt, "\\s+")); words <- words[words != ""]
  words <- words[!words %in% stopwords("en")]
  words <- wordStem(words, language = "english")
  paste(words, collapse = " ")
}

cat("Cleaning", nrow(wf_deduped), "WELFake documents (no dateline-strip, multi-source corpus)...\n")
wf_deduped$text_clean <- clean_text(wf_deduped$text)
wf_deduped$text_final <- sapply(wf_deduped$text_clean, remove_stopwords_stem)

empty_idx <- str_trim(wf_deduped$text_final) == ""
cat("Empty after cleaning:", sum(empty_idx), "\n")
wf_final <- wf_deduped[!empty_idx, ]
cat("WELFake final corpus:", nrow(wf_final), "| Fake:", sum(wf_final$label_name=="Fake"), "Real:", sum(wf_final$label_name=="Real"), "\n")
cat("Of these, ISOT-overlap:", sum(wf_final$isot_overlap), "\n")

saveRDS(wf_final, "rds/welfake_final.rds")
cat("Saved welfake_final.rds\n")
