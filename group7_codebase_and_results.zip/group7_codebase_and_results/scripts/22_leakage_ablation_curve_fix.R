suppressMessages({ library(glmnet) })

# Corrected incremental curve: ranks ONLY the 8 source-artifact tokens by
# |coefficient| and removes them one at a time in that order, showing the
# cumulative accuracy converges to the same point as removing all 8 at once
# (21_leakage_ablation_dedup.R), regardless of removal order. (An earlier
# attempt mistakenly ranked across the full 500-term vocabulary, which pulls
# in unrelated high-|coef| tokens like "getti"/"via"/"pic" -- those are a
# separate media-caption-fragment artifact, not the dateline/wire-service
# artifact this ablation targets.)

feat <- readRDS("rds/features.rds")
train_docs <- feat$train_docs; test_docs <- feat$test_docs
train_bow <- feat$train_bow; test_bow <- feat$test_bow
vocab500 <- feat$vocab500
y_train <- train_docs$label; y_test <- test_docs$label
y_train_bin <- ifelse(y_train=="Real",1,0)

abl <- readRDS("rds/leakage_ablation_dedup.rds")
lambda_fixed <- abl$fit_full_bow$bestTune$lambda
cat("Fixed lambda:", lambda_fixed, "\n")

artifact_tokens <- c("reuter","monday","tuesday","wednesday","thursday","friday","saturday","sunday")
full_glm <- glmnet(train_bow, y_train_bin, family="binomial", alpha=1, lambda=lambda_fixed)
beta <- as.matrix(full_glm$beta)
artifact_coefs <- beta[artifact_tokens, 1]
ranked_tokens <- names(sort(abs(artifact_coefs), decreasing=TRUE))
cat("Artifact tokens ranked by |coef|:\n")
print(round(artifact_coefs[ranked_tokens], 4))

eval_glmnet_acc <- function(Xtr, Xte, ytr_bin, yte) {
  f <- glmnet(Xtr, ytr_bin, family="binomial", alpha=1, lambda=lambda_fixed)
  p <- as.numeric(predict(f, newx=Xte, type="response"))
  mean(ifelse(p>0.5,"Real","Fake") == yte)
}

ks <- 0:length(artifact_tokens)
curve <- data.frame(k=ks, accuracy=NA_real_, removed=NA_character_)
for (i in seq_along(ks)) {
  k <- ks[i]
  rm_tok <- if (k==0) character(0) else ranked_tokens[1:k]
  keep_k <- setdiff(vocab500, rm_tok)
  acc_k <- eval_glmnet_acc(train_bow[,keep_k], test_bow[,keep_k], y_train_bin, y_test)
  curve$accuracy[i] <- acc_k
  curve$removed[i] <- paste(rm_tok, collapse=",")
  cat(sprintf("k=%d  acc=%.4f  removed=[%s]\n", k, acc_k, paste(rm_tok, collapse=",")))
}

total_drop <- curve$accuracy[curve$k==0] - curve$accuracy[curve$k==max(curve$k)]
reuter_drop <- curve$accuracy[curve$k==0] - curve$accuracy[curve$k==1]
cat(sprintf("\nTotal drop k=0->%d: %.4f (%.2f points). First-removed token: %s, its share of total drop: %.1f%%\n",
            max(curve$k), total_drop, 100*total_drop, ranked_tokens[1], 100*reuter_drop/total_drop))
cat(sprintf("Final-point accuracy (all 8 removed, direct refit): %.4f  | caret-CV-retrained 8-token-removed accuracy (21_*.R): %.4f\n",
            curve$accuracy[curve$k==max(curve$k)], abl$acc_abl_bow))

saveRDS(curve, "rds/leakage_ablation_curve.rds")
cat("\nDone.\n")
