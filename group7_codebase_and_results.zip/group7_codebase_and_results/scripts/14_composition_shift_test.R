suppressMessages({ library(tm); library(glmnet); library(naivebayes) })

after_test_docs <- readRDS("rds/test_docs_light.rds")  # deduplicated/after test set (n=7718)
vocab500_before <- readRDS("rds/vocab500_before.rds")
before_idf <- readRDS("rds/before_idf.rds")

build_bow <- function(texts, vocab) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control=list(dictionary=vocab))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab, colnames(mat))
  if (length(missing_cols)>0) { addmat <- matrix(0,nrow=nrow(mat),ncol=length(missing_cols),dimnames=list(NULL,missing_cols)); mat <- cbind(mat,addmat) }
  mat[, vocab, drop=FALSE]
}
tfidf_from_bow <- function(bow, idfv) { rs <- rowSums(bow); rs[rs==0]<-1; sweep(bow/rs, 2, idfv, `*`) }

# Vectorize the AFTER test set using the BEFORE model's vocabulary/idf
after_test_bow_viaBeforeVocab <- build_bow(after_test_docs$text_final, vocab500_before)
after_test_tfidf_viaBeforeVocab <- tfidf_from_bow(after_test_bow_viaBeforeVocab, before_idf)

cat("After-test class balance: Real=", mean(after_test_docs$label=="Real"), "\n")
before_test_label <- readRDS("rds/before_pipeline_docs.rds")$before_test$label
cat("Before-test class balance: Real=", mean(before_test_label=="Real"), "\n")

eval_acc <- function(fit, X, y_true, is_glmnet=TRUE) {
  if (is_glmnet) {
    p <- as.numeric(predict(fit, newx=X, type="response"))
    pred <- ifelse(p>0.5,"Real","Fake")
  } else {
    pred <- as.character(predict(fit, as.data.frame(X)))
  }
  mean(pred == as.character(y_true))
}

lr_bow_before <- readRDS("rds/lr_bow_before.rds")$fit
lr_tfidf_before <- readRDS("rds/lr_tfidf_before.rds")$fit
acc_lr_bow_crossEval   <- eval_acc(lr_bow_before, after_test_bow_viaBeforeVocab, after_test_docs$label)
acc_lr_tfidf_crossEval <- eval_acc(lr_tfidf_before, after_test_tfidf_viaBeforeVocab, after_test_docs$label)
cat("\n=== BEFORE-trained models evaluated on AFTER (deduplicated) test set ===\n")
cat("LR-BoW:   ", acc_lr_bow_crossEval, "\n")
cat("LR-TFIDF: ", acc_lr_tfidf_crossEval, "\n")

nb_bow_before <- readRDS("rds/nb_bow_before.rds")
nb_tfidf_before <- readRDS("rds/nb_tfidf_before.rds")
acc_nb_bow_crossEval   <- eval_acc(nb_bow_before, after_test_bow_viaBeforeVocab, after_test_docs$label, is_glmnet=FALSE)
acc_nb_tfidf_crossEval <- eval_acc(nb_tfidf_before, after_test_tfidf_viaBeforeVocab, after_test_docs$label, is_glmnet=FALSE)
cat("NB-BoW:   ", acc_nb_bow_crossEval, "\n")
cat("NB-TFIDF: ", acc_nb_tfidf_crossEval, "\n")

saveRDS(list(acc_lr_bow_crossEval=acc_lr_bow_crossEval, acc_lr_tfidf_crossEval=acc_lr_tfidf_crossEval,
             acc_nb_bow_crossEval=acc_nb_bow_crossEval, acc_nb_tfidf_crossEval=acc_nb_tfidf_crossEval),
        "rds/composition_shift_results.rds")
cat("\nDone.\n")
