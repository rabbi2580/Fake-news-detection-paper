suppressMessages({
  library(dplyr); library(stringr); library(tm); library(SnowballC)
})

deduped <- readRDS("rds/deduped_raw.rds")

clean_text <- function(txt) {
  txt <- tolower(txt)
  txt <- str_replace_all(txt, "http\\S+|www\\.\\S+", " ")
  txt <- str_replace_all(txt, "[^a-z\\s]", " ")
  txt <- str_replace_all(txt, "\\s+", " ")
  txt <- str_trim(txt)
  txt
}

remove_stopwords_stem <- function(txt) {
  words <- unlist(str_split(txt, "\\s+"))
  words <- words[words != ""]
  words <- words[!words %in% stopwords("en")]
  words <- wordStem(words, language = "english")
  paste(words, collapse = " ")
}

cat("Cleaning", nrow(deduped), "documents...\n")
deduped$text_clean <- clean_text(deduped$text)
deduped$text_final <- sapply(deduped$text_clean, remove_stopwords_stem)

n_before <- nrow(deduped)
empty_idx <- str_trim(deduped$text_final) == ""
cat("Empty after cleaning:", sum(empty_idx), "\n")
print(table(deduped$label[empty_idx]))

final <- deduped[!empty_idx, ]
cat("Final corpus:", nrow(final), "| Fake:", sum(final$label=="Fake"), "Real:", sum(final$label=="Real"), "\n")

saveRDS(final, "rds/final_corpus.rds")
cat("Saved final_corpus.rds\n")
