# Figure: tabular-path vs text-mode LIME -- same-document stability vs.
# cross-document similarity of the top-10 explanation sets (20 documents).
# A useful explanation is stable on the same document (high blue bar) but
# DIFFERENT across documents (low orange bar). Tabular LIME at 5,000
# permutations is "stable" only because it returns nearly the same words for
# every document. Numbers come from 09_lime_text_stability.R and
# 38_agreement_tabular_rerun.R (part B); nothing is hardcoded by hand.
tab <- readRDS("rds/tabular_stability_rerun.rds")
sw  <- readRDS("rds/lime_text_sensitivity_sweep.rds")
same <- c(mean(tab$tab_300$within), mean(tab$tab_5000$within),
          mean(sapply(sw$res_5000, `[[`, "mean_jaccard")), mean(sapply(sw$res_10000, `[[`, "mean_jaccard")))
across <- c(tab$tab_300$across, tab$tab_5000$across, tab$text_5000$across, tab$text_10000$across)
m <- rbind(same, across)
colnames(m) <- c("Tabular\n300 perm.", "Tabular\n5,000 perm.", "Text-mode\n5,000 perm.", "Text-mode\n10,000 perm.")
blue <- "#2a78d6"; orange <- "#eb6834"; ink <- "#2b2b2b"; muted <- "#6b6b6b"

png("paper/figures/lime_tabular_vs_text.png", width = 1500, height = 950, res = 220)
par(mar = c(4.2, 4.2, 1.2, 0.6), family = "sans", col.axis = muted, fg = muted, las = 1, mgp = c(2.6, 0.6, 0))
bp <- barplot(m, beside = TRUE, ylim = c(0, 1.08), col = c(blue, orange), border = "white", lwd = 2,
              space = c(0.08, 0.7), axes = FALSE, names.arg = rep("", 4))
abline(h = seq(0, 1, 0.25), col = "#e6e6e3", lwd = 0.8); par(new = FALSE)
barplot(m, beside = TRUE, ylim = c(0, 1.08), col = c(blue, orange), border = "white", lwd = 2,
        space = c(0.08, 0.7), axes = FALSE, names.arg = rep("", 4), add = TRUE)
axis(2, at = seq(0, 1, 0.25), lwd = 0, lwd.ticks = 0, cex.axis = 0.8)
mtext("Mean top-10 Jaccard", side = 2, line = 2.9, col = ink, cex = 0.85, las = 0)
text(colMeans(bp), -0.075, colnames(m), xpd = TRUE, cex = 0.72, col = ink, adj = c(0.5, 1))
text(bp, m + 0.035, sprintf("%.2f", m), cex = 0.68, col = ink)
abline(h = tab$random_full_vocab, lty = 2, col = muted, lwd = 1)
legend("topleft", inset = c(0.01, -0.02), bty = "n", cex = 0.72, text.col = ink,
       legend = c("Same document, 5 reruns (stability)", "Different documents (should be low)",
                  sprintf("Random top-10 baseline (%.2f)", tab$random_full_vocab)),
       pch = c(15, 15, NA), pt.cex = 1.6, col = c(blue, orange, muted), lty = c(NA, NA, 2), lwd = c(NA, NA, 1))
dev.off()
cat("Saved paper/figures/lime_tabular_vs_text.png\n"); print(round(m, 3))
