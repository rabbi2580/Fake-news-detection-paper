suppressMessages({ library(caret); library(glmnet) })

# Remaining confidence intervals requested in review:
#  (1) tabular-path LIME same-document stability (300 / 5,000 perm.) and
#      cross-document similarity, n=20 documents (38_*.R part B);
#  (2) the TF-IDF artifact-ablation drop (0.87 pts), paired over test docs --
#      requires refitting the two TF-IDF models (same protocol as 21_*.R),
#      because 21_*.R saved only the BoW fits.
set.seed(2033); B <- 2000
ci <- function(v) quantile(v, c(.025, .975), names = FALSE)
bm <- function(v) replicate(B, mean(v[sample.int(length(v), length(v), TRUE)]))
J <- function(a, b) length(intersect(a, b)) / length(union(a, b))

tb <- readRDS("rds/tabular_stability_rerun.rds")
cat("=== Tabular LIME, n=20 documents, 95% bootstrap CI over documents ===\n")
for (np in c("300","5000")) {
  w <- tb[[paste0("tab_", np)]]$within; b <- bm(w)
  first <- tb[[paste0("tab_", np)]]$first
  # cross-doc similarity per document = mean Jaccard of its explanation with the other 19 documents'
  xs <- sapply(seq_along(first), function(i) mean(sapply(setdiff(seq_along(first), i), function(j) J(first[[i]], first[[j]]))))
  bx <- bm(xs)
  cat(sprintf("  %5s perm.: same-doc stability %.3f [%.3f, %.3f]; cross-doc similarity %.3f [%.3f, %.3f]\n",
              np, mean(w), ci(b)[1], ci(b)[2], mean(xs), ci(bx)[1], ci(bx)[2]))
}

cat("\n=== TF-IDF artifact ablation, paired bootstrap over the 7,718 test docs ===\n")
feat <- readRDS("rds/features.rds")
art <- c("reuter","monday","tuesday","wednesday","thursday","friday","saturday","sunday")
keep <- setdiff(feat$vocab500, art); y <- as.character(feat$test_docs$label); ytr <- feat$train_docs$label
cvc <- trainControl(method = "cv", number = 5); grid <- expand.grid(alpha = 1, lambda = 10^seq(log10(1e-4), log10(1e-1), length.out = 10))
fit <- function(X) { set.seed(123); train(label ~ ., data = data.frame(X, label = ytr, check.names = FALSE), method = "glmnet",
                                           family = "binomial", trControl = cvc, tuneGrid = grid) }
pf <- as.character(predict(fit(feat$train_tfidf), data.frame(feat$test_tfidf, check.names = FALSE)))
pa <- as.character(predict(fit(feat$train_tfidf[, keep]), data.frame(feat$test_tfidf[, keep], check.names = FALSE)))
cf <- pf == y; ca <- pa == y; n <- length(y)
d <- replicate(B, { i <- sample.int(n, n, TRUE); mean(cf[i]) - mean(ca[i]) })
cat(sprintf("  full %.4f -> ablated %.4f; drop %.2f pts [%.2f, %.2f]; McNemar p=%.3g\n", mean(cf), mean(ca),
            100 * (mean(cf) - mean(ca)), 100 * ci(d)[1], 100 * ci(d)[2], mcnemar.test(table(cf, ca))$p.value))
cat("\nDone.\n")
