suppressMessages({ library(glmnet) })
bp <- readRDS("rds/before_pipeline_docs.rds")
before_train <- bp$before_train; before_test <- bp$before_test
before_train_bow <- readRDS("rds/before_train_bow.rds")
before_test_bow <- readRDS("rds/before_test_bow.rds")

N_train <- nrow(before_train_bow); df_train <- colSums(before_train_bow>0)
idf <- log2(N_train/df_train); idf[is.infinite(idf)] <- 0
tfidf_from_bow <- function(bow, idfv) { rs <- rowSums(bow); rs[rs==0]<-1; sweep(bow/rs, 2, idfv, `*`) }
before_train_tfidf <- tfidf_from_bow(before_train_bow, idf)
before_test_tfidf <- tfidf_from_bow(before_test_bow, idf)
saveRDS(idf, "rds/before_idf.rds")
saveRDS(before_train_tfidf, "rds/before_train_tfidf.rds")
saveRDS(before_test_tfidf, "rds/before_test_tfidf.rds")

y_train <- ifelse(before_train$label=="Real",1,0)
lambda_grid <- 10^seq(log10(1e-4), log10(1e-1), length.out=10)
fit_lr <- function(X, y, seed=123) {
  set.seed(seed)
  cvfit <- cv.glmnet(X, y, family="binomial", alpha=1, lambda=lambda_grid, nfolds=5, type.measure="class")
  best_lambda <- cvfit$lambda.min
  final <- glmnet(X, y, family="binomial", alpha=1, lambda=best_lambda)
  list(fit=final, lambda=best_lambda)
}

lr_bow_before <- fit_lr(before_train_bow, y_train)
cat("LR-BoW lambda:", lr_bow_before$lambda, "\n")
eval_acc <- function(fit, X, y_true) { p<-as.numeric(predict(fit,newx=X,type="response")); mean(ifelse(p>0.5,"Real","Fake")==y_true) }
cat("LR-BoW before-pipeline test accuracy:", eval_acc(lr_bow_before$fit, before_test_bow, as.character(before_test$label)), "\n")
saveRDS(lr_bow_before, "rds/lr_bow_before.rds")
rm(before_train_bow, before_test_bow); gc()

lr_tfidf_before <- fit_lr(before_train_tfidf, y_train)
cat("LR-TFIDF lambda:", lr_tfidf_before$lambda, "\n")
cat("LR-TFIDF before-pipeline test accuracy:", eval_acc(lr_tfidf_before$fit, before_test_tfidf, as.character(before_test$label)), "\n")
saveRDS(lr_tfidf_before, "rds/lr_tfidf_before.rds")
cat("Done.\n")
