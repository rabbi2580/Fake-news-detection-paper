suppressMessages({
  library(dplyr); library(lime); library(tm)
})

feat <- readRDS("rds/features.rds")
results <- readRDS("rds/model_results.rds")
vocab500 <- feat$vocab500
lr_bow_fit <- results$lr_bow$fit

# Preprocess: raw (perturbed) text strings -> 500-col BoW matrix matching training vocab/order
preprocess_bow <- function(texts) {
  corpus <- VCorpus(VectorSource(texts))
  dtm <- DocumentTermMatrix(corpus, control = list(dictionary = vocab500))
  mat <- as.matrix(dtm)
  missing_cols <- setdiff(vocab500, colnames(mat))
  if (length(missing_cols) > 0) {
    addmat <- matrix(0, nrow = nrow(mat), ncol = length(missing_cols), dimnames = list(NULL, missing_cols))
    mat <- cbind(mat, addmat)
  }
  mat <- mat[, vocab500, drop = FALSE]
  as.data.frame(mat, check.names = FALSE)
}

test_docs <- feat$test_docs
pred_bow <- predict(lr_bow_fit, as.data.frame(feat$test_bow, check.names=FALSE))
correct_idx <- which(pred_bow == test_docs$label)
cat("Correctly classified test docs:", length(correct_idx), "\n")

set.seed(1)
sample_idx <- sample(correct_idx, 1)
doc_text <- test_docs$text_final[sample_idx]
cat("Doc length (chars):", nchar(doc_text), " words:", length(strsplit(doc_text," ")[[1]]), "\n")

explainer <- lime(test_docs$text_final[sample_idx], model = lr_bow_fit, preprocess = preprocess_bow)

t0 <- Sys.time()
set.seed(42)
expl <- explain(test_docs$text_final[sample_idx], explainer, n_labels = 1, n_features = 10, n_permutations = 300)
t1 <- Sys.time()
cat("Time for 1 doc, 300 perms:", as.numeric(t1-t0), "sec\n")
print(expl[, c("feature","feature_weight","label")])
saveRDS(list(preprocess_bow=preprocess_bow), "rds/lime_text_preprocess.rds")
