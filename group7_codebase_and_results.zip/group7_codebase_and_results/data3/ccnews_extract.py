# Build the CC-News mainstream-publisher sample used by scripts/43_ccnews_publisher_probe.R.
# Source: Hugging Face dataset vblagoje/cc_news (parquet shards 0 and 1).
# Run from data3/:  python3 ccnews_extract.py   (downloads ~450 MB, keeps a 5,013-row CSV)
import subprocess, pandas as pd
for i in (0, 1):
    subprocess.run(["curl", "-s", "-L", "-o", f"cc{i}.parquet",
                    f"https://huggingface.co/api/datasets/vblagoje/cc_news/parquet/plain_text/train/{i}.parquet"], check=True)
pubs = ["uk.reuters.com","www.bbc.com","www.nytimes.com","www.npr.org","www.nbcnews.com","abcnews.go.com",
        "www.latimes.com","www.irishtimes.com","nationalpost.com","www.nzherald.co.nz"]
d = pd.concat([pd.read_parquet(f, columns=["domain","date","title","text","url"]) for f in ["cc0.parquet","cc1.parquet"]])
d = d[d.domain.isin(pubs) & (d.date.str[:4] == "2017") & (d.text.str.len() >= 500)].drop_duplicates("text")
s = pd.concat([g.sample(min(len(g), 600), random_state=2029) for _, g in d.groupby("domain")])
s.to_csv("ccnews_2017_mainstream_sample.csv", index=False)
print(len(s)); print(s.domain.value_counts())
